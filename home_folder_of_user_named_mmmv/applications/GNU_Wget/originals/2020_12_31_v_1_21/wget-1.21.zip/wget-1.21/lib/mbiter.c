#include <config.h>
#define MBITER_INLINE _GL_EXTERN_INLINE
#include "mbiter.h"
