#!/usr/bin/env bash
#==========================================================================
# Initial author of this file: Martin.Vahi@softf1.com
# This file is in public domain.
# The following line is a spdx.org license label line:
# SPDX-License-Identifier: 0BSD
#
# The main control flow entry in this script is the func_main(),
#==========================================================================

func_settings(){
    # The
    S_FP_FOLDER_WITH_INDEXABLE_TXT="$S_FP_DIR/text_to_be_indexed"
    # has been created from a recursive copy of
    # https://web.archive.org/web/20260303200036/https://xlinux.nist.gov/dads/
    # by using /usr/bin/html2text

    S_FP_FOLDER_WITH_INDICES="$S_FP_DIR/demoindex"
} # func_settings

#--------------------------------------------------------------------------
# All below this line is just implementation. Start of boilerplate-library.
#--------------------------------------------------------------------------
S_FP_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
#--------------------------------------------------------------------------

func_mmmv_wait_and_sync_t1(){
    wait # for background processes started by this Bash script to exit/finish
    sync # network drives, USB-sticks, etc.
    wait # for sync
} # func_mmmv_wait_and_sync_t1

#--------------------------------------------------------------------------
func_mmmv_init_s_timestamp_if_not_inited_t1(){
    if [ "$S_TIMESTAMP" == "" ]; then
        if [ "`which date 2> /dev/null`" != "" ]; then
            S_TIMESTAMP="`date +%Y`_`date +%m`_`date +%d`_T_`date +%H`h_`date +%M`min_`date +%S`s"
        else
            S_TIMESTAMP="0000_00_00_T_00h_00min_00s"
            echo ""
            echo -e "The console program \"\e[31mdate\e[39m\" is missing from the PATH."
            echo "Using a constant value, "
            echo ""
            echo "    S_TIMESTAMP=\"$S_TIMESTAMP\""
            echo ""
            echo "GUID=='78016d4d-633c-4c09-9434-b22360a04ae7'"
            echo ""
        fi
    fi
} # func_mmmv_init_s_timestamp_if_not_inited_t1

#--------------------------------------------------------------------------

func_mmmv_assert_error_code_zero_t2(){
    local S_ERR_CODE="$1" # the "$?"
    local S_GUID_CANDIDATE="$2"
    #----------------------------------------------------------------------
    if [ "$S_GUID_CANDIDATE" == "" ]; then
        echo ""
        echo -e "\e[31mThe Bash code that calls this function is flawed. \e[39m"
        echo ""
        echo "    S_GUID_CANDIDATE==\"\""
        echo ""
        echo "but it is expected to be a GUID."
        echo "Aborting script."
        echo "GUID=='7361f11e-d6fd-455d-bd34-b22360a04ae7'"
        echo "S_GUID_CANDIDATE=='$S_GUID_CANDIDATE'"
        echo ""
        #--------
        exit 1
    fi
    #------------------------------
    # If the "$?" were evaluated in this function,
    # then it would be "0" even, if it is
    # something else at the calling code.
    if [ "$S_ERR_CODE" != "0" ];then
        echo ""
        echo "Something went wrong. Error code: $S_ERR_CODE"
        echo -e "\e[31mAborting script. \e[39m"
        echo "GUID=='14a58d11-0e72-455d-a634-b22360a04ae7'"
        echo "S_GUID_CANDIDATE=='$S_GUID_CANDIDATE'"
        echo ""
        #--------
        exit 1
    fi
    #------------------------------
} # func_mmmv_assert_error_code_zero_t2

#--------------------------------------------------------------------------

func_mmmv_assert_file_exists_t1() {
    local S_FP="$1"
    local S_GUID_CANDIDATE="$2"
    local SB_OPTIONAL_BAN_SYMLINKS="$3" # domain: {"t", "f", ""} default: "f"
                                        # is the last formal parameter
                                        # in stead of the S_GUID_CANDIDATE,
                                        # because that way this function is
                                        # backwards compatible with
                                        # an earlier version of this
                                        # function.
    #----------------------------------------------------------------------
    local SB_LACK_OF_PARAMETERS="f"
    if [ "$S_FP" == "" ]; then
        SB_LACK_OF_PARAMETERS="t"
    fi
    if [ "$S_GUID_CANDIDATE" == "" ]; then
        SB_LACK_OF_PARAMETERS="t"
    fi
    if [ "$SB_LACK_OF_PARAMETERS" == "t" ]; then
        echo ""
        echo -e "\e[31mThe code that calls this function is flawed. \e[39m"
        echo "This function requires 2 parameters, which are "
        echo "S_FP, S_GUID_CANDIDATE, and it has an optional 3. parameter, "
        echo "which is SB_OPTIONAL_BAN_SYMLINKS."
        if [ "$S_GUID_CANDIDATE" != "" ]; then
            echo "S_GUID_CANDIDATE=='$S_GUID_CANDIDATE'"
        fi
        echo "GUID=='8aa1e9d6-9252-422f-b534-b22360a04ae7'"
        echo ""
        #--------
        exit 1 # exiting with an error
    else
        if [ "$SB_LACK_OF_PARAMETERS" != "f" ]; then
            echo -e "\e[31mThis code is flawed. \e[39m"
            echo "GUID=='35e06bef-0b94-44dd-a234-b22360a04ae7'"
            #--------
            exit 1 # exiting with an error
        fi
    fi
    #------------------------------
    if [ "$SB_OPTIONAL_BAN_SYMLINKS" == "" ]; then
        # The default value of the
        SB_OPTIONAL_BAN_SYMLINKS="f"
        # must be backwards compatible with the
        # version of this function, where
        # symlinks to files were treated as actual files.
    else
        if [ "$SB_OPTIONAL_BAN_SYMLINKS" != "t" ]; then
            if [ "$SB_OPTIONAL_BAN_SYMLINKS" != "f" ]; then
                echo ""
                echo "The "
                echo ""
                echo "    SB_OPTIONAL_BAN_SYMLINKS==\"$SB_OPTIONAL_BAN_SYMLINKS\""
                echo ""
                echo "but the valid values for the SB_OPTIONAL_BAN_SYMLINKS"
                echo "are: \"t\", \"f\", \"\"."
                echo "S_GUID_CANDIDATE=='$S_GUID_CANDIDATE'"
                echo "GUID=='93cdb4e1-3083-40b8-9234-b22360a04ae7'"
                echo ""
                #--------
                exit 1 # exiting with an error
            fi
        fi
    fi
    #------------------------------
    if [ ! -e "$S_FP" ]; then
        if [ -h "$S_FP" ]; then
            echo ""
            echo "The path "
            echo ""
            echo "    $S_FP "
            echo ""
            echo -e "points to a\e[31m broken symlink\e[39m, but "
            if [ "$SB_OPTIONAL_BAN_SYMLINKS" == "t" ]; then
                echo "a file is expected."
            else
                echo "a file or a symlink to a file is expected."
            fi
            echo "S_GUID_CANDIDATE==\"$S_GUID_CANDIDATE\""
            echo "GUID=='5036c563-5183-4074-ae34-b22360a04ae7'"
            echo ""
            #--------
            exit 1 # exiting with an error
        else
            echo ""
            if [ "$SB_OPTIONAL_BAN_SYMLINKS" == "t" ]; then
                echo "The file "
            else
                echo "The file or a symlink to a file "
            fi
            echo ""
            echo "    $S_FP "
            echo ""
            echo -e "\e[31mdoes not exist\e[39m."
            echo "S_GUID_CANDIDATE==\"$S_GUID_CANDIDATE\""
            echo "GUID=='95677427-e806-45ce-8334-b22360a04ae7'"
            echo ""
            #--------
            exit 1 # exiting with an error
        fi
    else
        if [ -d "$S_FP" ]; then
            echo ""
            if [ -h "$S_FP" ]; then
                echo "The symlink to an existing folder "
            else
                echo "The folder "
            fi
            echo ""
            echo "    $S_FP "
            echo ""
            printf "exists, but "
            if [ "$SB_OPTIONAL_BAN_SYMLINKS" == "t" ]; then
                echo -e "a\e[31m file is expected\e[39m."
            else
                echo -e "a\e[31m file or a symlink to a file is expected\e[39m."
            fi
            echo "S_GUID_CANDIDATE==\"$S_GUID_CANDIDATE\""
            echo "GUID=='e5165ced-bdc0-45fc-9134-b22360a04ae7'"
            echo ""
            #--------
            exit 1 # exiting with an error
        else
            if [ "$SB_OPTIONAL_BAN_SYMLINKS" == "t" ]; then
                if [ -h "$S_FP" ]; then
                    echo ""
                    echo "The "
                    echo ""
                    echo "    $S_FP"
                    echo ""
                    echo -e "is a symlink to a file, but a\e[31m file is expected\e[39m."
                    echo "S_GUID_CANDIDATE==\"$S_GUID_CANDIDATE\""
                    echo "GUID=='670e6131-84a2-4ecb-b134-b22360a04ae7'"
                    echo ""
                    #--------
                    exit 1 # exiting with an error
                fi
            fi
        fi
    fi
} # func_mmmv_assert_file_exists_t1

#--------------------------------------------------------------------------

func_mmmv_assert_folder_exists_t1() {
    local S_FP="$1"
    local S_GUID_CANDIDATE="$2"
    local SB_OPTIONAL_BAN_SYMLINKS="$3" # domain: {"t", "f", ""} default: "f"
                                        # is the last formal parameter
                                        # in stead of the S_GUID_CANDIDATE,
                                        # because that way this function is
                                        # backwards compatible with
                                        # an earlier version of this
                                        # function.
    #----------------------------------------------------------------------
    local SB_LACK_OF_PARAMETERS="f"
    if [ "$S_FP" == "" ]; then
        SB_LACK_OF_PARAMETERS="t"
    fi
    if [ "$S_GUID_CANDIDATE" == "" ]; then
        SB_LACK_OF_PARAMETERS="t"
    fi
    if [ "$SB_LACK_OF_PARAMETERS" == "t" ]; then
        echo ""
        echo -e "\e[31mThe code that calls this function is flawed. \e[39m"
        echo "This function requires 2 parameters, which are "
        echo "S_FP, S_GUID_CANDIDATE, and it has an optional 3. parameter, "
        echo "which is SB_OPTIONAL_BAN_SYMLINKS."
        if [ "$S_GUID_CANDIDATE" != "" ]; then
            echo "S_GUID_CANDIDATE=='$S_GUID_CANDIDATE'"
        fi
        echo "GUID=='5b12ed95-c9c1-42b8-bb34-b22360a04ae7'"
        echo ""
        #--------
        exit 1 # exiting with an error
    else
        if [ "$SB_LACK_OF_PARAMETERS" != "f" ]; then
            echo -e "\e[31mThis code is flawed. \e[39m"
            echo "GUID=='2281674e-d543-4bc3-b134-b22360a04ae7'"
            #--------
            exit 1 # exiting with an error
        fi
    fi
    #------------------------------
    if [ "$SB_OPTIONAL_BAN_SYMLINKS" == "" ]; then
        # The default value of the
        SB_OPTIONAL_BAN_SYMLINKS="f"
        # must be backwards compatible with the
        # version of this function, where
        # symlinks to folders were treated as actual folders.
    else
        if [ "$SB_OPTIONAL_BAN_SYMLINKS" != "t" ]; then
            if [ "$SB_OPTIONAL_BAN_SYMLINKS" != "f" ]; then
                echo ""
                echo "The "
                echo ""
                echo "    SB_OPTIONAL_BAN_SYMLINKS==\"$SB_OPTIONAL_BAN_SYMLINKS\""
                echo ""
                echo "but the valid values for the SB_OPTIONAL_BAN_SYMLINKS"
                echo "are: \"t\", \"f\", \"\"."
                echo "S_GUID_CANDIDATE=='$S_GUID_CANDIDATE'"
                echo "GUID=='7e430904-2e1f-4933-a334-b22360a04ae7'"
                echo ""
                #--------
                exit 1 # exiting with an error
            fi
        fi
    fi
    #------------------------------
    if [ ! -e "$S_FP" ]; then
        if [ -h "$S_FP" ]; then
            echo ""
            echo "The path "
            echo ""
            echo "    $S_FP "
            echo ""
            echo -e "points to a\e[31m broken symlink\e[39m, but "
            if [ "$SB_OPTIONAL_BAN_SYMLINKS" == "t" ]; then
                echo -e "a\e[31m folder is expected\e[39m."
            else
                echo -e "a\e[31m folder or a symlink to a folder is expected\e[39m."
            fi
            echo "S_GUID_CANDIDATE==\"$S_GUID_CANDIDATE\""
            echo "GUID=='325f7be5-a178-40e1-9634-b22360a04ae7'"
            echo ""
            #--------
            exit 1 # exiting with an error
        else
            echo ""
            if [ "$SB_OPTIONAL_BAN_SYMLINKS" == "t" ]; then
                echo "The folder "
            else
                echo "The folder or a symlink to a folder "
            fi
            echo ""
            echo "    $S_FP "
            echo ""
            echo -e "\e[31mdoes not exist\e[39m."
            echo "S_GUID_CANDIDATE==\"$S_GUID_CANDIDATE\""
            echo "GUID=='162ab427-24b1-4d45-9234-b22360a04ae7'"
            echo ""
            #--------
            exit 1 # exiting with an error
        fi
    else
        if [ ! -d "$S_FP" ]; then
            echo ""
            if [ -h "$S_FP" ]; then
                echo "The symlink to an existing file "
            else
                echo "The file "
            fi
            echo ""
            echo "    $S_FP "
            echo ""
            printf "exists, but "
            if [ "$SB_OPTIONAL_BAN_SYMLINKS" == "t" ]; then
                echo -e "a\e[31m folder is expected\e[39m."
            else
                echo -e "a\e[31m folder or a symlink to a folder is expected\e[39m."
            fi
            echo "S_GUID_CANDIDATE==\"$S_GUID_CANDIDATE\""
            echo "GUID=='7f39474d-051c-448b-b434-b22360a04ae7'"
            echo ""
            #--------
            exit 1 # exiting with an error
        else
            if [ "$SB_OPTIONAL_BAN_SYMLINKS" == "t" ]; then
                if [ -h "$S_FP" ]; then
                    echo ""
                    echo "The "
                    echo ""
                    echo "    $S_FP"
                    echo ""
                    echo -e "is a symlink to a folder, but a\e[31m folder is expected\e[39m."
                    echo "S_GUID_CANDIDATE==\"$S_GUID_CANDIDATE\""
                    echo "GUID=='548f3e3b-2be0-4eca-8534-b22360a04ae7'"
                    echo ""
                    #--------
                    exit 1 # exiting with an error
                fi
            fi
        fi
    fi
} # func_mmmv_assert_folder_exists_t1

#--------------------------------------------------------------------------

func_mmmv_exit_if_not_on_path_t2() { # S_COMMAND_NAME
    local S_COMMAND_NAME="$1"
    #----------------------------------------------------------------------
    local S_LOCAL_VARIABLE="`which $S_COMMAND_NAME 2> /dev/null`"
    if [ "$S_LOCAL_VARIABLE" == "" ]; then
        echo ""
        echo -e "\e[31mCommand \"$S_COMMAND_NAME\" could not be found from the PATH. \e[39m"
        echo "The execution of this Bash script is aborted."
        echo "GUID=='21ea4cb4-2765-444b-8134-b22360a04ae7'"
        echo ""
        exit 1;
    fi
} # func_mmmv_exit_if_not_on_path_t2

#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
#          Start of the applicationspecific code.
#--------------------------------------------------------------------------

func_main(){
    #----------------------------------------------------------------------
    func_mmmv_exit_if_not_on_path_t2 "find"
    func_mmmv_exit_if_not_on_path_t2 "grep"
    #--------
    if [ "`uname -a | grep -i linux `" == "" ]; then
        echo ""
        echo -e "This script \e[31mhas been tested only on Linux\e[39m."
        echo "It MIGHT work also on BSD, but it has not been tested on BSD."
        echo "Exiting without doing anything."
        echo "GUID=='d66a53da-3502-47b0-8f34-b22360a04ae7'"
        echo ""
        exit 1;
    fi
    #--------
    func_mmmv_exit_if_not_on_path_t2 "zet" # Zettair Text Search Engine
    func_mmmv_init_s_timestamp_if_not_inited_t1
    func_settings
    #----------------------------------------------------------------------
    func_mmmv_assert_folder_exists_t1 \
        "$S_FP_FOLDER_WITH_INDEXABLE_TXT" \
        "dc7f6229-5d60-42eb-b234-b22360a04ae7"
    func_mmmv_assert_folder_exists_t1 \
        "$S_FP_FOLDER_WITH_INDICES" \
        "55afff15-7f81-4764-a134-b22360a04ae7"
    #----------------------------------------------------------------------
    cd "$S_FP_FOLDER_WITH_INDICES"
    func_mmmv_assert_error_code_zero_t2 "$?" \
        "7408e255-b0a3-4d13-9634-b22360a04ae7"
    rm -f ./inde*
    func_mmmv_assert_error_code_zero_t2 "$?" \
        "3623f03d-5b49-436b-9134-b22360a04ae7"
    func_mmmv_wait_and_sync_t1
    #----------------------------------------------------------------------
    local S_TMP_0="_$RANDOM$S_TIMESTAMP"
    local S_TMP_1=".txt"
    local S_FP_LIST_OF_INDEXABLE_FILES="/tmp/temporary_file_$S_TMP_0$S_TMP_1"
    printf '' > $S_FP_LIST_OF_INDEXABLE_FILES
    func_mmmv_assert_error_code_zero_t2 "$?" \
        "4cfbb952-f813-423d-b934-b22360a04ae7"
    #----------------------------------------------------------------------
    nice -n 5 find $S_FP_FOLDER_WITH_INDEXABLE_TXT/ \
        -maxdepth 20  -type f | \
        grep -i -E '[.]((txt)|(md)|(yml))$' > $S_FP_LIST_OF_INDEXABLE_FILES
    func_mmmv_assert_error_code_zero_t2 "$?" \
        "e59e1aad-5982-4d84-9134-b22360a04ae7"
    func_mmmv_wait_and_sync_t1
    func_mmmv_assert_file_exists_t1 \
        "$S_FP_LIST_OF_INDEXABLE_FILES" \
        "4cf5695a-725c-42a7-8234-b22360a04ae7"
    #----------------------------------------------------------------------
    cd "$S_FP_FOLDER_WITH_INDICES"
    func_mmmv_assert_error_code_zero_t2 "$?" \
        "b3bc5aaf-c2f8-497a-b934-b22360a04ae7"
    nice -n 10 zet -i --big-and-fast --file-list "$S_FP_LIST_OF_INDEXABLE_FILES"
    func_mmmv_assert_error_code_zero_t2 "$?" \
        "11085428-d496-4974-a434-b22360a04ae7"
    #rm -f "$S_FP_LIST_OF_INDEXABLE_FILES"
    #----------------------------------------------------------------------
} # func_main
func_main

#--------------------------------------------------------------------------
exit 0
#==========================================================================
# S_VERSION_OF_THIS_FILE="6a8fab84-e09e-4d01-9a34-b22360a04ae7"
#==========================================================================
