#!/usr/bin/env bash
#==========================================================================
# Initial author of this file: Martin.Vahi@softf1.com
# This file is in public domain.
#
# The following line is a spdx.org license label line:
# SPDX-License-Identifier: 0BSD
#==========================================================================
if [ "$S_FP_DATA_COLLECTION_ROOT" == "" ]; then
    echo ""
    echo -e "\e[31mCode in a set of Bash scripts is flawed\e[39m."
    echo "The S_FP_DATA_COLLECTION_ROOT is expected to be "
    echo "initiated at ./../../update_reading_copy.bash ."
    echo "GUID=='d9a26325-7259-473f-845b-f141b061b8e7'"
    echo ""
    exit 1
fi
#--------------------------------------------------------------------------
S_FP_0="$S_FP_DATA_COLLECTION_ROOT/bonnet/rsync_based_backups_creator_modified"
if [ "$S_FP_ORIG" == "" ]; then
    S_FP_ORIG="`pwd`"
fi
I_NUMBER_OF_BACKUP_VERSIONS=1
S_FP_FULL_PATH_2_A_FOLDER_OR_A_FILE_THAT_WILL_BE_BACKED_UP="$S_FP_DATA_COLLECTION_ROOT/archival_copy"
#--------------------------------------------------------------------------
cd $S_FP_0
source $S_FP_0/bonnet/engine_part_1.bash 
wait ; sync ; wait
cd $S_FP_ORIG
exit 0
#==========================================================================
# S_VERSION_OF_THIS_FILE="50540c38-7e81-4f0e-a55b-f141b061b8e7"
#==========================================================================
