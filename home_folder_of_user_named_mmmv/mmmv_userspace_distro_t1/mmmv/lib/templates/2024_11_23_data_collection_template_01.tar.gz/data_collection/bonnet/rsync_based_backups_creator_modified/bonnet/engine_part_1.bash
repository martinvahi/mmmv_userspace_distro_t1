#!/usr/bin/env bash 
XXX=$(cat<< 'txt1' #=======================================================

 The MIT license from the 
 http://www.opensource.org/licenses/mit-license.php

 Copyright (c) 2012, martin.vahi@softf1.com that has an
 Estonian personal identification code of 38108050020.

 Permission is hereby granted, free of charge, to any
 person obtaining a copy of this software and associated
 documentation files (the "Software"), to deal in the Software
 without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense,
 and/or sell copies of the Software, and to permit persons
 to whom the Software is furnished to do so, subject to the
 following conditions:

 The above copyright notice and this permission notice shall
 be included in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
 KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE AUTHORS
 OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 The following line is a spdx.org license label line:
 SPDX-License-Identifier: MIT

===========================================================================

 Working directory verifications are not necessary here, because
 if the ../bonnet did not exist, the ../create_backup.bash would
 throw an exception, etc. 

 The I_NUMBER_OF_BACKUP_VERSIONS is 
 initiated within the ./../creat_backup.bash 

txt1
)#-------------------------------------------------------------------------
S_FP_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
S_FP_ORIG="`pwd`"

if [ -e "$S_FP_MMMV_BASH_BOILERPLATE_T6" ]; then
    if [ -d "$S_FP_MMMV_BASH_BOILERPLATE_T6" ]; then
        echo ""
        echo "A folder with the path of "
        echo ""
        echo "    S_FP_MMMV_BASH_BOILERPLATE_T6==$S_FP_MMMV_BASH_BOILERPLATE_T6"
        echo ""
        echo "exists, but a file is expected."
        echo "GUID=='ac6fee40-0ae3-4016-a581-c0d2b061b8e7'"
        echo ""
    else
        source "$S_FP_MMMV_BASH_BOILERPLATE_T6"
    fi
else
    echo ""
    echo "A file with the path of "
    echo ""
    echo "    S_FP_MMMV_BASH_BOILERPLATE_T6==$S_FP_MMMV_BASH_BOILERPLATE_T6"
    echo ""
    echo "could not be found."
    echo "GUID=='12779fa8-46ba-4645-8181-c0d2b061b8e7'"
    echo ""
fi

#-------------------------------------------------------------------------

func_mmmv_exit_if_not_on_path_t2 "ruby"
#func_mmmv_exit_if_not_on_path_t2 "grep"
func_mmmv_exit_if_not_on_path_t2 "rsync"
#func_mmmv_exit_if_not_on_path_t2 "nice"

#-------------------------------------------------------------------------
PERIOD_MINUS_ONE=$((I_NUMBER_OF_BACKUP_VERSIONS-1))

S_BACKUP_FOLDER_NAME_PREFIX="backup_v_"
S_BACKUP_FOLDER_FULL_PATH_PREFIX="`pwd`/backups/$S_BACKUP_FOLDER_NAME_PREFIX"

for i in `seq 0 $PERIOD_MINUS_ONE`; do 
    mkdir -p $S_BACKUP_FOLDER_FULL_PATH_PREFIX$i
    func_mmmv_assert_error_code_zero_t1 "$?" \
        "8fbbc41a-5b0b-4af4-b581-c0d2b061b8e7"
done

BACKUP_COPY_NUMBER=`ruby ./bonnet/folder_selector.rb $PERIOD_MINUS_ONE`
S_FULL_PATH_TO_THE_BACKUP_FOLDER="$S_BACKUP_FOLDER_FULL_PATH_PREFIX$BACKUP_COPY_NUMBER"

echo ""
#echo "The backup copy will be placed to folder: $S_BACKUP_FOLDER_NAME_PREFIX$BACKUP_COPY_NUMBER"
echo "Starting to run rsync .."
echo ""
func_mmmv_wait_and_sync_t1 # For network drives and USB drives.
# sleep 5s

#--------------------------------------------------------------------------
S_RSYNC_SKIP_COMPRESS_ARG=" --skip-compress=jpg/jpeg/jp2/j2k/jpf/jpx/jpm/mj2/mp[34]/m4p/m4v/mpg/mpeg/m2v/svi/3gp/3g2/amv/7z/s7z/z/rar/rk/bz2/mar/zz/xz/lz/lzma/lha/lzh/lzx/tar/gz/tgz/tbz2/tlz/txz/taz/tz/tzma/lzo/rz/rzip/lrzip/sfark/sz/alz/apk/arc/b1/b6z/paq6/paq7/pit/shk/sit/sitx/sqx/zoo/zpaq/xar/kgb/jar/zip/zipx/arj/stblob/webm/ogg/ogv/spx/mov/qt/avi/mts/m2ts/wmv/rm/rmvb/flv/f4v/f4p/f4a/f4b/swf/mkv/vob/mng/msi/pkg/iso/img/deb/rpm/dvd/dmg/ova/vdi/vmdk/vhd "
# The S_RSYNC_SKIP_COMPRESS_ARG makes more sense, when the rsync logs in
# to some remote computer, which it does not do at this script, but this
# script here is a nice place for storing the list of file extensions
# of files that probably can not be compressed "that much" and this
# file also serves as a test case for the syntax of the list of file
# extensions.
S_RSYNC_COMMAND_PREFIX="nice -n15 rsync -avz $S_RSYNC_SKIP_COMPRESS_ARG --delete "

$S_RSYNC_COMMAND_PREFIX \
    $S_FP_FULL_PATH_2_A_FOLDER_OR_A_FILE_THAT_WILL_BE_BACKED_UP \
    $S_FULL_PATH_TO_THE_BACKUP_FOLDER
S_TMP_0="$?"
if [ "$S_TMP_0" != "0" ]; then
    echo ""
    echo "The program rsync exited with an error code of $S_TMP_0."
    echo "GUID='4acc52e5-b593-42cb-8281-c0d2b061b8e7'"
    echo ""
    exit $S_TMP_0
fi
func_mmmv_wait_and_sync_t1 # Motivated by the use of external USB drives/sticks.
exit 0
#==========================================================================
# S_VERSION_OF_THIS_FILE="11b39cf2-e5ac-4ecc-8e81-c0d2b061b8e7"
#==========================================================================

