#!/usr/bin/env bash 

`which php5` the_web_app.php $1

