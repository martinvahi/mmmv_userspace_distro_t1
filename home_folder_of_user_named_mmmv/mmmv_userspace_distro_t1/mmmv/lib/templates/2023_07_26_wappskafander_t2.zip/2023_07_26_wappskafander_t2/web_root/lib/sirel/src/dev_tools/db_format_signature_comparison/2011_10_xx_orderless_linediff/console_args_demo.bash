#!/bin/bash


ruby -Ku ./orderless_linediff.rb -f ./test_data/old.txt ./test_data/new.txt ;

