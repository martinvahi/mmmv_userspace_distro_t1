#!/usr/bin/env ruby
#==========================================================================
# Ruby language version related normalization:
#--------------------------------------------------------------------------
# Most Ruby versions prior to Ruby version 3.2.0
# had that method. This code makes old code that
# worked with those older Ruby versions
# work with the Ruby version 3.2.0 .
if !defined? File.exists?
   def File.exists? x
      b=File.exist? x
      return b
   end # File.exists?
end # if
# Ruby 2.4.0 introduced a change, where
# classes Fixnum and Bignum were deprecated
# their use triggered a warning text to stderr
# and their common parent class, Integer,
# was expected to be used instead of them.
# Ruby version 2.7.2 removed the warning from the stderr.
# Ruby version 3.2.0 missed the classes, Fixnum and Bignum.
# The following 2 if-clauses keep the old code working.
if !defined? Fixnum
   Fixnum=Integer
end # if
if !defined? Bignum
   Bignum=Integer
end # if
#--------------------------------------------------------------------------
require 'pathname'
ob_pth_0=Pathname.new(__FILE__).realpath.parent
KIBUVITS_HOME=ob_pth_0.to_s+"/kibuvits_ruby_library"
require  KIBUVITS_HOME+"/src/include/kibuvits_boot.rb"

require  KIBUVITS_HOME+"/src/include/wrappers/kibuvits_ImageMagick.rb"
#--------------------------------------------------------------------------

s_fp_orig=ob_pth_0.parent.to_s+"/originals"
s_fp_dest=ob_pth_0.parent.to_s+"/conversion_result"

#------------------

i_len=ARGV.size
if i_len!=1
   kibuvits_throw("ARGV.size!=1 "+
   "\nGUID='5f8eb06f-c426-4fd0-92b5-937211716ae7'")
end # if
s_max_edge_length_candidate=ARGV[0]
if kibuvits_b_not_a_whole_number_t1(s_max_edge_length_candidate)
   kibuvits_throw("\nLength candidate must be "+
   "a string representaton of a postive whole number. "+
   "\ns_max_edge_length_candidate=="+ s_max_edge_length_candidate+
   "\nGUID='bfbd104e-33fe-42ac-b4b5-937211716ae7'")
end # if
i_max_edge_length=s_max_edge_length_candidate.to_i
if (i_max_edge_length<1)
   kibuvits_throw("\nImage side length in number of pixels "+
   "must be greater than 0. "+
   "\ni_max_edge_length=="+ i_max_edge_length.to_s+
   "\nGUID='9912fb8a-b00f-46c3-acb5-937211716ae7'")
end # if

#------------------

msgcs=Kibuvits_msgc_stack.new
Kibuvits_ImageMagick.apply_width_and_height_limits(
i_max_edge_length,i_max_edge_length,s_fp_dest,s_fp_orig,msgcs)
puts msgcs.to_s if msgcs.b_failure

#==========================================================================
