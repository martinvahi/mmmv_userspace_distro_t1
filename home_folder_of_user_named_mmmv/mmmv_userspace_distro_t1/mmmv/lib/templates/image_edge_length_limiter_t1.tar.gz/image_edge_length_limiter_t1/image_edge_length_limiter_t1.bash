#!/usr/bin/env bash

S_TMP_0="`which identify`"
if [ "$S_TMP_0" == "" ]; then
       echo ""
       echo "This application requires the ImageMagick console tool,"
       echo "'identify' to be on the PATH, but it isn't on the PATH."
       echo "GUID=='5c008965-2f28-4e21-a327-b01030d1c3e7'"
       echo ""
       exit 1 # exit with an error
fi
S_TMP_0="`which convert`"
if [ "$S_TMP_0" == "" ]; then
       echo ""
       echo "This application requires the ImageMagick console tool,"
       echo "'convert' to be on the PATH, but it isn't on the PATH."
       echo "GUID=='84655687-22d6-4bcc-b336-b01030d1c3e7'"
       echo ""
       exit 1 # exit with an error
fi

S_FP_RUBY=`which ruby`

if [ "$S_FP_RUBY" == "" ]; then
       echo ""
       echo "This application requires the 'ruby' to be on the PATH,"
       echo "but it isn't on the PATH."
       echo "GUID=='14d1a384-8c2a-4cc6-a116-b01030d1c3e7'"
       echo ""
       exit 1 # exit with an error
fi
#------------------------------------------------------------
# At Ruby verson 2.4.0 the class Fixnum was obsoleted,
# replaced with its former parent class, Integer.
# Ruby version 2.4.x gives a warning on Fixnum.
S_TMP_0="`ruby -v`"
SB_SELECT_IMPLEMENTATION_THAT_USES_PRE_RUBY_v_2_4_x_="t"
SB_UNSUPPORTED_RUBY_VERSION_NOT_YET_DETECTED="t"
SB_SUPPORTED_RUBY_VERSION_DETECTED="f"
#--------
S_TMP_1="`echo $S_TMP_0 | grep -E ^ruby\ 0`"
if [ "$S_TMP_1" != "" ]; then
    SB_UNSUPPORTED_RUBY_VERSION_NOT_YET_DETECTED="f" # Ruby verson 0.x
fi
#--------
if [ "$SB_UNSUPPORTED_RUBY_VERSION_NOT_YET_DETECTED" == "t" ]; then
    S_TMP_1="`echo $S_TMP_0 | grep -E ^ruby\ 1`"
    # From Ruby 1.x.x only the Ruby 1.9.x is supported.
    if [ "$S_TMP_1" != "" ]; then # the Ruby 1.x.x series
        S_TMP_1="`echo $S_TMP_0 | grep -E ^ruby\ 1.9`"
        SB_UNSUPPORTED_RUBY_VERSION_NOT_YET_DETECTED="t"
        if [ "$S_TMP_1" != "" ]; then
            SB_UNSUPPORTED_RUBY_VERSION_NOT_YET_DETECTED="f"
            SB_SUPPORTED_RUBY_VERSION_DETECTED="t"
        fi
    fi
fi
#--------
if [ "$SB_UNSUPPORTED_RUBY_VERSION_NOT_YET_DETECTED" == "t" ]; then
    if [ "$SB_SUPPORTED_RUBY_VERSION_DETECTED" == "f" ]; then
        S_TMP_1="`echo $S_TMP_0 | grep -E ^ruby\ 2`"
        # The implementation choice goes between
        # Ruby version 2.4.0 and everything that is earlier than that.
        if [ "$S_TMP_1" != "" ]; then # the Ruby 2.x.x series
            S_TMP_1="`echo $S_TMP_0 | grep -E ^ruby\ 1.9`"
            SB_UNSUPPORTED_RUBY_VERSION_NOT_YET_DETECTED="t"
            if [ "$S_TMP_1" != "" ]; then
                SB_UNSUPPORTED_RUBY_VERSION_NOT_YET_DETECTED="f"
                SB_SUPPORTED_RUBY_VERSION_DETECTED="t"
            fi
        fi
    fi
fi
#--------

if [ "$SB_UNSUPPORTED_RUBY_VERSION_NOT_YET_DETECTED" != "t" ]; then
       echo ""
       echo "The ruby version "
       echo ""
       echo "    $S_TMP_0"
       echo ""
       echo "is not supported by this script. "
       echo "Aborting without doing anything."
       echo "GUID=='b1ec30a1-1ac7-436e-b326-b01030d1c3e7'"
       echo ""
       exit 1 # exit with an error
fi

#------------------------------------------------------------

S_FP_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
S_FP_CORE="$S_FP_DIR/bonnet/image_edge_length_limiter_t1_core.rb"
S_FP_origin="$S_FP_DIR/originals"
S_FP_destination="$S_FP_DIR/conversion_result"
S_FP_FUNC_X_IS_GREATER_THAN_0="$S_FP_DIR/bonnet/func_x_is_greater_than_zero.rb"

#------------------------------------------------------------

mkdir -p $S_FP_origin
chmod -f -R 0700 $S_FP_origin

mkdir -p $S_FP_destination
chmod -f -R 0700 $S_FP_destination
rm -fr $S_FP_destination
mkdir -p $S_FP_destination

#------------------------------------------------------------
S_EDGE_MAX_WIDTH="$1"

fun_get_edge_max_width () {
    local SB_ASK="t"
    local S_CMD="$S_FP_RUBY $S_FP_FUNC_X_IS_GREATER_THAN_0 "
    local S_EMW="$S_EDGE_MAX_WIDTH"
    local SB_FUNC_X_IS_GREATER_THAN_0_OUTPUT="f"
    while [ "$SB_ASK" == "t" ];
    do
           # This version is a misfortunate hack.
           # The correct version would have all of the UI
           # related code at the Ruby side.
           if [ "$S_EMW" != "" ]; then
                   SB_FUNC_X_IS_GREATER_THAN_0_OUTPUT=`$S_CMD $S_EMW`;
           fi
           if [ "$SB_FUNC_X_IS_GREATER_THAN_0_OUTPUT" == "t" ]; then
                   SB_ASK="f"
           else
                   echo ""
                   read -p "Please enter the image edge maximum length in pixels: " S_EMW
                   echo ""
           fi
    done
    S_EDGE_MAX_WIDTH="$S_EMW"
} # fun_tere

fun_get_edge_max_width
#echo "$S_EDGE_MAX_WIDTH px"

#------------------------------------------------------------
echo ""
echo "Converting ... "
$S_FP_RUBY $S_FP_CORE $S_EDGE_MAX_WIDTH # $2 $3 $4 $5 $6 $7 $8 $9
echo "Conversion process stopped."
unset S_EDGE_MAX_WIDTH

exit 0 # No errors.

