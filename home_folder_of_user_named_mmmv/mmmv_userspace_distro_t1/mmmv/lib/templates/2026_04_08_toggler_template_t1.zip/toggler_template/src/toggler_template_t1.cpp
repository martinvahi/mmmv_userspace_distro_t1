/*=========================================================================
 Author of this file: <INCOMPLETE>
 Initial author of this file: Martin.Vahi@softf1.com
 This file is in public domain.
 The following line is a spdx.org license label line:
 SPDX-License-Identifier: 0BSD
=========================================================================*/
#include <filesystem>
#include <fstream>
#include <iostream>

int main() {
    // As primitive, as possible. Intentionally.
    std::string s_fp_flagfile="/opt/andmekettad/RAM_200MiB_01/flagfiles/ts3b_flagfile_keyboardlayout_01.txt";
    if (std::ifstream(s_fp_flagfile)) { // File exists and is readable
        std::filesystem::remove(s_fp_flagfile);
        printf("%s","ee" );
    } else {
        std::ofstream file(s_fp_flagfile);
        printf("%s","us" );
    }
}

/*=========================================================================
S_VERSION_OF_THIS_FILE="6567201d-f884-42a7-b341-c01190804ae7"
=========================================================================*/
