#!/usr/bin/env bash
#==========================================================================
# Initial author of this file: Martin.Vahi@softf1.com
# This file is in public domain.
#
# The following line is a spdx.org license label line:
# SPDX-License-Identifier: 0BSD
#==========================================================================
S_FP_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
S_FP_ORIG="`pwd`"
#--------------------------------------------------------------------------
export S_FP_MMMV_BASH_BOILERPLATE_T6="$S_FP_DIR/bonnet/lib/2024_07_13_mmmv_bash_boilerplate_t6/mmmv_bash_boilerplate_t6.bash"
if [ -e "$S_FP_MMMV_BASH_BOILERPLATE_T6" ]; then
    if [ -d "$S_FP_MMMV_BASH_BOILERPLATE_T6" ]; then
        echo ""
        echo "A folder with the path of "
        echo ""
        echo "    S_FP_MMMV_BASH_BOILERPLATE_T6==$S_FP_MMMV_BASH_BOILERPLATE_T6"
        echo ""
        echo "exists, but a file is expected."
        echo "GUID=='52146982-97e3-4ef7-b34a-51616071b8e7'"
        echo ""
        exit 1
    else
        source "$S_FP_MMMV_BASH_BOILERPLATE_T6"
    fi
else
    echo ""
    echo "A file with the path of "
    echo ""
    echo "    S_FP_MMMV_BASH_BOILERPLATE_T6==$S_FP_MMMV_BASH_BOILERPLATE_T6"
    echo ""
    echo "could not be found."
    echo "GUID=='21b597d1-223d-413f-875a-51616071b8e7'"
    echo ""
    exit 1
fi
#--------------------------------------------------------------------------

func_main(){ # runs rsync
    #----------------------------------------------------------------------
    export S_FP_DATA_COLLECTION_ROOT="$S_FP_DIR"
    local S_FP_0="$S_FP_DIR/bonnet/rsync_based_backups_creator_modified"
    cd "$S_FP_0"
    func_mmmv_assert_error_code_zero_t1 "$?" \
        "3b889192-2d6a-4614-ac1a-51616071b8e7"
    nice -n 5 bash ./main_and_settings.bash
    func_mmmv_assert_error_code_zero_t1 "$?" \
        "4e30e692-835b-442f-b74a-51616071b8e7"
    func_mmmv_wait_and_sync_t1
    cd $S_FP_ORIG
    func_mmmv_assert_error_code_zero_t1 "$?" \
        "1d9706a3-5dce-413e-be5a-51616071b8e7"
    #----------------------------------------------------------------------
    local SB_0="f"
    local S_FP_1="$S_FP_DIR/reading_copy"
    if [ -e "$S_FP_1" ]; then 
        if [ ! -d "$S_FP_1" ]; then
            echo ""
            echo "The "
            echo ""
            echo "    $S_FP_1"
            echo ""
            if [ -h "$S_FP_1" ]; then
                echo -e "is a symlink to a file, but a\e[31m symlink to a folder is expected\e[39m."
            else
                echo -e "is a file, but a\e[31m symlink to a folder is expected\e[39m."
            fi
            echo "GUID=='28d33622-153a-46a7-905a-51616071b8e7'"
            echo ""
            exit 1
        fi
        if [ -h "$S_FP_1" ]; then
            SB_0="t"
        else
            echo ""
            echo "The "
            echo ""
            echo "    $S_FP_1"
            echo ""
            echo -e "is a folder, but a\e[31m symlink to a folder is expected\e[39m."
            echo "GUID=='51f591ec-cd54-484b-b619-51616071b8e7'"
            echo ""
            exit 1
        fi
    else
        if [ -h "$S_FP_1" ]; then # a broken symlink
            echo ""
            echo "The "
            echo ""
            echo "    $S_FP_1"
            echo ""
            echo -e "is a broken symlink, but "
            echo -e "a\e[31m symlink to a folder is expected\e[39m."
            echo "GUID=='e5313fdd-ff02-4a85-9a29-51616071b8e7'"
            echo ""
            exit 1
        fi
    fi
    #----------------------------------------------------------------------
    echo ""
    if [ "$SB_0" == "t" ]; then
        echo -e "\e[32mReading copy updated\e[39m at"
        echo "    $S_FP_1"
    else
        echo -e "\e[32mReading copy updated\e[39m."
    fi
    echo ""
    exit 0
    #----------------------------------------------------------------------
} # func_main
func_main

#==========================================================================
# S_VERSION_OF_THIS_FILE="05aa9368-a48d-41b1-8919-51616071b8e7"
#==========================================================================
