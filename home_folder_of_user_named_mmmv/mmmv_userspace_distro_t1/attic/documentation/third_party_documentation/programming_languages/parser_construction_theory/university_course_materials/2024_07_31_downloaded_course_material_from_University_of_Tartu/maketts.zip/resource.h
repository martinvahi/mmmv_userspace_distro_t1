//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Two.rc
//
#define IDR_MENU1                       101
#define ID_LEARNING                     40001
#define ID_TRIGOL                       40002
#define ID_FORM                         40003
#define ID_GRAMMAR_LEARNING             40004
#define ID_WORD                         40005
#define ID_PROG                         40006
#define ID_FORMULA                      40007
#define ID_CONSTR                       40008
#define ID_PARS                         40009
#define ID_INTER                        40010
#define ID_COMP                         40011
#define ID_OPT                          40012
#define ID_EX                           40013
#define ID_FINT                         40014
#define ID_PARSE                        40015
#define ID_PROGRAM                      40016
#define ID_INTERP                       40017
#define ID_SIMPLE                       40018
#define ID_TRANS                        40019
#define ID_SHGR                         40020
#define ID_LOG                          40021
#define ID_GRAMMAR                      40022
#define ID_CONSTRUCTOR                  40023
#define ID_TABLES                       40024
#define ID_FILES                        40025
#define ID_CR                           40026
#define ID_P                            40027
#define ID_TRII                         40028
#define ID_TRIC                         40029
#define ID_TWO                          40030
#define ID_PARSER                       40031
#define ID_HEADER                       40032
#define ID_G                            40033

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40034
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
