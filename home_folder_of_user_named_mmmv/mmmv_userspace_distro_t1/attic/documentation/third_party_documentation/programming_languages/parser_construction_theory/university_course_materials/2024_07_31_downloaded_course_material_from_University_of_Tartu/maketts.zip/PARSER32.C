/* parser32.c  May 2001 */
#include <io.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include "two32.h"

int NR;
FILE *rdf=NULL;

void ExiT(char *t){
	fprintf(Logi,"%s<BR>",t);
	fprintf(Logi,"</BODY></HTML>");
	fflush(Logi);
	fclose(Logi);
	printf("%s",t);
	getchar();
	abort();
}

void blue(char *t){
	fprintf(Logi,"<FONT COLOR=\"0000FF\">%s</FONT>",t);
}       

void green(char *t){
	fprintf(Logi,"<FONT COLOR=\"008000\">%s</FONT>",t);
}       

void red(char *t){
	fprintf(Logi,"<FONT COLOR=\"FF0000\">%s</FONT>",t);
}       

void pset(int x,int y){
	blue("{");
	fprintf(Logi,"%s",T[x]);
	blue(",");
	fprintf(Logi,"%s",T[y]);
	blue("}");
}

void print_cxt(char **L){
	int i,j;
	char *rc;
	fprintf(Logi,"cxt: L=%p<BR>",L); fflush(Logi);
	for(i=tnr+1;i<nr+1;i++){
		rc=L[i];
		if(rc!=(char *)NULL){
			fprintf(Logi,"cxt: nr=%d i=%d rc=%p<BR>",nr,i,rc); 
			fflush(Logi);
			for(j=0;j<tnr+1;j++){
				if(rc[j]==1) pset(i,j);
				}
			}
		}
	fprintf(Logi,"<BR>"); fflush(Logi);     
}

void print_cxtp(char **L){
int i;
	char *rc;
	for(i=1;i<nr+1;i++){
		rc=L[i];
		if(rc!=(char *)NULL) fprintf(Logi,"L[%d]=%p<BR>",i,rc);
		}
}

void print_DEP(void){
char **L;
char *rc;
int i,j,k;
	for(i=tnr+1;i<nr+1;i++){
		L=DEP[i];
		if(L!=(char **)NULL){
			fprintf(Logi,"<BR>DEP[%d]=%p<BR>",i,L);
			for(j=0;j<tnr+1;j++){
				rc=L[j];
				if(rc!=(char *)NULL){
					fprintf(Logi,"L[%d]=%p<BR>",j,rc);
					for(k=0;k<tnr+1;k++)
					   fprintf(Logi,"rc[%d]=%d ",k,rc[k]);
					fprintf(Logi,"<BR>");
					}
				}
			}
		}
}

void print_all_cxt(void){
char **L;
int i;
	for(i=tnr+1;i<nr+1;i++){
		L=DEP[i];
		if(L!=(char **)NULL){
			fprintf(Logi,"<BR>dependent context of %s:<BR>",T[i]);
			print_cxt(L);
			fprintf(Logi,"<BR>");
			}
		}
}

void print_all_cxtp(void){
char **L;
int i;
	for(i=tnr+1;i<nr+1;i++){
		L=DEP[i];
		if(L!=(char **)NULL){
			fprintf(Logi,"DEP[%d]=%p<BR>",i,L);
			print_cxtp(L);
			}
		}
}

void print_L(struct h *CP){
int i,j;
char *r;
	fprintf(Logi,"<BR>L: P%2d `%s' -&gt ",CP->P,T[CP->NT]); 
	for(j=0;j<CP->n;j++){
		i=CP->d[j];
		r=T[i];
		if(i<tnr+1) fprintf(Logi,"%s ",r);
		else fprintf(Logi,"`%s' ",r);
		}
	fprintf(Logi,"<BR>");
	fflush(Logi);
}

void print_h(struct h *t){
	int i,j;
	char *r;
	fprintf(Logi,"<BR>P=%d `%s' -&gt ",t->P,T[t->NT]); 
	for(i=0;i<t->n;i++){
		j=t->d[i];
		r=T[j];
		if(j<=tnr) fprintf(Logi,"%s ",r);
		else fprintf(Logi,"`%s' ",r);
		}
	fprintf(Logi,"<BR>");
	fflush(Logi);
}

void print_top(struct top *t){
fprintf(Logi,
"top %p: kood=%d leks=%d sem=%d label=%d truel=%d falsel=%d up=%p right=%p down=%p",
   t,t->kood,t->leks,t->sem,t->label,t->truel,t->falsel,t->up,t->right,
   t->down);
fprintf(Logi,"  (%s)<BR>",(t->leks==0) ? T[t->kood] : T[t->leks]);
if(t->right!=(struct top *)NULL) print_top(t->right);
if(t->down!=(struct top *)NULL) print_top(t->down);
}

void print_Itr(struct itr *t){
fprintf(Logi," itr %p: nr=%d loc=%d value=%d top=%p io=%d",
   t,t->nr,t->loc,t->value,t->t,t->io);
fprintf(Logi,"   (%s)<BR>",T[t->nr]);
}

void print_Ctr(struct ctr *t){
fprintf(Logi," ctr %p: nr=%d loc=%d value=%d",
   t,t->nr,t->loc,t->value);
fprintf(Logi,"   (%s)<BR>",T[t->nr]);
}

void print_one_top(struct top *t){
fprintf(Logi," top %p: kood=%d leks=%d sem=%d label=%d truel=%d falsel=%d up=%p right=%p down=%p",
   t,t->kood,t->leks,t->sem,t->label,t->truel,t->falsel,t->up,t->right,
   t->down);
fprintf(Logi,"  (%s)<BR>",(t->leks==0) ? T[t->kood] : T[t->leks]);
}

/* anal��sipuu tipu tr�kk */
void p_top(char *t,struct top *p){
if(logi==1){
	fprintf(Logi,"%s top:<BR>",t);
	print_one_top(p);
	}  
}

/* adresseerib maatrikseid programmi anal��si ajal. Sn=nr-(ident & con arv) */
/* scanner lisab id. ja c-d V-sse, iga puhul nr++ */
int adr(int i, int j){
	int k;
	k=(i-1)*Sn+j;
	if(k>(Sn+1)*(Sn+1)){
		fprintf(Logi,"adr: indeks %d �le piiri!<BR>",k);
		k=0;
		}
	return(k);      
}

void set_show(char *title){
	fprintf(Logi,"<H4><FONT COLOR=\"#0000FF\">%s",title);
	fprintf(Logi,"</FONT></H4>");
}

char *DefArray(int d){
	int n,i;
	char *M;
	n=(d*d);
	M=(char *)malloc(n);
	if(M==(char *)NULL){
		fprintf(Logi,"DefArray: I don't have memory enough..<BR>");
		ExIT();
		}
	for(i=0;i<n;i++) M[i]='\0'; 
	return(M);
}

/* vektoritele m�lu eraldamine */
char *DefVect(int n){
	int i;
	char *M;
	M=(char *)malloc(n);
	if(M==(char *)NULL){
		fprintf(Logi,"I don't have memory enough..");
		ExIT();
		}
	for(i=0;i<n;i++) M[i]='\0'; 
	return(M);
}

/* s"ltuva konteksti puu �lemine tase: m"isted */
char ***defDEP(void){
	int i,n;
	n=(nr+1)*sizeof(char ***);
	DEP=(char ***)malloc(n);
	if(DEP==(char ***)NULL){
		fprintf(Logi,"I don't have memory enough..");
		ExIT();
		}
	for(i=0;i<nr+1;i++) DEP[i]=(char **)NULL;
	return(DEP);
}

/* s"ltuva konteksti puu vahetase: vasakud kontekstid */
char **defL(void){
	int i,n;
	char **L;
	n=(nr+1)*sizeof(char **);
	L=(char **)malloc(n);
	if(L==(char **)NULL){
		fprintf(Logi,"I don't have memory enough..");
		ExIT();
		}
	for(i=0;i<nr+1;i++) L[i]=(char *)NULL;
	return(L);
}

void ps(void){
	fprintf(Logi,"<BR>");
}

void ExIT(void){
	if(logi==1){
		fprintf(Logi,"Abnormal end<BR><BR>");
		fflush(Logi);
		fclose(Logi);
		}               
	abort();
}

/* paiskfunktsioon (v�ti on prod. vahekeelne parem pool) */ 
int hfunc(int keylen,int *key){
	int h=0,g;
	int i;
	for(i=0;i<keylen;i++) h=h^key[i];
	g=h;
	h=h/HTL;
	h=g-(h*HTL);
	if((h<0)||(h>HTL)){
		fprintf(Logi,"HT error!<BR>");
		ExIT();
		}
	return(h);
}

/* produktsiooni otsimine paisktabelist */
struct h *ReadHash(int n,int *key){
	struct h *t;
	int i,a;
	a=hfunc(n,key);
	t=HT[a];
otsi:	
	if(t!=(struct h *)NULL){
		if(n==t->n){
			for(i=0;i<n;i++){
				if(key[i]!=t->d[i]) goto next;
				}
			return(t);
			}		
		next: t=t->col;
		goto otsi;
		}	
	return(NULL);
}

int p_viga(int i){
	int j;
	VEAD++;
	fprintf(Logi,"<BR>\rerror at symbol #%d %s<BR>",i,word);
	for(j=0;j<i;j++) fprintf(Logi,"%c",PBuf[j]);
	if(logi==1) fprintf(Logi,"%c",sk);
	while(i<Plen){
		fprintf(Logi,"%c",PBuf[i]);
		i++;
		}
	ps();
	return(1);
}

/* parser: l�hte- ja vahekeelse programmi tr�kk */
void print_VK(int k){
int t,i,j;
	set_show("Input program:");
	for(i=0;i<k;i++){
		j=VK[i];
		if(j!=m_k){
			if(j!=k_k) fprintf(Logi,"%s ",T[j]);
			}
		}
	fprintf(Logi,"<BR>");
	set_show("Scanned program:");
	for(i=0;i<k;i++) fprintf(Logi,"%d ",VK[i]);
	fprintf(Logi,"<BR>");
	if(itl>0){
		fprintf(Logi,"<BR><FONT COLOR=\"#0000FF\">Identifiers:</FONT>");
		for(i=0;i<itl;i++){
			t=IT[i];
			fprintf(Logi,"%s%s",T[t],(i<itl-1) ? ", " : ";");
			}
		ps();   
		}
	if(ktl>0){
		fprintf(Logi,"<BR><FONT COLOR=\"#0000FF\">Constants:</FONT>");
		for(i=0;i<ktl;i++){
			t=KT[i];
			fprintf(Logi,"%s%s",T[t],(i<ktl-1) ? ", " : ";");
			}
		ps();
		}
}

/* eraldab m�lu uuele tipule t�hestiku V puusse */
struct D *newD(void){
	struct D *ptr;
	ptr=(struct D *)malloc(sizeof(struct D));
	if(ptr==NULL) ExIT();
	memset(ptr,'\0',sizeof(struct D));
	ptr->left=(struct D *)NULL;
	ptr->right=(struct D *)NULL;
	ptr->def=(struct R *)NULL;
	return(ptr);
}

/* t�hestiku V elemendi otsimine */
struct D *getV(char *key){
	struct D *t;
	int res;
	t=DT;
	if(t==(struct D *)NULL) goto exit;
ring: if(t->loc==0) res=strcmp(key,T[t->code]);
	 else{
	 	res=strcmp(key,T[t->loc]);        
	 	fprintf(Logi,"key=%s t->loc=%d %s<BR>",key,t->code,T[t->loc]);  
		}
	 if(res==0) goto out;
	 if(res<0){
			if(t->left != (struct D *)NULL){
				t=t->left;
				goto ring;
				}
			else goto exit;
			}
		if(res>0){
			if(t->right != (struct D *)NULL){
				t=t->right;
				goto ring;
				}
			else goto exit;
			}
exit: t=(struct D *)NULL;
out:  
	return(t);
}

/* scanner: identifikaatori t""tlemine */
int Ident(int k){
	int t,i;
	char *id;
	for(i=0;i<itl;i++){
		t=IT[i];
		id=T[t];
		if(strcmp(id,word)==0) goto itis;
		}		
	nr++;
	memcpy(T[nr],word,20);
	VK[k]=m_k;
	IT[itl]=nr;
	itl++;
	k++;
	VK[k]=nr;
	k++;
	goto ok;
itis:	
	VK[k]=m_k;
	k++;
	VK[k]=t;
	k++;
ok:	memset(word,'\0',20);   
	return(k);
}

/* scanner: konstandi t""tlemine */
int Const(int k){
	int t,i;
	char *con;
	for(i=0;i<ktl;i++){
		t=KT[i];
		con=T[t];
		if(strcmp(con,word)==0) goto itis;
		}		
	nr++;
	memcpy(T[nr],word,20);
	VK[k]=k_k;
	KT[ktl]=nr;
	ktl++;
	k++;
	VK[k]=nr;
	k++;
	goto ok;
itis:	
	VK[k]=k_k;
	k++;
	VK[k]=t;
	k++;
ok:	memset(word,'\0',20);   
	return(k);
}

int lekseem(int i){
	char *b,*g;
	struct D *t;
	int a,j,s,n;
	b=PBuf+i;
	for(s=0;s<tnr+1;s++){
		g=TT[s];
		n=strlen(g);
		if(n==0) return(0);
		j=0;
		memset(word,'\0',20);  
		for(a=0;a<n;a++){
			if(b[a]!=g[a]) goto next;
			word[j]=b[j];
			j++;
			}
		i=i+j;  
		t=getV(word);
		if(t==NULL) ExIT();
		KOOD=t->code;
		return(j);
		next: j=0;
		}
	return(0);      
}               
							
/* teisendab l�hteprogrammi vahekeelseks */
int scanner(void){
	struct D *t;
	int i,j,k,r;
	int olek;
	j=0;
	itl=ktl=0;
	m_k=k_k=0;
	VEAD=0;
	t=getV("#i#");
	if(t!=(struct D *)NULL) m_k=t->code;
	t=getV("#c#");
	if(t!=(struct D *)NULL) k_k=t->code; 
	vkl=Plen*8;
	VK=(int *)malloc(vkl);
	if(VK==NULL){
		fprintf(Logi,"I don't have memory enaugh..");
		return(0);
		}
	memset(VK,'\0',vkl);
	if(PBuf==NULL){
		fprintf(Logi,"scanner: pole faili %s",pr_name);
		return(0);
		}
	i=0;
	olek=0;
	marker=0;
	t=getV("#");
	if(t!=(struct D *)NULL) marker=t->code; 
	if(marker==0){
	    fprintf(Logi,"aksioomi definitsioonis peavad olema markerid '#'");
	    return(0);
	    }
	VK[0]=marker; 
	k=1;
	if(PBuf[i]=='#') i=1;
	memset(word,'\0',20);
	while(i<Plen){
		switch(olek){
			case 0:{
				if(isspace(PBuf[i])){
					i++;
					break;
					}
				if(k_k>0){
					if(isdigit(PBuf[i])){
						j=0;
						olek=2;
						break;
						}
					}	
				r=lekseem(i);
				if(r>0){
					VK[k]=KOOD;
					k++;
					memset(word,'\0',20);
					i=i+r;
					j=0;
					break;
					}
				j=0;
				memset(word,'\0',20);   
				if(isalpha(PBuf[i])){
					j=0;
					olek=1;
					break;
					}
				if(ispunct(PBuf[i])){
					p_viga(i);
					i++;
					j=0;
					memset(word,'\0',20);
					break;
					}       
				}
			case 1:{
				if(isalpha(PBuf[i])){
					word[j]=PBuf[i];
					i++;
					j++;
					break;
					}
				if(isdigit(PBuf[i])){
					word[j]=PBuf[i];
					i++;
					j++;
					break;
					}
				if(ispunct(PBuf[i])){
					k=Ident(k);
					j=0;
					olek=0;
					break;
					}
				if(isspace(PBuf[i])){
					k=Ident(k);
					j=0;
					i++;
					olek=0;
					break;
					}
				}       
			case 2:{
				if(isalpha(PBuf[i])){
					p_viga(i);
					i++;
					j=0;
					memset(word,'\0',20);
					break;
					}
				if(isdigit(PBuf[i])){
					word[j]=PBuf[i];
					i++;
					j++;
					break;
					}
				if(ispunct(PBuf[i])){
					k=Const(k);
					j=0;
					olek=0;
					break;
					}
				if(isspace(PBuf[i])){
					k=Const(k);
					i++;
					j=0;
					olek=0;
					break;
					}
				}       
			}
	}
	if(VK[k-1]!=marker){
		VK[k]=marker;
		k++;
		}
	print_VK(k);
	VKL=k;
	memset(word,'\0',20);
	memcpy(word,"DUMMY",5);
	Ident(k);
	dummy=nr;
	set_show("Scanner ended");
	if(VEAD>0) return(0);
	NR=nr;
	nr=Sn;  
	return(1);
}

FILE *opr(void){
	of=fopen(rida,"rb");
	if (of==NULL){
		fprintf(Logi,"cannot open %s",rida);
		return(of);
		}
	return(of);
}

FILE *opw(void){
	of=fopen(rida,"wb");
	if (of==NULL){
		fprintf(Logi,"cannot open %s",rida);
		return(of);
		}
	return(of);
}

/* eraldab m�lu uuele NT-definitsioonile: id / const */
struct R *newR(void){
	struct R *ptr;
	ptr=(struct R *)malloc(sizeof(struct R));
	if(ptr==NULL) ExIT();
	memset(ptr,'\0',sizeof(struct R));
	ptr->alt=(struct R *)NULL;
	return(ptr);
}

struct D *r_V(void){
	struct D *t;
	struct R *od,*d;
	int f;
	t=newD();
	fread(t,sizeof(struct D),1,of);
	if(feof(of)){
		fclose(of);
		return((struct D *)NULL);
		}
	f=ferror(of);
	if(f>0){
		fprintf(Logi,"file error %d",f);
		fclose(of);
		return((struct D *)NULL);
		}
	if(t->tunnus==0){
		t->def=newR();
		fread(t->def,sizeof(struct R),1,of);
		d=t->def;
		if(d->d!=(int *)NULL&&d->n>0){
				d->d=(int *)malloc(d->n*sizeof(int));
				if(d->d==NULL) ExIT();
				fread(d->d,d->n*sizeof(int),1,of);
				}
		od=d->alt;
		while(od!=(struct R *)NULL){
			d->alt=newR();
			d=d->alt;
			fread(d,sizeof(struct R),1,of);
			if(d->d!=(int *)NULL&&d->n>0){
				d->d=(int *)malloc(d->n*sizeof(int));
				if(d->d==NULL) ExIT();
				fread(d->d,d->n*sizeof(int),1,of);
				}
			od=d->alt;
			}
		}
	if(t->left!=(struct D *)NULL) t->left=r_V();
	if(t->right!=(struct D *)NULL) t->right=r_V();
	return(t);
}

/* tabelite lugemine */
void r_DEP(void){
	int i,j;
	char **L;
	char *rc;
	DEP=defDEP();
	fread(DEP,sizeof(char ***),nr+1,of);
	for(i=0;i<nr+1;i++){
		if(DEP[i]!=(char **)NULL){
			L=defL();
			fread(L,sizeof(char **),nr+1,of);
			DEP[i]=L;
			for(j=0;j<nr+1;j++){
				if(L[j]!=(char *)NULL){
					rc=DefVect(tnr+1);
					fread(rc,tnr+1,1,of);
					L[j]=rc;
					}
				}
			}
		}
}                                       

struct h *grec(void){
	struct h *L;
	L=(struct h *)malloc(sizeof(struct h));
	if(L==(struct h *)NULL){
		fprintf(Logi,"I haven't memory enough..");
		ExIT();
		}
	return(L);
}               

char *gM(int p){
	char *ptr=NULL;
	ptr=(char *)malloc(p);
	if(ptr==NULL){
		fprintf(Logi,"I haven't memory enough..");
		ExIT();
		}
	return(ptr);
}

struct h *r_hr(void){
	struct h *r;
	r=grec();
	fread(r,sizeof(struct h),1,of);
	r->d=(int *)malloc(r->n*sizeof(int));
	fread(r->d,r->n*sizeof(int),1,of);
	if(r->same!=(struct h *)NULL) r->same=r_hr();
	if(r->col!=(struct h *)NULL) r->col=r_hr();
	return(r);
}

void r_HT(void){
	int i;
	fread(HT,sizeof(struct h *),HTL,of);
	for(i=0;i<HTL;i++){
		if(HT[i]!=(struct h *)NULL) HT[i]=r_hr();
		}
}                                       

struct top *r_ptree(void){
	struct top *p;
	p=(struct top *)malloc(sizeof(struct top));
	if(p==(struct top *)NULL){
		fprintf(Logi,"I haven't memory enough..");
		ExIT();
		}
	fread(p,sizeof(struct top),1,of);
	if(p->right!=(struct top *)NULL) p->right=r_ptree();
	if(p->down!=(struct top *)NULL) p->down=r_ptree();
	return(p);
}

void w_ptree(struct top *p){
	fwrite(p,sizeof(struct top),1,of);
	if(p->right!=(struct top *)NULL) w_ptree(p->right);
	if(p->down!=(struct top *)NULL) w_ptree(p->down);
}

int w_tree(void){
	sprintf(rida,"%s.pt",Pr_name);
	if(opw()!=NULL){
		w_ptree(p_);
		return(1);
		}
	return(0);
}		

struct top *set_up(struct top *root){
	struct top *p=NULL;
	if(root!=(struct top *)NULL){
		if(root->down!=(struct top *)NULL) p=set_up(root->down);
		if(root->right!=(struct top *)NULL) p=set_up(root->right);
		if(p->up!=(struct top *)NULL) p->up=root;
		}
	return(p);
}

int r_t(void){
	sprintf(rida,"%s.t",Nimi);
	if(opr()!=NULL){
		fread(&T,20,nr+1,of);
		fclose(of);
		return(1);
		}
	else return(0);
}

int r_tt(void){
	sprintf(rida,"%s.tt",Nimi);
	if(opr()!=NULL){
		fread(&TT,20,tnr+1,of);
		fclose(of);
		return(1);
		}
	else return(0);
}

int w_t(void){
	sprintf(rida,"%s.t",Pr_name);
	if(opw()!=NULL){
		fwrite(&T,20,NR+1,of);
		fclose(of);
		return(1);
		}
	else return(0);
}

int r_parm(void){
	PARM=(struct parm *)malloc(sizeof(struct parm));
	if(PARM==(struct parm *)NULL) ExIT();
	memset(PARM,'\0',sizeof(struct parm));
	sprintf(rida,"%s.prm",Nimi);
	if(opr()!=NULL){
		fread(PARM,sizeof(struct parm),1,of);
		fclose(of);
		nr=PARM->nr;
		tnr=PARM->tnr;
		Sn=nr;
		context=PARM->BRC;
		Pnr=PARM->Pnr;
		dc=PARM->dep;
		return(1);
		}
	return(0);
}

int w_parm(void){
	sprintf(rida,"%s.prm",Pr_name);
	if(opw()!=NULL){
		PARM->nr=NR;
		PARM->ktl=ktl;
		PARM->itl=itl;
		fwrite(PARM,sizeof(struct parm),1,of);
		fclose(of);
		return(1);
		}
	return(0);
}

int r_sm(void){
	sprintf(rida,"%s.sm",Nimi);
	if(opr()!=NULL){
		semantika=(int *)malloc(sizeof(int)*(tnr+Pnr+1));
		fread(semantika,sizeof(int)*(tnr+Pnr+1),1,of);
		fclose(of);
		semflag=1;
		return(1);
		}
	return(0);
}

int r_v(void){
	sprintf(rida,"%s.v",Nimi);
	if(opr()!=NULL){
		DT=r_V();
		fclose(of);
		return(1);
		}
	else return(0);
}       

int r_ht(void){
	sprintf(rida,"%s.ht",Nimi);
	if(opr()!=NULL){
		r_HT();
		fclose(of);
		return(1);
		}
	else return(0);
}                       

int r_pm(void){
	sprintf(rida,"%s.pm",Nimi);
	if(opr()!=NULL){
		PM=DefArray(nr+1);
		fread(PM,(nr+1)*(nr+1),1,of);
		fclose(of);
		return(1);
		}
	else return(0);
}

int inxt(void){
	if(context==1){
		sprintf(rida,"%s.lc",Nimi);
		if(opr()!=NULL){
			LC=DefArray(nr+1);
			fread(LC,(nr+1)*(nr+1),1,of);
			fclose(of);
			}
		else return(0);
		sprintf(rida,"%s.rc",Nimi);
		if(opr()!=NULL){
			RC=DefArray(nr+1);
			fread(RC,(nr+1)*(nr+1),1,of);
			fclose(of);
			}
		else return(0);
	}
	return(1);
}

int depc(void){
	if(dc==1){
		sprintf(rida,"%s.dc",Nimi);
		if(opr()!=NULL){
			r_DEP();
			fclose(of);
			}
		else return(0);
		}
	return(1);
}

int w_it(void){
	sprintf(rida,"%s.it",Pr_name);
	if(opw()!=NULL){
		fwrite(IT,itl*sizeof(int),1,of);
		fclose(of);
		return(1);
		}
	return(0);
}

int w_kt(void){
	sprintf(rida,"%s.kt",Pr_name);
	if(opw()!=NULL){
		fwrite(KT,ktl*sizeof(int),1,of);
		fclose(of);
		return(1);
		}
	return(0);
}

int r_tabs(void){
	int flag;
	flag=1;
	flag=r_parm(); 
	if(flag==0) goto out;
	flag=r_t();    
	if(flag==0) goto out;
	flag=r_tt();    
	if(flag==0) goto out;	
	flag=r_sm();   
	if(flag==0) goto out;
	flag=r_v();    
	if(flag==0) goto out;
	flag=r_ht();   
	if(flag==0) goto out;
	PM=DefArray(nr+1);
	flag=r_pm();   
	if(flag==0) goto out;
	if(context>0){
		LC=DefArray(nr+1);
		RC=DefArray(nr+1);
		flag=inxt(); 
		if(flag==0) goto out;
		}
if(dc>0){
	flag=depc();     
	}
out:    if(flag==0){
		fprintf(Logi,"cannot read all the tables..");
		}
	return(flag);
}

void p_w(struct stat *b){
	int p;
	if(stat(rida,b)==-1){
		sprintf(rida,"w_tabs: stat failed<BR>");
		ExiT(rida);
		}
	p=b->st_size;
	fprintf(Logi,"<TR><TD>%s</TD><TD ALIGN=\"right\">%d</TD></TR>",rida,p);
}	

int w_p_tabs(void){
	struct stat *buf;
	fprintf(Logi,"<H3><FONT COLOR=\"#0000FF\">Result tables</H3><BR>");
	fprintf(Logi,"<TABLE BORDER=1><TR>");
	fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\">File</TD><TD><FONT COLOR=\"#0000FF\">Size</TD></FONT>");
	buf=(struct stat *)malloc(sizeof(struct stat));
	if(buf==NULL){
		sprintf(rida,"w_tabs: I haven't %d bytes of memory..<BR>",
			sizeof(struct stat));
		ExiT(rida);
		}
	w_parm();
	fclose(of);
	p_w(buf);	
	w_t();
	fclose(of);
	p_w(buf);		
	w_it();
	fclose(of);
	p_w(buf);		
	w_kt();
	fclose(of);
	p_w(buf);		
	w_tree();
	fclose(of);
	p_w(buf);		
	fprintf(Logi,"</TABLE>");
	fflush(Logi);	
	return(1);
}		

int p_top_rdf(struct top *t){
if(t==(struct top *)NULL) return(0);
fprintf(rdf,
"top %p: kood=%d leks=%d sem=%d label=%d truel=%d falsel=%d up=%p right=%p down=%p<BR>",
   t,t->kood,t->leks,t->sem,t->label,t->truel,t->falsel,t->up,t->right,
   t->down);
p_top_rdf(t->down);
p_top_rdf(t->right);
return(1);
}


int make_rtf(void){
int i;
	sprintf(rida,"%srd.htm",Pr_name);
	rdf=fopen(rida,"w");
	if(rdf==NULL) return(0);
	fprintf(rdf,"<HTML><HEAD><TITLE>");
	fprintf(rdf,"TABLES %s",pr_name);
	fprintf(rdf,
	"</TITLE></HEAD><BODY><H4><FONT COLOR=\"#0000FF\">PARSER TABLES of the Word %s</H4>",
		pr_name);
	fprintf(rdf,"</FONT><B>");	
	fflush(rdf);	
	fprintf(rdf,"<UL><LI><A HREF=\"#parm\">Parameters</A></LI>");
	fprintf(rdf,"<LI><A HREF=\"#t\">Dictionary T</A></LI>");
	if(PARM->itl>0)
		fprintf(rdf,"<LI><A HREF=\"#it\">Identifiers</A></LI>");
	if(PARM->ktl>0)
		fprintf(rdf,"<LI><A HREF=\"#kt\">Constants</A></LI>");	
	fprintf(rdf,"<LI><A HREF=\"#pt\">Parsing tree</A></LI>");	
	fprintf(rdf,"</UL>");	
	fprintf(rdf,"<HR>");

	fprintf(rdf,"<A NAME=\"parm\"></A>");
	fprintf(rdf,"<H4><FONT COLOR=\"#0000FF\">Parameters</H4></FONT>");
	fprintf(rdf,"File %s.prm<BR>",Pr_name);
	fprintf(rdf,"<PRE>");
	fprintf(rdf,"struct parm{\n");
	fprintf(rdf,"\tint nr   //t&auml;hestiku V pikkus\n");
	fprintf(rdf,"\tint tnr  //t&auml;hestiku V<SUB>T</SUB> pikkus\n");
	fprintf(rdf,"\tint BRC  //0: G on p&ouml;&ouml;ratav\n");
	fprintf(rdf,"\tint Pnr  //Produktsioonide arv\n");
	fprintf(rdf,"\tint dep  //1: s&otilde;ltuv kontekst\n");
	fprintf(rdf,"\tint itl  //identifikaatorite arv\n");
	fprintf(rdf,"\tint ktl  //konstantide arv\n");
	fprintf(rdf,"}\n\n");
	fprintf(rdf,"nr=%d tnr=%d BRC=%d Pnr=%d dep=%d itl=%d ktl=%d\n\n",
	PARM->nr,PARM->tnr,PARM->BRC,PARM->Pnr,PARM->dep,PARM->itl,PARM->ktl);

	fprintf(rdf,"</PRE><A NAME=\"t\"></A><HR>");
	fprintf(rdf,"<H4><FONT COLOR=\"#0000FF\">Dictionary T</H4></FONT>");
	fprintf(rdf,"File %s.t<BR>",Pr_name);
	fprintf(rdf,"<PRE>");
	for(i=1;i<=NR;i++) fprintf(rdf,"%s ",T[i]);
	fprintf(rdf,"</PRE><BR><BR><HR>");

if(itl>0){
	fprintf(rdf,"<A NAME=\"it\"></A>");
	fprintf(rdf,"<H4><FONT COLOR=\"#0000FF\">Identifiers</H4></FONT>");
	fprintf(rdf,"File %s.it<BR>",Pr_name);
	fprintf(rdf,"<PRE>");
	for(i=0;i<itl;i++) fprintf(rdf,"%d ",IT[i]);
	fprintf(rdf,"</PRE><BR><BR><HR>");	
	}
if(ktl>0){	
	fprintf(rdf,"<A NAME=\"kt\"></A>");
	fprintf(rdf,"<H4><FONT COLOR=\"#0000FF\">Constants</H4></FONT>");
	fprintf(rdf,"File %s.kt<BR>",Pr_name);
	fprintf(rdf,"<PRE>");
	for(i=0;i<ktl;i++) fprintf(rdf,"%d ",KT[i]);	
	fprintf(rdf,"</PRE><BR><BR><HR>");
	}
	fprintf(rdf,"<A NAME=\"pt\"></A>");
	fprintf(rdf,"<H4><FONT COLOR=\"#0000FF\">Parsing tree</H4></FONT>");
	fprintf(rdf,"File %s.pt<BR>",Pr_name);
	fprintf(rdf,"<PRE>");
	fprintf(rdf,"struct top{<BR>");
	fprintf(rdf,"\tint kood;\t/* vahekeelne kood */<BR>");
	fprintf(rdf,"\tint leks;\t/* kui tipp=ident/const, siis selle jrk-nr.*/<BR>");
	fprintf(rdf,"\tint sem;\t/* semantikakood */<BR>");
	fprintf(rdf,"\tint label;\t/* kui tipp on m&auml;rgendatud operaator - m&auml;rgendi nr */<BR>");
	fprintf(rdf,"\tint truel;\t/* kompilaator: go to true */<BR>");
	fprintf(rdf,"\tint falsel;\t/* kompilaator: go to false */<BR>");
	fprintf(rdf,"\tstruct top *up;\t/* puuviidad: &uuml;les, */<BR>");
	fprintf(rdf,"\tstruct top *right;\t/* naabrile ja */<BR>");
	fprintf(rdf,"\tstruct top *down;\t/* alluvale */<BR>");
	fprintf(rdf,"}<BR><BR><BR>");
	p_top_rdf(p_);
	fprintf(rdf,"</PRE>");

	fprintf(rdf,"</BODY></HTML>");
	fflush(rdf);
	fclose(rdf);
	return(1);
}

struct top *analyzer(void){
	if(r_tabs()==0) return(0);
	Sn=nr;
	P=PBuf;
	set_show("Scanner started");
	if(scanner()==0||VEAD>0) return(0);
	set_show("Parser started");
	p_=parser();
	if(p_==(struct top *)NULL) return(0);
	set_show("Parsing tree");                       
	pp2html(p_);    
	ctree();
	return(p_);
}

void ctree(void){
	if(ktl>0){
		set_show("Table of constants");
		make_CT();
		}
	if(itl>0){
		set_show("Table of identifiers");
		make_IDT();
		fprintf(Logi,"<BR>");
		}       
}               

int red_dep(struct h *S,int x,int y){
	char **L;
	char *rc;
	L=DEP[S->NT];
	if(L!=(char **)NULL){
		rc=L[x];
		if(rc==(char *)NULL) return(0);
		if(rc[y]==1){
			hc=S;
			return(S->NT);
			}
		}
	return(0);
}	

int red_indep(struct h *t,int x,int y){
	int ret=0;
	int r=0;
	struct h *S;
	S=t;
	while(S!=(struct h *)NULL){
		if(S->nc==0){
			if(LC[adr(S->NT,x)]>0){
				r++;
				ret=S->NT;
				hc=S;
				}
			}	
		S=S->same;
		}
	if(r==0){
		fprintf(Logi,"\n%s is not in any LCs\n",T[x]);
		hc=(struct h *)NULL;
		return(0);
		}
	if(r==1) return(ret);
	S=t;
	while(S!=(struct h *)NULL){
		if(S->nc==0){
			if(RC[adr(S->NT,y)]>0){
				hc=S;
				return(S->NT);
				}
			}	
		S=S->same;
		}
	fprintf(Logi,"\n%s is not in any RCs\n",T[y]);
	hc=(struct h *)NULL;
	return(0);
}

/* redutseerib lausevormi mitteterminali koodiks */
int reduce(struct h *t,int x, int y){
	int ret;
	struct h *S;
	ret=0;
	hc=(struct h *)NULL;
	if(t->same==(struct h *)NULL){
		hc=t;
		return(t->NT);
		}
	S=t;
	while(S!=(struct h *)NULL){
		if(S->nc>0){
			ret=red_dep(S,x,y);
			if(ret>0) return(ret);
			}
		S=S->same;
		}
	ret=red_indep(t,x,y);
	if(ret>0) return(ret);
	return(0);
}

char s[7][60]={
	" ",
	"<FONT COLOR=\"#FF4500\">=&#149</FONT>",
	"<FONT COLOR=\"#FF4500\">&lt&#149</FONT>",      
	" ",
	"<FONT COLOR=\"#FF4500\">&#149&gt</FONT>",      
	};
	
/* anal��s: magasini ja anal��simata teksti v�ljatr�kk */
int p_stack(char *name,int *v,char *rel,int a,int n,int k){
	int i,j,lv;
	fprintf(Logi,"<BR><TABLE BORDER=1><B><TR><TD NOWRAP>Stack & Word</TD>");
	for(lv=n;lv>0;lv--){
		if(rel[lv]==2) break;
		}
	for(i=a;i<n;i++){
		j=rel[i];
		fprintf(Logi,"<TD NOWRAP> %s",s[j]);
		j=v[i];
		if(i<lv)
		  fprintf(Logi,"<FONT COLOR=\"#0000FF\"><STRONG>%s</FONT></TD>",T[j]);
		else
		  fprintf(Logi,"<FONT COLOR=\"#FF0000\"><STRONG>%s</FONT></TD>",T[j]);
		}
	for(i=k; i<VKL; i++){
		j=VK[i];
		fprintf(Logi,"<TD>%s </TD>",T[j]);
		}
	fprintf(Logi,"</TR></TABLE>");
	return(0);
}

/* anal��sipuu moodustamine: uus tipp */
struct top *newtop(int x,int i,int sem){
	struct top *ptr;
	ptr=(struct top *)NULL; 
	if(x<tnr+1 && semantika[sem]==0) goto out;
	ptr=(struct top *)malloc(sizeof(struct top));
	if(ptr==(struct top *)NULL){
		fprintf(Logi,"newtop: lack of memory of %d bytes<BR>",
		sizeof(struct top));
		ExIT();
		}
	memset(ptr,'\0',sizeof(struct top));
	ptr->up=(struct top *)NULL;
	ptr->right=(struct top *)NULL;
	ptr->down=(struct top *)NULL;
	ptr->kood=x;
	ptr->sem=semantika[sem];
	if((x==m_k)||(x==k_k)){
		ptr->leks=(i==0) ? dummy : VK[i];
		}
out:    return(ptr);
}

/* anal��sipuu moodustamine: uue tipu/alampuu lisamine */
void red_tree(struct top *puu[],struct top *p,int s,int n){
	int i;
	struct top *cp=(struct top *)NULL;
	struct top *first=(struct top *)NULL;
	struct top *last=(struct top *)NULL;
	for(i=0;i<n;i++){
		if(puu[i+s]!=(struct top *)NULL){
			cp=puu[i+s];
			if(cp->sem==0){
				if(cp->down==(struct top *)NULL) goto ilja;
				if(cp->down!=(struct top *)NULL){
					cp=cp->down;
					if(first==(struct top *)NULL) first=cp;
					if(last!=(struct top *)NULL) last->right=cp;
					while(cp->right!=(struct top *)NULL){
						cp=cp->right;
						}
					cp->up=(struct top *)NULL;
					goto next;
					}
			    }   
			if(first==(struct top *)NULL) first=cp;
			if(last!=(struct top *)NULL) last->right=cp;
			}
		next: last=cp;
		ilja: cp=cp;
		}
	p->down=first;
	if(last!=(struct top *)NULL) last->up=p;
}

/* analyysipuu trykk */
int pp2html(struct top *p){
	double pr;
	int n=1;
	struct top *t;
	char s[20];
	t=p;
naaber:
	if(t->right!=NULL){
		n++;
		t=t->right;
		goto naaber;
		}
	pr=100.0/n;
	sprintf(s,"\"%2.0f&#037\"",pr); 
	fprintf(Logi,"<table border=1><tr>");   
next:
	fprintf(Logi,
	"<td width=%s valign=\"top\"><STRONG>",s);      
	if((p->kood==m_k)||(p->kood==k_k)) fprintf(Logi,"%s",T[p->leks]);
	else fprintf(Logi,"%s",T[p->kood]); 
	if(p->down!=NULL) pp2html(p->down);
	fprintf(Logi,"</td>");  
	if(p->right!=NULL){                     
		p=p->right;
		goto next;
		}
	fprintf(Logi,"</tr></table>");
	return 1;
}  

void p_sf(void){
	int i,j;
	fprintf(Logi,"<BR>Sentential form: ");
	for(i=0; i<n_; i++){
		j=lausevorm[i];
		fprintf(Logi,"%s ",T[j]);
		}
	fprintf(Logi,"<BR>");   
	fflush(Logi);
}               

void sentential_form(void){
	for(s_=J;s_>0;s_--){
		if(rela[s_]==2) break;
		}
	memset(lausevorm,'\0',sizeof(lausevorm));
	n_=J-s_;
	for(l_=0;l_<n_;l_++){
	lausevorm[l_]=Stack[s_+l_];
	}
}


int correct(void){
	int i,r;
	if(x_==VK[I]) return(0);
	for(i=1;i<tnr;i++){
		r=PM[adr(x_,i)];
		if(r!=0){
			Stack[J]=i;
			rela[J]=r;
			x_=i;
			p_stack("\n",Stack,rela,0,J+1,I);
			if((x_==m_k)||(x_==k_k)) puu[J]=newtop(x_,0,x_);
			J++;
			return(1);
			}
		}
	return(0);
}


/* anal�saator. Ette vahekeelne programm, v�lja (h6re) anal��sipuu */
struct top *parser(void){
	int i,j,r;
	char c=' ';
	memset(Stack,'\0',sizeof(Stack));
	memset(rela,'\0',200);
fflush(Logi);
	for(I=0;I<200;I++) puu[I]=(struct top *)NULL;
fflush(Logi);
	Stack[0]=marker;
	x_=marker;
	J=1;
	I=1;
while(I<VKL){
fflush(Logi);
	rel=PM[adr(x_,VK[I])];
	j=VK[I];
	fflush(Logi);           
	rela[J]=rel;
	switch(rel){
		case 0: 
			j=VK[I];
			fprintf(Logi,
				"<BR>no relationship between the symbols %s and %s<BR>",
				T[x_],T[j]);
			fprintf(Logi,"The relationships of %s<BR>",T[x_]);
			for(i=0;i<nr+1;i++){
				r=PM[adr(x_,i)];
				if(r>0){
					if(r==1) c='=';
					if(r==2) c='<';
					if(r==4) c='>';
					fprintf(Logi,"%s %c %s<BR>",T[x_],c,T[i]);
					}
				}
			fprintf(Logi,"<BR>");
			if(X==0){
				p_=(struct top *)NULL;
				return(p_);
				}
			fprintf(Logi,"I'll try to correct..\n");
			flag=1;
			if(correct()==0) I++;				
			break;
		case 1: if(VK[I]==marker){
				set_show("the parsing is completed");
				return(p_);
				}
			Stack[J]=VK[I];
			x_=Stack[J];
			if((x_==m_k)||(x_==k_k)) I++;
fflush(Logi);
			puu[J]=newtop(x_,I,x_);
fflush(Logi);
			p_stack("\n",Stack,rela,0,J+1,I+1);                     
fflush(Logi);
			J++;
			I++;
			break;
		case 2: Stack[J]=VK[I];
			x_=Stack[J];
			if((x_==m_k)||(x_==k_k)) I++;
fflush(Logi);
			puu[J]=newtop(x_,I,x_);
fflush(Logi);
			p_stack("\n",Stack,rela,0,J+1,I+1);                     
fflush(Logi);
			J++;
			I++;
			break;
		case 4: 
fflush(Logi);
			sentential_form();
fflush(Logi);
			ps();
fflush(Logi);
			t_=ReadHash(n_,lausevorm);
fflush(Logi);
			if(t_==(struct h *)NULL){
fflush(Logi);
				p_=(struct top *)NULL;
				return(p_);
				}
fflush(Logi);
			N_=reduce(t_,Stack[s_-1],VK[I]);
			fflush(Logi);
			t_=hc;
			if(N_==0){
fflush(Logi);
				set_show("reduce error");
fflush(Logi);

				p_=(struct top *)NULL;
				fflush(Logi);
				return(p_);
				}
			rela[s_]=PM[adr(Stack[s_-1],N_)];
			Stack[s_]=N_;
			x_=N_;
fflush(Logi);
			p_=newtop(N_,I,t_->P+tnr);
fflush(Logi);
			red_tree(puu,p_,s_,n_);
	fflush(Logi);
			puu[s_]=p_;
			p_stack("<BR>",Stack,rela,0,s_+1,I);                    
fflush(Logi);
			if(semantika[t_->P+tnr]>0){
				set_show("Parsing tree");                       
fflush(Logi);
				pp2html(p_);
fflush(Logi);
				}
			fprintf(Logi,"<BR>");
			J=s_+1;
			break;
		}
	}
	return(p_);
}

/* m�lueraldus konstantide tabeli kirjele */
struct ctr *make_ctr(void){
	struct ctr *c;
	c=(struct ctr *)malloc(sizeof(struct ctr));
	if(c==(struct ctr *)NULL) ExIT();
	memset(c,'\0',sizeof(struct ctr));
	return(c);
}       
	
/* konstantide tabeli moodustamine */
int make_CT(void){
	int t;
	struct ctr *c;
	int i;
	if(ktl==0) return(0);
	fprintf(Logi,"<TABLE BORDER=1><TR>");
	for(i=0;i<ktl;i++){
		t=KT[i];
		c=make_ctr();
		c->nr=t;
		c->value=atoi(T[c->nr]);
		CT[i]=c;
		fprintf(Logi,"<TD>c%d=%d</TD>",i+1,c->value);
		}
	fprintf(Logi,"</TR></TABLE>");
	return(ktl);
}

/* m�lueraldus identifikaatorite tabeli kirjele */
struct itr *make_itr(void){
	struct itr *c;
	c=(struct itr *)malloc(sizeof(struct itr));
	if(c==(struct itr *)NULL) ExIT();
	memset(c,'\0',sizeof(struct itr));
	c->t=(struct top *)NULL;
	return(c);
}       

/* identifikaatorite tabeli moodustamine */
int make_IDT(void){
	int t;
	struct itr *c;
	int i;
	if(itl==0) return(0);   
	itl=(flag==0) ? itl-1 : itl;
	fprintf(Logi,"<TABLE BORDER=1><TR>");
	for(i=0;i<itl;i++){
		t=IT[i];
		c=make_itr();
		c->nr=t;
		IDT[i]=c;
		fprintf(Logi,"<TD>i%d=%s</TD>",i+1,T[c->nr]);
		}
	fprintf(Logi,"</TR></TABLE>");          
	return(itl);
}

/* identifikaatorite tabeli kirje tr�kk */
void p_itr(struct itr *id){
	fprintf(Logi,"ITR nr=%d V=%s loc=%d value=%d t=%p<BR>",
		id->nr,T[id->nr],id->loc,id->value,id->t);
}

/* muutujate v�ljatr�kk */
void print_variables(void){
	struct itr *id;
	int i,k;
	set_show("THE VARIABLES:");
	k=(flag==0) ? itl-1 : itl;
	for(i=0;i<k;i++){
		id=IDT[i];
		if(id->t==(struct top *)NULL)
		fprintf(Logi,"%s=%d<BR>",T[id->nr],id->value);
		}
}

/* konstantide tabeli kirje tr�kk */
void p_ctr(struct ctr *id){
	fprintf(Logi,"CTR nr=%d V=%s loc=%d value=%d<BR>",
		id->nr,T[id->nr],id->loc,id->value);
}               

/* tekstimassiivi sisestamine kettalt */
char *jarray(char *pealkiri){
	FILE *tekst=NULL;
	char *B;
	char c;
	int  i;
	int  k;
	struct stat *buf;
	buf=(struct stat *)malloc(sizeof(struct stat));
	if(buf==NULL){
		fprintf(Logi,"r_text: I haven't %d bytes of memory..<BR>",
			sizeof(struct stat));
		ExIT();
		}               
	tekst = fopen(pealkiri, "r");
	if (tekst==NULL){
		fprintf(Logi,"cannot find the file  %s <BR>",pealkiri);
		ExIT();
		}
	if(stat(pealkiri,buf)==-1){
		fprintf(Logi,"r_text: stat failed<BR>");
		ExIT();
		}
	k=buf->st_size; 
	B = (char *)malloc(k+10);
	if(B == NULL){
		fprintf(Logi,"I don't have memory enaugh..");
		ExIT();
		}
	memset(B,'\0',k+10);
/* fill buffer */
	rewind(tekst);
	i=0;
	while (!feof(tekst)){
		c=fgetc(tekst);
		B[i]=c;
		i++;
		}
	P_length=i;
	for(i=P_length;i>0;i--){
		if(isgraph(B[i])){
			i++;
			B[i]='\n';
			i++;
			B[i]='\0';
			P_length=i;
			goto out;
			}
		}
out:    fclose(tekst);
	return(B);
}

int prog(void){
	PBuf=jarray(pr_name);
	if(PBuf!=NULL){
		Plen=P_length;
		return(1);
		}
	return(0);
}

int itr(void){
	int ret=0;
	time_t t0;
	char c;
	GBuf=NULL;
	Logi=fopen(L_name,"w");
	if(Logi==NULL){
		printf("Cannot open log-book\n");
		return(0);
		}
	logi=1;
	time(&t0);
	fprintf(Logi,"<HTML><HEAD><TITLE>Parser</TITLE></HEAD><BODY><B>");
	fprintf(Logi,
	"<FONT COLOR=\"#0000FF\"><H3>Start of %s Parser for a ",Nimi);
	c=Nimi[0];
	c=toupper(c);
	switch(c){
		case 'G': fprintf(Logi,"Word "); break;
		case 'T': fprintf(Logi,"Program "); break;
		case 'F': fprintf(Logi,"Formula "); break;
		}		
	fprintf(Logi,"</FONT>%s ",pr_name);
	fprintf(Logi,"<FONT COLOR=\"#0000FF\"> at </FONT>");
	fprintf(Logi,"%s</H3><BR>",asctime(localtime(&t0)));
	if(prog()==0){
		fflush(Logi);
		fclose(Logi);   
		return(ret);
		}
	if(analyzer()!=NULL){
		w_p_tabs();
		make_rtf();
		}
	time(&t0);
	fprintf(Logi,"<FONT COLOR=\"#0000FF\"><H4>Parser ended at </FONT> ");
	fprintf(Logi,"%s</H4>",asctime(localtime(&t0))); 
	fprintf(Logi,"</BODY></HTML>");
	return(ret);
}

struct top *main(int argc,char **argv){
char *p;
char c;
char wrd[20];
	pr_name=(char *)malloc(256);
	Pr_name=(char *)malloc(256);	
	L_name=(char *)malloc(256);
	Nimi=(char *)malloc(256);       
	memset(pr_name,'\0',256);
	memset(Pr_name,'\0',256);	
	memset(L_name,'\0',256);        
	memset(Nimi,'\0',256);          
	strcpy(Nimi,argv[1]);      
	sprintf(pr_name,"%s",argv[2]);  
	strcpy(L_name,pr_name);
	strcpy(Pr_name,pr_name);	
	p=strrchr(L_name,'.');
	strcat(L_name,"p.htm");
	memset(wrd,'\0',20);
	X=0;
	c=tolower(Nimi[0]);
	switch(c){
		case 'g': 
			sprintf(wrd,".%s",Nimi);
			strcat(pr_name,wrd); 
			break;
		case 't': strcat(pr_name,".tri"); 
				X=1;
				break;
		case 'f': strcat(pr_name,".frm"); break;
		}
	printf("gr_name=%s.grm pr_name=%s L_name=%s\n",Nimi,pr_name,L_name);
	itr();
	fflush(Logi);   
	return(p_);
}


