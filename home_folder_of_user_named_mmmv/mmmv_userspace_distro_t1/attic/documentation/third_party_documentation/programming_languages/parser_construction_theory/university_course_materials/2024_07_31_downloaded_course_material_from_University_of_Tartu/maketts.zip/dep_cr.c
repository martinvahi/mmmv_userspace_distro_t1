/* Constructor for C++6.0 (HTML-log, dependent context). March 2001  */

/* #include <io.h> */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>

#define HTL 256
#define sk '\xBA'
#define ap '\xFA'   /* xFA on relatsiooni tryki "punkt":  � */
#define MAX_FAILINIME_PIKKUS 256

  FILE *of;        /* w_bin & r_bin */
  int X;              /* 0 - Gx.grm,  1 - tri.grm  */
  char *Nimi;
  char rida[44];
  char word[20];      /* terminaalse v�i mitteterminaalse t�hestiku t�ht */
  char def[20];       /* produktsiooni parem pool vahekeeles */
  int dl;             /* "def" pikkus */
  char sat[44];             /* ={"trigol.txt"};  */
  char *fname;        /*  grammatika teksti nimi (v�ib koos teega) */
  char Rn[256];
  FILE *rules;        /* grammatikafaili handle */
  char *Buf;          /* sisendpuhver */
  int PF_length;      /* sisestatud teksti pikkus (Milam) */
  int P_length;       /* sisestatud teksti pikkus */
  char *GBuf;         /* sisendpuhver: grammar */
  int Glen;           /* sisestatud teksti pikkus: grammar */
  int Pnr;            /* produktsiooni jrk-nr */
  int olek;           /* automaadi jaoks */
  char *P;            /* sisendpuhvri j�rg */
  char T[2*HTL][20];  /* t�hestiku V symbolite nimed */
  int left;
  int right;
  int V;
  int semflag;
  char *semantika;    /* semantikamassiiv */
  char *p_M;          /* puutr�ki indeksite vektor */
  int p_ML;           /* indeksite vektori pikkus */
  char *PM;           /* eelnevusmaatriks output */
  char Pm[HTL][HTL];  /* konstruktori eelnevusmaatriks */
  char Lm[HTL][HTL];  /* leftmost-maatriks */
  char Rm[HTL][HTL];  /* rightmost-maatriks */
  char *LC;           /* vasak s�ltumatu kontekst */
  char *RC;           /* parem s�ltumatu kontekst */
  int Index;          /* eelnevusteisenduste uute produktsioonide suffiks */
  int dep;            /* dep>0; analysaator kasutab BRC(1,1)-konteksti */
  int dc;    /* dc=0 kui s�ltuvat kontexti ei saa arvutada v�i see ei eristu */
  int si;    /* stack index */

/* Produktsiooni parem pool */
struct R{
	int P;         /* produktsiooni jrk-nr */
	int sem;       /* semantikakood */
	int n;         /* NT definitsiooni pikkus */
	char *d;       /* NT definitsioon */
	struct R *alt; /* NT alternatiivne definitsioon */
	};

/* T�hestiku V symboli (NT v�i T) kirje */
struct D{
	int tunnus;  /* 0: NT, 1: T */
	int code;    /* vahekeelne kood */
	int L;       /* NT v�i id/const nime pikkus  */
	int loc;     /* ident | const : nr */
	int icx;     /* itl v�i ktl - IT v�i KT index */
	struct D *left;   /* kahendpuu viidad (v�ti on s) */
	struct D *right;
	struct R *def;    /* NT: vahekeelne definitsioon */
	};

struct parm{
	int nr;
	int tnr;
	int BRC;
	int Pnr;
	int dep;
	};

/* Produktsioonide paremate poolte j�rgi paisatud tabeli kirje */
struct h{
	int P;          /* produktsiooni jrk-nr */
	int n;          /* definitsiooni pikkus  */
	int NT;         /* defineeritav nonterminal  */
	char *d;        /* definitsioon */
	int nc;         /* 1 - s�ltuv kontekst */
	char *c;        /* reservis */
	struct h *same; /* sama parem pool */
	struct h *col;  /* p�rkeviit */
	};

  struct D *DT;     /* first   */
  struct D *DC;     /* current */
  struct D *DL;     /* last    */
  struct D *DN;     /* new     */

  int nr;     /* t�hestiku V jooksev pikkus */
  int tnr;    /* terminaalse t�hestiku jooksev pikkus */
  int ttl;    /* eraldajate arv */
  int NR;     /* eelnevusteisenduste 'uute produktsioonide' jooksev jrk-nr */
  int Sn;     /* 'nr' enne eelnevusteisendusi */
  int BRC;    /* �hesuguste paremate pooltega produktsioonide arv */
  int context;  /* 0 kui G on p��ratav, 1 kui pole */
  struct parm *PARM;      /* parameetrid */
  struct h *hc;           /* BRC-analyysil detekteeritud kirje viit */
  struct h *HT[HTL];      /* hashtabel */

  char ***DEP;	/* s�ltuv kontekst */
  FILE *Logi;
  char *L_name;
  
void ExiT(char *t);
int constr(void);            /* constr.c */
void ctree(void);            /* constr.c */
void print_h(struct h *t);              /* hash.c */
int hfunc(int keylen,char *key);        /* hash.c */
struct h *ReadHash(int n,char *key);    /* hash.c */
int HashRule(struct D *t,struct R *r);  /* hash.c */
void HashNT(struct D *t);               /* hash.c */
void HashRules(struct D *t);            /* hash.c */
void print_L(struct h *CP);             /* hash.c */
void print_HT(void);                    /* hash.c */
void brc(int NT);                               /* indep.c */
void print_indepC(void);                        /* indep.c */
void print_cxt(char **L);                       /* dep.c */
void print_all_cxt(void);                       /* dep.c */
void print_all_cxtp(void);                      /* dep.c */
int g1(char **L,int X,int D);                   /* dep.c */
int g2(char **L,struct h *t,int X);             /* dep.c */
int g3(char **L,struct h *t,int D);             /* dep.c */
int g4(char **L,struct h *t);                   /* dep.c */
int search_springs(struct h *t,int A);          /* dep.c */
int test_dep_con(struct h *x,struct h *y);      /* dep.c */
int brctest(struct h *t);                       /* indep.c */
int make_BRC(void);                             /* indep.c */
void pT(int v);                                  /* dict.c */
struct D *newD(void);                           /* dict.c */
struct R *newR(void);                           /* dict.c */
void free_R(struct R *r);                       /* dict.c */
void free_tree(struct D *t);                    /* dict.c */
void printR(struct R *r);                       /* dict.c */
int print_rule(struct D *t,struct R *r);        /* dict.c */
char *jarray(char *pealkiri);                   /* r_text.c */
int put_semant(void);                           /* sem.c */
struct D *search(int x);                        /* dict.c */ 
struct D *getV(char *key);                      /* dict.c */
void viga(int i);                               /* dict.c */
int p_viga(int i);                              /* scanner.c */
int print_rules(struct D *t);                   /* dict.c */
struct D *leftside(int l);                      /* dict.c */
void nonterm(int l);                            /* dict.c */
void term(int l,int flag);                      /* dict.c */
void makerul(void);                             /* dict.c */
int Terms(void);                                /* dict.c */
int Rules(void);                                /* dict.c */
void first_LR(struct D *t);                     /* lrm.c */
void sec_LR(int lrf,int nt);                    /* lrm.c */
void make_LRB(void);                            /* lrm.c */
void print_def(struct R *r);                    /* dict.c */
int relac(struct D *t);                         /* lrm.c */
int make_PM(void);                              /* lrm.c */
void print_rela(void);                          /* lrm.c */
void s_to_right(int lim, struct D *t,struct R *d);  /* conf.c */
void P2(int x,int y);                               /* conf.c */
void s_to_left(int lim, struct D *t,struct R *d);   /* conf.c */ 
void P1(int x,int y);                               /* conf.c */
void tell_conf(int p,int i,int j,int c);            /* conf.c */
int conflicts(void);                                /* conf.c */
void print_LRM(char M[HTL][HTL]);                   /* lrm.c */ 
void print_PM(void);       /* lrm.c */
void fprint_PM(void);      /* lrm.c */
int w_tabs(void);                      /* w_bin.c */

struct D *SD[HTL];
struct R *SR[HTL];

FILE *Sem=NULL;

struct U{
	int x;
	int y;
	struct U *next;
};

struct U *UP=NULL;	


char s[7][60]={"",
	"<FONT COLOR=\"#0000FF\">=&#149</FONT>",
	"<FONT COLOR=\"#0000FF\">&lt&#149</FONT>",
	"<FONT COLOR=\"#FF0000\">&lt&#149=&#149</FONT>",	
	"<FONT COLOR=\"#0000FF\">&#149&gt</FONT>",	
	"<FONT COLOR=\"#FF0000\">&lt&#149&#149&gt</FONT>",		
	"<FONT COLOR=\"#FF0000\">&lt&#149=&#149&#149&gt</FONT>"
	};

void printD(struct D *t);

/* tekstimassiivi sisestamine kettalt */
char *r_text(char *pealkiri){
	FILE *tekst=NULL;
	char *B;
	char c;
	int  i;
	int  k;
	struct stat *buf;
	buf=(struct stat *)malloc(sizeof(struct stat));
	if(buf==NULL){
		sprintf(rida,"r_text: I haven't %d bytes of memory..",
			sizeof(struct stat));
		ExiT(rida);
		}		
 	tekst = fopen(pealkiri, "r");
	if (tekst==NULL){
		sprintf(rida,"cannot find the file  %s",pealkiri);
		ExiT(rida);
		}
	if(stat(pealkiri,buf)==-1){
		sprintf(rida,"r_text: stat failed");
		ExiT(rida);
		}
	k=buf->st_size;	
	B = (char *)malloc(k+10);
	if(B == NULL){
		sprintf(rida,"r_text: I have't %d bytes of memory..",k+10);
		ExiT(rida);
		}
	memset(B,'\0',k+10);
/* fill buffer */
	rewind(tekst);
	i=0;
	while (!feof(tekst)){
		c=fgetc(tekst);
		B[i]=c;
		i++;
	};
	P_length=i;
	for(i=P_length;i>0;i--){
		c=B[i]; if(isgraph(c)){
			i++;
			B[i]='\n';
			i++;
			B[i]='\0';
			P_length=i;
			goto out;
			}
		}	
out:	fclose(tekst);
	return(B);
}

int gramm(void){
	GBuf=r_text(fname);
	if(GBuf!=NULL){
		Glen=P_length;
		return(1);
		}
	return(0);
}

/* adresseerib maatrikseid s�ntaksi anal��si ajal. nr=V pikkus */
int addr(int i, int j){
	int k;
/*	if(NR>0) goto indeks;
	if((i<1)||(j<1)||(i>nr)||(j>nr)){
		sprintf(rida,"addr: erroneus index nr=%d tnr=%d i=%d j=%d",
			nr,tnr,i,j);
		ExiT(rida);
		}
	indeks: */
	k=(i-1)*nr+j;
/*	if(NR>0) return(k);
	if(k>(nr+1)*(nr+1)){
		sprintf(rida,"addr: index %d �le piiri. i=%d j=%d nr=%d",k,i,j,nr);
		ExiT(rida);
		} */
	return(k);
}

char *DefArray(int d){
	int n,i;
	char *M;
	n=(d*d);
	M=(char *)malloc(n);
	if(M==(char *)NULL){
		sprintf(rida,"DefArray: I don't have memory enough..");
		ExiT(rida);
		}
	for(i=0;i<n;i++) M[i]='\0'; 
	return(M);
}

/* vektoritele m�lu eraldamine */
char *DefVect(int n){
	int i;
	char *M;
	M=(char *)malloc(n);
	if(M==(char *)NULL){
		sprintf(rida,"DefVect: I don't have memory enough..");
		ExiT(rida);
		}
	for(i=0;i<n;i++) M[i]='\0'; 
	return(M);
}

/* s�ltuva konteksti puu �lemine tase: m�isted */
char ***defDEP(void){
	int i,n;
	n=(nr+1)*sizeof(char ***);
	DEP=(char ***)malloc(n);
	if(DEP==(char ***)NULL){
		sprintf(rida,"defDEP: I don't have memory enough..");
		ExiT(rida);
		}
	for(i=0;i<nr+1;i++) DEP[i]=(char **)NULL;
	return(DEP);
}

/* s�ltuva konteksti puu vahetase: vasakud kontekstid */
char **defL(void){
	int i,n;
	char **L;
	n=(nr+1)*sizeof(char **);
	L=(char **)malloc(n);
	if(L==(char **)NULL){
		sprintf(rida,"defL: I don't have memory enough..");
		ExiT(rida);
		}
	for(i=0;i<nr+1;i++) L[i]=(char *)NULL;
	return(L);
}

void ExiT(char *t){
	fprintf(Logi,"%s<BR>",t);
	fprintf(Logi,"</BODY></HTML>");
	fflush(Logi);
	fclose(Logi);
	printf("%s",t);
	getchar();
	abort();
}

/* produktsioonide paisktabeli l�li tr�kk */
void print_h(struct h *t){
	int i,j;
	char *r;
	fprintf(Logi,"P=%d `%s' -&gt ",t->P,T[t->NT]); 
	for(i=0;i<t->n;i++){
		j=t->d[i];
		r=T[j];
		if(j<=tnr) fprintf(Logi,"%s ",r);
		else fprintf(Logi,"`%s' ",r);
		}
	fprintf(Logi,"<BR>");
}

/* paiskfunktsioon (v�ti on prod. vahekeelne parem pool) */ 
int hfunc(int keylen,char *key){
	int h=0,g;
	int i;
	for(i=0;i<keylen;i++) h=h^key[i];
	g=h;
	h=h/HTL;
	h=g-(h*HTL);
	return(h);
}

/* produktsiooni otsimine paisktabelist */
struct h *ReadHash(int n,char *key){
	struct h *t;
	int a;
	a=hfunc(n,key);
	t=HT[a];
otsi:	if(t!=(struct h *)NULL){
		if(n==t->n){
			if(strncmp(key,t->d,n)==0) return(t);
			}		
		t=t->col;
		goto otsi;
		}
	return(t);
}

/* produktsiooni paiskamine */
int HashRule(struct D *t,struct R *r){
	struct h *L,*TP,*S;
	int a;
	L=(struct h *)malloc(sizeof(struct h));
	if(L==NULL){
		sprintf(rida,"HashRule: I don't have memory enaugh..");
		ExiT(rida);
		}
	memset(L,'\0',sizeof(struct h));
	L->col=(struct h *)NULL;
	L->same=(struct h *)NULL;
	L->d=malloc(r->n);
	if(L->d==NULL){
		sprintf(rida,"HashRule: I don't have memory enaugh..");
		ExiT(rida);
		}
	memcpy(L->d,r->d,r->n);	
	L->n=r->n;
	L->NT=t->code;
	L->P=r->P;
	a=hfunc(L->n,L->d);
	if(HT[a] == (struct h *)NULL) HT[a]=L;
	else{
		TP=HT[a];
		while(TP!=(struct h *)NULL){
			if((L->n==TP->n)&&(strncmp(L->d,TP->d,L->n)==0)){
				S=TP->same;
				TP->same=L;
				L->same=S;
				BRC++;
				return(1);
				}
			TP=TP->col;
			}
		TP=HT[a];
		HT[a]=L;
		L->col=TP;
		}
	return(0);
}

/* Mitteterminali definitsioonide salvestamine */ 
void HashNT(struct D *t){
	struct R *r;
	r=t->def;
	while(r!=(struct R *)NULL){
		HashRule(t,r);
		r=r->alt;
		}
}

/* k�ikide mitteterminalide definitsioonide salvestamine */
void HashRules(struct D *t){
	if(t!=(struct D *)NULL){
		if(t->tunnus==0) HashNT(t);
		HashRules(t->left);
		HashRules(t->right);
		}
}

/* produktsioonide definitsitsioonide ahela l�li tr�kk */
void print_L(struct h *CP){
int i,j;
char *r;
	fprintf(Logi,"P%2d `%s' -&gr ",CP->P,T[CP->NT]); 
	for(j=0;j<CP->n;j++){
		i=CP->d[j];
		r=T[i];
		if(i<tnr+1) fprintf(Logi,"%s ",r);
		else fprintf(Logi,"`%s' ",r);
		}
	fprintf(Logi,"<BR>");
}

/* produktsioonide paisktabeli tr�kk */
void print_HT(void){
	struct h *CP,*s;
	int i;
		fprintf(Logi,"<H4>Productions (HT):</H4>");
		for(i=0; i<HTL; i++){
			CP=HT[i];
			while(CP != (struct h *)NULL){
				print_L(CP);
				s=CP->same;
				while(s != (struct h *)NULL){
					print_L(s);
					s=s->same;
					}
				CP=CP->col;
				}
			}
}


/* leftmost ja rightmost: esimene l�hendus */
void first_LR(struct D *t){
	struct R *r;
	int x;
	r=t->def;
ring:	if(r != (struct R *)NULL){
		if(t->tunnus==0){
			x=r->d[0];
			Lm[t->code][x]=1;
			x=r->d[r->n-1];
			Rm[t->code][x]=1;
			}
		r=r->alt;
		goto ring;
		}
}

/* leftmost: lisatakse L(A), kui A kuulub L */
void sec_LRL(int nt){
	int i,j;
	for(j=1; j<nr+1; j++){  
		if(Lm[j][nt]==1){
			for(i=1;i<nr+1;i++){
				if(Lm[nt][i]==1) Lm[j][i]=1;
				}
			}	
		}	
}

/* rightmost: lisatakse R(A), kui A kuulub R */
void sec_LRR(int nt){
	int i,j;
	for(j=1; j<nr+1; j++){  
		if(Rm[j][nt]==1){
			for(i=1;i<nr+1;i++){
				if(Rm[nt][i]==1) Rm[j][i]=1;
				}
			}	
		}	
}
				
/* mitteterminalide left- ja rightmost-hulkade moodustamine */
void make_LRB(void){
	int i;
	struct D *t;
	for(i=1; i<nr+1; i++){
		t=getV(T[i]);
/*		if(logi==1) fprintf(Logi,"LRM NT=%s<BR>",T[t->code]);		*/
		first_LR(t);
		}
	for(i=nr; i>tnr; i--){
		sec_LRL(i);
		sec_LRR(i);
		}
}

/* eelnevusmaatriksi koostamine: NT[i] relatsioonid maatriksisse */
int relac(struct D *t){
	struct R *r;
	int i,j,k,x,y;
	int ret=1;
	r=t->def;
ring:	if(r!=(struct R *)NULL){
			if(r->n==1) goto next;
			for(i=0;i<=r->n-2;i++){         /* def. paar x,y */
				x=r->d[i];
				y=r->d[i+1];
				if(Pm[x][y]!=0 && Pm[x][y]!=1) ret=0;
				Pm[x][y]=Pm[x][y]|1;      /* ajastub */
				if(y>tnr){         /* parem naaber on NT */
					for(k=1;k<nr+1;k++){
						if(Lm[y][k]==1){
							if(Pm[x][k]!=0 && Pm[x][k]!=2) ret=0;
							Pm[x][k]=Pm[x][k]|2;       /* iga eelneb */
							}
						}
					}
				if(x>tnr){          /* X on NT */
					for(k=1;k<nr+1;k++){
						if(Rm[x][k]==1){
							if(Pm[k][y]!=0 && Pm[k][y]!=4) ret=0;
							Pm[k][y]=Pm[k][y]|4;      /* iga j@rgneb*/
							}
						}
					}
				if((x>tnr)&&(y>tnr)){   /* X ja Y on NT */
					/* R(X) > L(Y) */
					for(j=1;j<nr+1;j++){
						if(Rm[x][j]==1){
							for(k=1;k<nr+1;k++){
								if(Lm[y][k]==1){
								if(Pm[j][k]!=0&&Pm[j][k]!=4) ret=0;
								Pm[j][k]=Pm[j][k]|4;
								}
							}
						}
					}
				}
			}
		next: r=r->alt;
		goto ring;
		}
	return(ret);
}

/* eelnevusmaatriksi koostamine: anna j�rgmine NT */
int make_PM(void){
	int i;
	int ret=1;
	struct D *t;
	for(i=tnr+1; i<nr+1; i++){
		t=getV(T[i]);
/*		fprintf(Logi,"make_PM: i=%d NT=%s<BR>",i,T[i]);
		printD(t);  */
		ret=ret & relac(t);
		}
	return(ret);	
}

/* left- ja rightmost-hulkade tr�kk */
void print_LRM(char M[HTL][HTL]){
	int i,j;
	fprintf(Logi,"<TABLE BORDER=1>");
	fprintf(Logi,"<TR><TD><FONT COLOR=\"#0000FF\">Symbol</TD>");
	for(i=1;i<nr+1;i++){
		if(Nimi[0]=='G'||Nimi[0]=='g') 
			fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\">%s</FONT></TD>",T[i]);
		else fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\">%d</FONT></TD>",i);
		}
	fprintf(Logi,"</TR>");
	for(i=tnr+1; i<nr+1; i++){
		fprintf(Logi,
			"<TR><TD>%d.<FONT COLOR=\"#0000FF\">%s</FONT></TD>",
			i,T[i]);
		for(j=1; j<nr+1; j++){
			if(M[i][j]>0)
				fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\">*</FONT></TD>");
			else fprintf(Logi,"<TD>0</TD>");			
				}
		fprintf(Logi,"</TR>");		
		}
	fprintf(Logi,"</TABLE>");
}

void cf(char *c){
	fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\"><STRONG>%s</FONT></TD>",c);
}

void p_r(char *R){
	cf(R);
	}
	
void p_cr(char *R){
	cf(R);
	}	

void print_rela(void){
int i,j,r;

	for(i=1;i<nr+1;i++){
		fprintf(Logi,
		"The relationships of <FONT COLOR=\"#0000FF\">%d</FONT>t = ",i);
		if(i<=tnr) fprintf(Logi,"%s<BR>",T[i]);
		else fprintf(Logi,"`%s'<BR>",T[i]);
		for(j=1;j<nr+1;j++){
			r=Pm[i][j];
			if(r>0){
				fprintf(Logi,"%s ",s[r]);
				if(j<=tnr) fprintf(Logi,"%s   ",T[j]);
				else fprintf(Logi,"`%s'   ",T[j]);
				}
			}
		fprintf(Logi,"<BR>");
		}
}

/* eelnevusmaatriksi tr�kk */
void print_PM(void){
	int i,j;
	fprintf(Logi,"<TABLE BORDER=1><STRONG>");
	fprintf(Logi,"<TR><TD><FONT COLOR=\"#0000FF\">Symbol</FONT></TD>");
	for(i=1;i<nr+1;i++){
		if(Nimi[0]=='G'||Nimi[0]=='g') 
			fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\">%s</FONT></TD>",T[i]);
		else fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\">%d</FONT></TD>",i);
		}
	fprintf(Logi,"</TR>");
	for(i=1; i<nr+1; i++){
		fprintf(Logi,
			"<TR><TD>%d.<FONT COLOR=\"#0000FF\">%s</FONT></TD>",
			i,T[i]);
		for(j=1; j<nr+1; j++){
			switch(Pm[i][j]){
				case 0: fprintf(Logi,"<TD>0</TD>"); break;
				case 1: cf("="); break;
				case 2: cf("&lt"); break;
				case 4: cf("&gt"); break;
				default: fprintf(Logi,
					"<TD><FONT COLOR=\"#FF0000\"><STRONG> %d</FONT></TD>",
					Pm[i][j]);
					break;
				}
			}
			fprintf(Logi,"</TR>");		
		}
	fprintf(Logi,"</TABLE>");
}

/* stratifikatsioon paremale (P2-konflikt) */
void s_to_right(int lim, struct D *t,struct R *d){
	int k,r;
	char *sec;	
	struct D *n;
	struct R *b;
	fprintf(Logi,"The source is the production ");
	print_rule(t,d);
	memset(word,'\0',20);
	sprintf(word,"%s%d",T[t->code],Index);
	NR++;
	if(NR>HTL){
		sprintf(rida,"too many symbols");
		ExiT(rida);
		}
	memcpy(T[NR],word,20);
	Index++;
	DC=newD();
	b=newR();
	r=d->n-lim;
	b->d=DefVect(r);
	memset(b->d,'\0',r);
	r=0;
	for(k=lim;k<d->n;k++){ 
		b->d[r]=d->d[k];
		r++;
		}
	b->n=r;
	DC->def=b;
	DC->code=NR;
	DC->tunnus=0;
	DC->L=t->L+1;
	b->P=Pnr;
	Pnr++;
	n=search(1);
	fprintf(Logi," I'll add a new NT ");
	print_rule(DC,b);

/* uus reegel on valmis. */					
	r=lim+1;
	sec=DefVect(r);
	memset(sec,'\0',r);
	for(k=0;k<lim;k++) sec[k]=d->d[k];  
	sec[lim]=NR;
	d->n=lim+1;
/*	free(d->d);  */
	d->d=sec;
	fprintf(Logi,"  I'll change the production ");
	print_rule(t,d);
	fflush(Logi);
}	

/* P2_konflikti likvideerimine:
      A->xXYy asendada k6ikjal A->xXD, kus D->Yy  */
void P2(int x,int y){
	int i,j;
	struct D *t;
	struct R *d;
    /* otsin konflikti allikaid: definitsioone, kus on paar XY */ 	
	for(i=tnr+1; i<nr+1; i++){
		t=getV(T[i]);
		d=t->def;
ring: if(d!=(struct R *)NULL){	
		for(j=0;j<d->n-1;j++){
			if(d->d[j]==x){
				if(d->d[j+1]==y) s_to_right(j+1,t,d);
				}
			}
		d=d->alt;
		goto ring;
		}
	}
}

/* stratifikatsioon vasakule (P1-konflikt) */
void s_to_left(int lim, struct D *t,struct R *d){
	int k,r;
	char *sec;
	struct D *n;
	struct R *b;
	fprintf(Logi,"The source is the production ");
	print_rule(t,d);
	r=t->L;
	memset(word,'\0',20);
	sprintf(word,"%s%d",T[t->code],Index);
	NR++;
	if(NR>HTL){
		sprintf(rida,"too many symbols");
		ExiT(rida);
		}
	memcpy(T[NR],word,20);
	Index++;
	DC=newD();
	b=newR();
	b->d=DefVect(lim);
	memset(b->d,'\0',lim);
	for(k=0;k<lim;k++) b->d[k]=d->d[k];
	b->n=lim;
	DC->def=b;
	DC->code=NR;
	DC->tunnus=0;
	DC->L=r+1;
	b->P=Pnr;
	Pnr++;
	n=search(1);
	fprintf(Logi," I'll add a new NT ");
	print_rule(DC,b);
/* uus reegel on valmis. */					
	r=d->n-lim;
	sec=DefVect(r);
	memset(sec,'\0',r);
	sec[0]=n->code;
	r=1;
	for(k=lim;k<d->n;k++){
		sec[r]=d->d[k];
		r++;
		} 
	d->n=r;
/*	free(d->d); */
	d->d=sec;
	fprintf(Logi,"  I'll change the production ");
	print_rule(t,d);
	fflush(Logi);	
}	

/* P1-konflikti likvideerimine:
   A->xXYy asendada k6ikjal A->DYy, kus D->xX  */
void P1(int x,int y){
	int i,j,u;
	struct D *t;
	struct R *d;
/* otsin konflikti allikaid: definitsioone, kus on paar XY 
   v�i XZ ja Y kuulub LM[Z]*/
for(i=tnr+1; i<nr+1; i++){
	t=getV(T[i]);
	d=t->def;
ring: if(d!=(struct R *)NULL){	
		for(j=0;j<d->n-1;j++){
			if(d->d[j]==x){
				if(d->d[j+1]==y){
					s_to_left(j+1,t,d);
					}
				else{
					if(d->d[j+1]>tnr){
						u=d->d[j+1];
						if(Lm[u][y]==1)	s_to_left(j+1,t,d);
						}
					}			
				}
			}	
		d=d->alt;
		goto ring;
		}
	}
}

/* teade eelnevuskonfliktist */
void tell_conf(int p,int i,int j,int c){
	fprintf(Logi,"<FONT COLOR=\"#FF0000\">");
	fprintf(Logi,"<BR>P%d-conflict: </FONT>",p);
	if(i<=tnr) fprintf(Logi,"%s <FONT COLOR=\"#FF0000\">%s </FONT>",T[i],s[c]);
	else fprintf(Logi,"`%s' <FONT COLOR=\"#FF0000\">%s </FONT>",T[i],s[c]);
	if(j<=tnr) fprintf(Logi,"%s<BR>",T[j]);
	else fprintf(Logi,"`%s'<BR>",T[j]);	
	fprintf(Logi,"</FONT>");
}	

/* eelnevuskonfliktide detekteerimine ja likvideerimine */
int conflicts(void){
	int i,j;
	int res=0;
	int oldN;
	NR=nr;
	for(i=1;i<nr+1;i++){
		for(j=1;j<nr+1;j++){
			if(Pm[i][j]==3){
				res=1;
				tell_conf(2,i,j,3);
				oldN=NR;
				P2(i,j);
				if(NR==oldN){
					fprintf(Logi,"Cannot find any source");
/*					ExiT();  */
					}
				}
			}
		}
	if(res==0) goto p1;
	memset(Lm,'\0',HTL*HTL);
	memset(Rm,'\0',HTL*HTL);
	nr=NR;
	make_LRB();
	fprintf(Logi,"<H4>Leftmost-set</H4>");
	print_LRM(Lm);  
p1:	for(i=1;i<nr+1;i++){
		for(j=1;j<nr+1;j++){
			if(Pm[i][j]>4){
				res=1;
				tell_conf(1,i,j,Pm[i][j]);
				oldN=NR;
				P1(i,j);
				if(NR==oldN){
					fprintf(Logi,"Cannot find any source");
					goto out;
					}
				}
			}
		}
out:
	nr=NR;
	return(res);
}

/* vasaku konteksti maatriksi tr�kk */
void print_LC(void){
	int i,j;
	fprintf(Logi,"<TABLE BORDER=1>");
	fprintf(Logi,"<TR><TD><FONT COLOR=\"#0000FF\">Symbol</TD>");
	for(i=1;i<nr+1;i++){
		if(Nimi[0]=='G'||Nimi[0]=='g') 
			fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\">%s</TD>",T[i]);
		else fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\">%d</TD>",i);
		}
	fprintf(Logi,"</TR></FONT>");
	for(i=tnr+1; i<nr+1; i++){
		fprintf(Logi,
			"<TR><TD>%d.<FONT COLOR=\"#0000FF\">%s</FONT></TD>",
			i,T[i]);
		for(j=1; j<nr+1; j++){
			if(LC[addr(i,j)]>0)
				fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\">*</FONT></TD>");
			else fprintf(Logi,"<TD>0</TD>");			
				}
		fprintf(Logi,"</TR>");		
		}
	fprintf(Logi,"</TABLE>");
}

/* parema konteksti maatriksi tr�kk */
void print_RC(void){
	int i,j;
	fprintf(Logi,"<TABLE BORDER=1>");
	fprintf(Logi,"<TR><TD><FONT COLOR=\"#0000FF\">Symbol</TD>");
	for(i=1;i<tnr+1;i++){
		if(Nimi[0]=='G'||Nimi[0]=='g') 
			fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\">%s</TD>",T[i]);
		else fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\">%d</TD>",i);
		}
	fprintf(Logi,"</TR></FONT>");
	for(i=tnr+1; i<nr+1; i++){
		fprintf(Logi,
			"<TR><TD>%d.<FONT COLOR=\"#0000FF\">%s</FONT></TD>",
			i,T[i]);
		for(j=1; j<tnr+1; j++){
			if(RC[addr(i,j)]>0)
				fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\">*</FONT></TD>");
			else fprintf(Logi,"<TD>0</TD>");			
				}
		fprintf(Logi,"</TR>");		
		}
	fprintf(Logi,"</TABLE><BR><BR>");
}


/* mitteterminali s�ltumatu konteksti hulga moodustamine */
void brc(int NT){
	int A,i;
	A=NT;
	for(i=1;i<nr+1;i++){
		if((Pm[i][A]==1)||(Pm[i][A]==2)) LC[addr(A,i)]=1;
		}
	for(i=1;i<tnr+1;i++){
		if(Pm[A][i]>0) RC[addr(A,i)]=1;
		}
}

/* mitteterminali s�ltumatu konteksti hulga tr�kk */
void p_brc(int NT){
	int A,i,f;
	A=NT;
	f=0;
	fprintf(Logi,"<FONT COLOR=\"#0000FF\">`%s' left context: </FONT>",T[NT]);
	for(i=1;i<nr+1;i++){
		if(LC[addr(A,i)]==1){
			if(f==0) f++;
			else fprintf(Logi,"<FONT COLOR=\"#FF4500\"><STRONG> , </FONT>");
			if(i<=tnr) fprintf(Logi," %s ",T[i]);
			else fprintf(Logi," `%s' ",T[i]);
			}
		}
	fprintf(Logi,"<BR></FONT>");	
	f=0;
	fprintf(Logi,"<FONT COLOR=\"#0000FF\">`%s' right context: </FONT>",T[NT]);
	for(i=1;i<tnr+1;i++){
		if(RC[addr(A,i)]==1){
			if(f==0) f++;
			else fprintf(Logi,"<FONT COLOR=\"#FF4500\"><STRONG> , </FONT>");
			fprintf(Logi,"%s ",T[i]);
			}			
		}
	fprintf(Logi,"<BR><BR>");	
}


void make_all_indep(void){
int i;
for(i=tnr+1;i<nr+1;i++) brc(i);
fprintf(Logi,"<FONT COLOR=\"#0000FF\"><H4>Left Context</H4></FONT><BR>");
print_LC();
fprintf(Logi,"<BR><FONT COLOR=\"#0000FF\"><H4>Right Context</H4></FONT><BR>");
print_RC();
}	

int deptest(struct h *x,struct h *y){
	BRC++;
	fprintf(Logi,"independent context didn't help us. ");
     fprintf(Logi,"I'll try to use the dependent one.<BR>");
     if(DEP==NULL) DEP=defDEP();
     dc=1;
	memset(word,'\0',20);
	si=0;
	dc=search_springs(x,x->NT);
	if(dc==0) return(0);
	memset(word,'\0',20);
	si=0;
	dc=search_springs(y,y->NT);
	if(dc==1){
		dc=test_dep_con(x,y);
		if(dc==1) dep++;
		}
	return(dc);
}

int testpaar(int A,int B){
	int i,s;
	s=0;
	for(i=1;i<nr+1;i++){
		if(LC[addr(A,i)]==1){
			if(LC[addr(B,i)]==1) goto rc;
			}
		}
	fprintf(Logi,"<FONT COLOR=\"#008000\">The left context of </FONT>");
	fprintf(Logi,"`%s' ",T[A]);
	fprintf(Logi,"<FONT COLOR=\"#008000\">and </FONT> `%s'",T[B]);
	fprintf(Logi,"<FONT COLOR=\"#008000\"> is different<BR></FONT>");
	return(0);
rc:	for(i=1;i<tnr+1;i++){
		if(RC[addr(A,i)]==1){
			if(RC[addr(B,i)]==1){
				fprintf(Logi,"<FONT COLOR=\"#FF0000\">");
				fprintf(Logi,
				"The independent context of </FONT>`%s' <FONT COLOR=\"#FF0000\">and </FONT>`%s' <FONT COLOR=\"#FF00000\">is not different<BR>",
				T[A],T[B]);
				fprintf(Logi,"</FONT><HR>");
				return(1);
				}
			}
		}	
	fprintf(Logi,"<FONT COLOR=\"#008000\">The right context of </FONT>");
	fprintf(Logi,"`%s' ",T[A]);
	fprintf(Logi,"<FONT COLOR=\"#008000\">and </FONT> `%s'",T[B]);
	fprintf(Logi,"<FONT COLOR=\"#008000\"> is different<BR></FONT>");
	return(0);
}

/*  mitteterminalide konteksti eristumise test */
int brctest(struct h *t){
	struct h *x,*y;
	struct h *SAM[20];
	int ns;
	int j,k,A,B;
	x=t;
	ns=0;
fill: SAM[ns]=x;
	ns++;
	x=x->same;
	if(x!=(struct h *)NULL) goto fill;

	for(j=0;j<ns-1;j++){
		x=SAM[j];
		A=x->NT;
		for(k=j+1;k<ns;k++){
			y=SAM[k];
			B=y->NT;
			/* if(testpaar(A,B)!=0) */
			deptest(x,y);
			}
		}	
	return(1);
}

/* otsib �hesuguse parema poolega produktsioone, teeb C1|1-hulgad */
int make_BRC(void){
	struct h *CP,*S;
	int i,j,k;
	char *r;
	BRC=0;
/*	for(i=0; i<nr+1; i++){  */
	for(i=0; i<HTL; i++){
		CP=HT[i];
		while(CP != (struct h *)NULL){
			if(CP->same!=(struct h *)NULL){
				fprintf(Logi,"<FONT COLOR=\"#FF0000\">");
				fprintf(Logi,"Equivalent definitions:</FONT><BR>");
				S=CP;
				p: fprintf(Logi,"`%s' &#151&gt ",T[S->NT]);
				for(j=0;j<S->n;j++){
					k=S->d[j];
					r=T[k];
					if(k<=tnr) fprintf(Logi,"%s ",r);
					else fprintf(Logi,"`%s' ",r);
					}
				S=S->same;
				if(S==(struct h *)NULL) goto B;
				fprintf(Logi,"<FONT COLOR=\"#FF0000\"> &amp </FONT>");
				goto p;
				B: fprintf(Logi,"<BR>");
				p_brc(CP->NT);
				}
			S=CP->same;
			while(S != (struct h *)NULL){
				p_brc(S->NT);
				S=S->same;
				}
			if(CP->same!=(struct h *)NULL){
				fprintf(Logi,"<BR>");
				if(brctest(CP)==0) return(0);
				fprintf(Logi,"<BR>");
				}
			CP=CP->col;
			}
	}
	return(1);
}

void pset(int x,int y){
	fprintf(Logi," {");
	fprintf(Logi,"<FONT COLOR=\"#0000FF\">");
	if(x<=tnr) fprintf(Logi,"%s ",T[x]);
	else fprintf(Logi,"`%s' ",T[x]);
	if(y<=tnr) fprintf(Logi,"%s",T[y]);
	else fprintf(Logi,"`%s'",T[y]);
	fprintf(Logi,"</FONT>");
	fprintf(Logi,"} ");	
}

void priv(char *v){
	int i;
	for(i=0;i<tnr+1;i++) fprintf(Logi,"%d ",v[i]);
	fprintf(Logi,"<BR>");
}	

void print_DEP(void){
char **L;
char *rc;
int i,j,k;
	for(i=0;i<nr+1;i++){
		L=DEP[i];
		if(L!=(char **)NULL){
			fprintf(Logi,"<BR>DEP[%d]=%p<BR>",i,L);
			for(j=0;j<nr+1;j++){
				rc=L[j];
				if(rc!=(char *)NULL){
					fprintf(Logi,"L[%d]=%p<BR>",j,rc);
					for(k=0;k<tnr+1;k++)
					   fprintf(Logi,"rc[%d]=%d ",k,rc[k]);
					fprintf(Logi,"<BR>");
					}
				}
			}
		}
}

void join_cxt(char **D,char **S){
	int i,j;
	char *rc,*src;
	for(i=1;i<nr+1;i++){
		if(S[i]!=(char *)NULL){
			src=S[i];
			rc=D[i];
			if(rc==(char *)NULL){
				rc=DefVect(tnr+1);
				D[i]=rc;
				}
			for(j=1;j<tnr+1;j++) rc[j]=src[j];
			}
		}
}

int test_cxt(char **D,char **S){
	int i,j,x;
	int flag=1;
	char *rc,*src;
	for(i=1;i<nr+1;i++){
		src=S[i];
		if(src!=(char *)NULL){
			rc=D[i];
			if(rc!=(char *)NULL){
				for(j=1;j<tnr+1;j++){
					x=rc[j];
					if(x==1){
						if(src[j]==1){
							flag=0;
							fprintf(Logi,
								"<FONT COLOR=\"red\"><BR>common:</FONT>");
							pset(i,j);
							fprintf(Logi,"<BR>");
							}
						}
					}
				}
			}
		}
	return(flag);
}

void print_cxt(char **L){
	int i,j;
	char *rc;
	for(i=1;i<nr+1;i++){
		rc=L[i];
		if(rc!=(char *)NULL){
			for(j=1;j<tnr+1;j++){
				if(rc[j]==1) pset(i,j);
				}
			}
		}
}

void print_cxtp(char **L){
int i;
	char *rc;
	for(i=1;i<nr+1;i++){
		rc=L[i];
		if(rc!=(char *)NULL) fprintf(Logi,"L[%d]=%p<BR>",i,rc);
		}
}

void print_all_cxt(void){
char **L;
int i;
	for(i=tnr+1;i<nr+1;i++){
		L=DEP[i];
		if(L!=(char **)NULL){
			fprintf(Logi,"<BR>dependent context of %s:<BR>",T[i]);
			print_cxt(L);
			fprintf(Logi,"<BR>");
			}
		}
	print_DEP();	
}

void print_all_cxtp(void){
char **L;
int i;
	for(i=tnr+1;i<nr+1;i++){
		L=DEP[i];
		if(L!=(char **)NULL){
			fprintf(Logi,"DEP[%d]=%p<BR>",i,L);
			print_cxtp(L);
			}
		}
}

/* s�ltuv kontekst. g1(A)={(X,T) | B->uXADv & [T=D or T in L(D)]}  */
int g1(char **L,int X,int D){
	int i;
	char *rc;
	rc=L[X];
	if(rc==(char *)NULL){
		rc=DefVect(tnr+1);
		L[X]=rc;
		}
	if(D>tnr){
		for(i=1;i<tnr+1;i++){
			if(Lm[D][i]==1){
				rc[i]=1;
				pset(X,i);
				}
			}
		}
	else{
		rc[D]=1;
		pset(X,D);
		}
	fprintf(Logi,"<BR>");
	return(1);
}

/* s�ltuv kontekst. g2(A)={(X,T) | B->uXA & T in RC(B)]}  */
int g2(char **L,struct h *t,int X){
	int i;
	char *rc;
	rc=L[X];
	if(rc==(char *)NULL){
		rc=DefVect(tnr+1);
		L[X]=rc;
		}
	for(i=1;i<tnr+1;i++){
		if(RC[addr(t->NT,i)]==1){
			rc[i]=1;
			pset(X,i);
			}
		}
	fprintf(Logi,"<BR>");
	return(1);
}

/* s�ltuv kontekst. g3(A)={(X,T) | B->ADv & X in LC(B) & [T=D or T in L(D)]} */
int g3(char **L,struct h *t,int D){
int i,j;
char *rc;
for(i=1;i<=nr;i++){
	if(LC[addr(t->NT,i)]==1){
		if(D<=tnr){
			rc=L[i];
			if(rc==(char *)NULL){
				rc=DefVect(tnr+1);
				L[i]=rc;
				}
			rc[D]=1;
			pset(i,D);
			}
		else{
			for(j=1;j<tnr+1;j++){
				if(Lm[D][j]==1){
					rc=L[i];
					if(rc==(char *)NULL){
						rc=DefVect(tnr+1);
						L[i]=rc;
						}
					rc[j]=1;
					pset(i,j);
					}
				}
			}
		}
	}
	fprintf(Logi,"<BR>");
	return(1);
}

/* s�ltuv kontekst. g4(A)={(X,T) | B->A & (X,T) in C1,1(B)}  */
int g4(char **L,struct h *t){
	char **S;
	if(t->nc==0) search_springs(t,t->NT);
	if(dc==0) return(0);
	S=DEP[t->NT];
	join_cxt(L,S);
	return(1);
}

/* otsib mitteterminali A s�ltuva konteksti allikaid, moodustab C1,1(A) */
int search_springs(struct h *t,int A){
char **L;
struct h *C;
int i,j,k;
L=DEP[A];
if(L==(char **)NULL){
	L=defL();
	DEP[A]=L;
	}
     fprintf(Logi,"<BR><BR>I'll find the subsets of dependent context of `%s'<BR>",
		T[t->NT]);
for(i=0;i<si+1;i++){
	if(word[i]==A){
		fprintf(Logi,"<BR>deadlock, the next will be `%s'<BR>",T[A]);
		for(j=0;j<i+1;j++){
			k=word[j];
			fprintf(Logi,"  %s ",T[k]);
			}
		fprintf(Logi,"<BR>");
		dc=0;
		goto out;
		}
	}	
word[si]=A;
si++;
for(i=0;i<HTL;i++){
	C=HT[i];
	while(C!=(struct h *)NULL){
		for(j=0;j<C->n;j++){
			if(C->d[j]==A){
				if((j==0)&&(C->n==1)){
					fprintf(Logi,"<FONT COLOR=\"#008000\">");
					fprintf(Logi,
					"gamma4:</FONT> the source is the production <BR>");
					print_h(C);
					if(g4(L,C)==0) goto out;
					goto nextj;
					}			
				if(j==0){
					fprintf(Logi,"<FONT COLOR=\"#008000\">");
					fprintf(Logi,
					"gamma3: </FONT> the source is the production <BR>");
					print_h(C);
					g3(L,C,C->d[1]);
					goto nextj;
					}
				if((j>0)&&(j!=C->n-1)){
					fprintf(Logi,"<FONT COLOR=\"#008000\">");
					fprintf(Logi,
					"gamma1: </FONT> the source is the production <BR>");
					print_h(C);
				     g1(L,C->d[j-1],C->d[j+1]);
					goto nextj;
					}
				if(j==C->n-1){
					fprintf(Logi,"<FONT COLOR=\"#008000\">");
					fprintf(Logi,
					"gamma2:</FONT> the source is the production <BR>");
					print_h(C);
					g2(L,C,C->d[C->n-2]);
					goto nextj;
					}
				}	
			nextj: k=k;	
			}		
		C=C->col;
		}
	}
word[si]='\0';
si--;
t->nc=1;
fprintf(Logi,"<BR>The set of dependent context of `%s':<BR>",T[A]);
print_cxt(L);
fprintf(Logi,"<BR>");
out:	return(dc);
}

void p_nlist(){
struct U *u;	
u=UP;
fprintf(Logi,"<FONT COLOR=\"#FF0000\">");
fprintf(Logi,
 "<BR>The following pairs of nonterminals are having nondifferent context:<BR>");
fprintf(Logi,"</FONT>");
while(u!=(struct U *)NULL){
	fprintf(Logi,"`%s'",T[u->x]);
	fprintf(Logi,"<FONT COLOR=\"#FF0000\">and </FONT>");
	fprintf(Logi,"`%s'<BR>",T[u->y]);
	u=u->next;
	}
fprintf(Logi,"<BR>");
}		

void add_not(int x,int y){
	struct U *u;
	u=(struct U *)malloc(sizeof(struct U));
	u->x=x;
	u->y=y;
	u->next=UP;
	UP=u;
}	

/* C1,1(A) ja C1,1(B) eristumise test */
int test_dep_con(struct h *x,struct h *y){
	int flag;
	char **A,**B;

	A=DEP[x->NT];
	B=DEP[y->NT];
	fprintf(Logi,"<BR>test_dep_con ");	
	fprintf(Logi,"<FONT COLOR=\"#0000FF\"> %s </FONT> and ",T[x->NT]);
	fprintf(Logi,"<FONT COLOR=\"#0000FF\"> %s </FONT><BR>",T[y->NT]);
	flag=test_cxt(A,B);
	if(flag==0){
		fprintf(Logi,"<FONT COLOR=\"#FF0000\">");
		fprintf(Logi,
			"<BR>dependent context is not different: </FONT>%s ",T[x->NT]);
		fprintf(Logi,"<FONT COLOR=\"#FF0000\">and </FONT>");
		fprintf(Logi," %s<BR>",T[y->NT]);
		add_not(x->NT,y->NT);
		fprintf(Logi,"<HR>");
		return(0);
		}
	BRC--;
	fprintf(Logi,"<FONT COLOR=\"#008000\">");
	fprintf(Logi,"<BR>dependent context of `%s' and `%s' is different<BR></FONT>",
			T[x->NT],T[y->NT]);
	fprintf(Logi,"<HR>");		
	return(1);
}

void print_h_lyli(struct h *s){
int i;
	fprintf(Logi," h %p: P=%d n=%d NT=%d d=%p nc=%d same=%p col=%p",
       s,s->P,s->n,s->NT,s->d,s->nc,s->same,s->col);
	fprintf(Logi,"  (%s)<BR>",T[s->NT]);       
	fprintf(Logi," d %p: ",s->d);
	for(i=0;i<s->n;i++) fprintf(Logi,"%d ",s->d[i]);
	fprintf(Logi,"<BR>");
	if(s->same!=(struct h *)NULL) print_h_lyli(s->same);	
	if(s->col!=(struct h *)NULL) print_h_lyli(s->col);
}

void print_h_tabel(void){
struct h *t;
int i;
	for(i=0;i<HTL;i++){
		t=HT[i];
		if(t!=(struct h *)NULL) print_h_lyli(t);
		}
}

/* t�hestiku V puu tipu tr�kk */
void printD(struct D *t){
struct R *r;
int i;
fprintf(Logi," D %p: tunnus=%d code=%d L=%d loc=%d icx=%d left=%p right=%p def=%p   ", 
t,t->tunnus,t->code,t->L,t->loc,t->icx,t->left,t->right,t->def);
fprintf(Logi,"(%s)<BR>",T[t->code]);
r=t->def;
ring:	if(r != (struct R *)NULL){
		fprintf(Logi," R %p: P=%d sem=%d n=%d d=%p alt=%p<BR>",
		r,r->P,r->sem,r->n,r->d,r->alt);
		fprintf(Logi," d %p: ",r->d);
		for(i=0;i<r->n;i++){
			fprintf(Logi,"%d ",r->d[i]);
			}
		fprintf(Logi,"<BR>");
		r=r->alt;
		goto ring;
		}
}

/* t�hestiku V v�ljatr�kk */
void print_tree(struct D *t){
	if(t->left != (struct D *)NULL) print_tree(t->left);
	printD(t);
	if(t->right != (struct D *)NULL) print_tree(t->right);
}

FILE *opw(void){
	FILE *of=NULL;
	of=fopen(rida,"wb");
	if (of==NULL){
		fclose(of);
		fprintf(Logi,"<BR>cannot create the file %s<BR>",rida);
		}
	return(of);
}

void w_V(FILE *of,struct D *t){
	struct R *d;
	struct R *prev;
	int q;
	if(t!=(struct D *)NULL){
		q=fwrite(t,sizeof(struct D),1,of);
		if(q!=1){
			sprintf(rida,"write error w_V()<BR>");  
			ExiT(rida);
			}
		if(t->tunnus==0){
			d=t->def;
			while(d!=(struct R *)NULL){
				q=fwrite(d,sizeof(struct R),1,of);
				if(q!=1){
					sprintf(rida,"write error w_V()<BR>");  
					ExiT(rida);
					}
				q=fwrite(d->d,d->n,1,of);
				if(q!=1){
					sprintf(rida,"write error w_V()<BR>");  
					ExiT(rida);
					}
				prev=d; 
				d=d->alt;
				}
			}	
		w_V(of,t->left);
		w_V(of,t->right);
		}
}		

void w_DEP(FILE *of){
	int i,j,q;
	char **L;
	char *rc;
	q=fwrite(DEP,sizeof(char ***),nr+1,of);
	if(q!=nr+1){
		sprintf(rida,"write error w_DEP()<BR>");  
		ExiT(rida);
		}
	for(i=0;i<(nr+1);i++){
		if(DEP[i]!=(char **)NULL){
			L=DEP[i];
			q=fwrite(L,sizeof(char **),nr+1,of);
			if(q!=nr+1){
				sprintf(rida,"write error w_DEP()<BR>");
				ExiT(rida);
				}
			for(j=0;j<nr+1;j++){
				rc=L[j];
				if(rc!=(char *)NULL){
					q=fwrite(rc,tnr+1,1,of);
					if(q!=1){
						sprintf(rida,"write error w_DEP()<BR>");
						ExiT(rida);
						}
					}
				}
			}
		}
}					
				

void w_hr(FILE *of,struct h *r){
	int q;
	q=fwrite(r,sizeof(struct h),1,of);
	if(q!=1){
		sprintf(rida,"write error w_hr()<BR>");
		ExiT(rida);
		}
	q=fwrite(r->d,r->n,1,of);
	if(q!=1){
		sprintf(rida,"write error w_hr()<BR>");
		ExiT(rida);
		}
	if(r->same!=(struct h *)NULL) w_hr(of,r->same);
	if(r->col!=(struct h *)NULL) w_hr(of,r->col);
}	

void w_HT(FILE *of){
	int i,q;
	q=fwrite(HT,sizeof(struct h *),HTL,of);
	if(q!=HTL){
		sprintf(rida,"write error w_HT()<BR>");
		ExiT(rida);
		}		
	for(i=0;i<HTL;i++){
		if(HT[i]!=(struct h *)NULL){
			w_hr(of,HT[i]);
			HT[i]=(struct h *)NULL;
			}
		}
}					

 void w_PM(void){
	int i,j,q;
	sprintf(rida,"%s.pm",Nimi);
	of=opw();
	if(of==NULL){
		sprintf(rida,"create error w_PM()<BR>");
		ExiT(rida);
		}
	PM=DefArray(nr+1);
	for(i=1;i<=nr;i++){
		for(j=1;j<=nr;j++){
			PM[addr(i,j)]=Pm[i][j];
			}
		}	
	q=fwrite(PM,(nr+1)*(nr+1),1,of);
	if(q!=1){
		sprintf(rida,"write error w_PM()<BR>");  
		ExiT(rida);
		}
	fclose(of);
}  

void p_w(struct stat *b){
	int p;
	if(stat(rida,b)==-1){
		sprintf(rida,"w_tabs: stat failed<BR>");
		ExiT(rida);
		}
	p=b->st_size;
	fprintf(Logi,"<TR><TD>%s</TD><TD ALIGN=\"right\">%d</TD></TR>",rida,p);	
}	

int w_tabs(void){
	int q;
	struct stat *buf;
	fprintf(Logi,"<H3><FONT COLOR=\"#0000FF\">Result tables</H3><BR>");
	fprintf(Logi,"<TABLE BORDER=1><TR>");
	fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\">File</TD><TD><FONT COLOR=\"#0000FF\">Size</TD></FONT>");
	buf=(struct stat *)malloc(sizeof(struct stat));
	if(buf==NULL){
		sprintf(rida,"w_tabs: I haven't %d bytes of memory..<BR>",
			sizeof(struct stat));
		ExiT(rida);
		}		
	PARM=(struct parm *)malloc(sizeof(struct parm));
	if(PARM==(struct parm *)NULL){
		sprintf(rida,"cannot create PARM<CR>");
		ExiT(rida);
		}
	memset(PARM,'\0',sizeof(struct parm));
	PARM->nr=nr;
	PARM->tnr=tnr;
	PARM->Pnr=Pnr;
	PARM->BRC=context;
	PARM->dep=dc;
	sprintf(rida,"%s.prm",Nimi);
	of=opw();
	if(of==NULL) goto bad;
	q=fwrite(PARM,sizeof(struct parm),1,of);
	if(q!=1){
		sprintf(rida,"write error PARM<BR>");  
		ExiT(rida);
		}
	fclose(of);
	p_w(buf);

	w_PM();
	p_w(buf);	

	sprintf(rida,"%s.t",Nimi);
	of=opw();
	if(of==NULL) goto bad;
	q=fwrite(&T,20,nr+1,of);	
	if(q!=nr+1){ 
		sprintf(rida,"write error w_T)<BR>");  
		ExiT(rida);
		}
	fclose(of);
	p_w(buf);

	sprintf(rida,"%s.ht",Nimi);
	of=opw();
	if(of==NULL) goto bad;
	w_HT(of);
	fclose(of);
	p_w(buf);

	if(semantika!=(char *)NULL){
		sprintf(rida,"%s.sm",Nimi);
		of=opw();
		if(of==NULL) goto bad;
		q=fwrite(semantika,tnr+Pnr+1,1,of);
		if(q!=1){
			sprintf(rida,"write error w_semantics<BR>");  
			ExiT(rida);
			}
		fclose(of);
		p_w(buf);
		}

	if(DT!=(struct D *)NULL){
		sprintf(rida,"%s.v",Nimi);
		of=opw();
		if(of==NULL) goto bad;
		w_V(of,DT);
		fclose(of);
		p_w(buf);
		}

	if(context==1){
		sprintf(rida,"%s.lc",Nimi);
		of=opw();
		if(of==NULL) goto bad;
		q=fwrite(LC,(nr+1)*(nr+1),1,of);
		if(q!=1){
			sprintf(rida,"write error w_LC<BR>");  
			ExiT(rida);
			}
		fclose(of);
		p_w(buf);

		sprintf(rida,"%s.rc",Nimi);
		of=opw();
		if(of==NULL) goto bad;
		q=fwrite(RC,(nr+1)*(nr+1),1,of);
		if(q!=1){
			sprintf(rida,"write error w_RC<BR>");  
			ExiT(rida);
			}		
		fclose(of);
		p_w(buf);
		}
	if(dc==1){
		sprintf(rida,"%s.dc",Nimi);
		of=opw();
		if(of==NULL) goto bad;
		w_DEP(of);
		fclose(of);
		p_w(buf);	
		}
	goto out;
bad:	sprintf(rida,"<BR>cannot write all the tables of %s.grm<BR>",Nimi);
	ExiT(rida);
out:    
	fprintf(Logi,"</TABLE>");
	fflush(Logi);
	return(1);
}
 
char *gM(int p){
	char *ptr=NULL;
	ptr=malloc(p);
	if(ptr==NULL){
		sprintf(rida,"gM: I haven't %d bytes of memory..",p);
		ExiT(rida);
		}
	return(ptr);
}

/* t�hestiku v�ljatr�kk */
void pT(int v){
int j,i,p;
j=(v==0) ? 1 : tnr+1;
p=(v==0) ? tnr+1 : nr+1;
	for(i=j;i<p;i++){
		fprintf(Logi,"<FONT COLOR=\"008000\"> #%2d = </FONT>",i);
		if(v==0) fprintf(Logi,"%s<BR>",T[i]);
		else fprintf(Logi,"`%s'<BR>",T[i]);		
		}
	fprintf(Logi,"<BR>");
}

/* eraldab m�lu uuele tipule t�hestiku V puusse */
struct D *newD(void){
	struct D *ptr;
	ptr=(struct D *)malloc(sizeof(struct D));
	if(ptr==NULL){
		sprintf(rida,"newD: I don't have memory enaugh..");
		ExiT(rida);
		}
	memset(ptr,'\0',sizeof(struct D));
	ptr->left=(struct D *)NULL;
	ptr->right=(struct D *)NULL;
	ptr->def=(struct R *)NULL;
	return(ptr);
}

/* eraldab m�lu uuele NT-definitsioonile */
struct R *newR(void){
	struct R *ptr;
	ptr=(struct R *)malloc(sizeof(struct R));
	if(ptr==NULL){
		sprintf(rida,"newR: I don't have memory enaugh..");	
		ExiT(rida);
		}
	memset(ptr,'\0',sizeof(struct R));
	ptr->alt=(struct R *)NULL;
	return(ptr);
}


/* vabastab NT-definitsiooni m�lu */
void free_R(struct R *r){
	if(r != (struct R *)NULL){
		 free_R(r->alt);
		 free(r->d);
		 free(r);
		 }
}

/* vabastab t�hestiku V puuga h�ivatud m�lu */
void free_tree(struct D *t){
	if(t!=(struct D *)NULL){
		free_tree(t->left);
		free_tree(t->right);
		free_R(t->def);
		free(t);
		}
}

/* mitteterminali definitsiooni(de) tr�kk */
void printR(struct R *r){
int i,j;
char *s;
ring:	if(r != (struct R *)NULL){
		fprintf(Logi,"dl=%d<BR>",r->n);
		for(i=0;i<r->n;i++){
			j=r->d[i];
			s=T[j];		
			fprintf(Logi,"%s ",s);
			}
		fprintf(Logi,"<BR>");
		r=r->alt;
		goto ring;
		}
}

/* t�hestiku V elemendi otsimine/lisamine (x=1), otsimine (x=0) */
struct D *search(int x){
	struct D *t;
	int res;
	t=DT;
	if(t==(struct D *)NULL){
		if(x==0) goto exit;
		DT=DC;
		t=DC;
		goto out;
		}
ring: if(t->loc==0) res=strcmp(word,T[t->code]);
	 else res=strcmp(word,T[t->loc]);
	 if(res==0){
/*		free(DC);  */
		goto out;
		}
	 if(res<0){
		if(t->left != (struct D *)NULL){
			t=t->left;
			goto ring;
			}
		 else{
			if(x==0) goto exit;
			t->left=DC;
			t=DC;
			goto out;
			}
		}
		if(res>0){
			if(t->right != (struct D *)NULL){
				t=t->right;
				goto ring;
				}
			else{
				if(x==0) goto exit;
				t->right=DC;
				t=DC;
				goto out;
				}
			}
	goto out;
exit:	t=(struct D *)NULL;
/*	free(DC);			 */
out:	return(t);
}


/* t�hestiku V elemendi otsimine */
struct D *getV(char *key){
	struct D *t;
	int res;
	t=DT;
	if(t==(struct D *)NULL) goto exit;
ring:	if(t->loc==0) res=strcmp(key,T[t->code]);
		else res=strcmp(key,T[t->loc]);	
		if(res==0) goto out;
		if(res<0){
			if(t->left != (struct D *)NULL){
				t=t->left;
				goto ring;
				}
			else goto exit;
			}
		if(res>0){
			if(t->right != (struct D *)NULL){
				t=t->right;
				goto ring;
				}
			else goto exit;
			}
exit:	t=(struct D *)NULL;
out:	return(t);
}

/* t�hestiku V moodustamine: veateade */
void viga(int i){
int j;
	fprintf(Logi,"error in  grammar: nr of symbol=%d GrammarLength=%d<BR>",
		i,Glen);
	for(j=0;j<i;j++) fprintf(Logi,"%c",GBuf[j]);
	fprintf(Logi,"%c",sk);
	while(i<Glen){
		fprintf(Logi,"%c",GBuf[i]);
		i++;
		}
	fprintf(Logi,"<BR>");
}	

/* produktsioonide otseadresseeriv j�rjestamine v�ljatr�kiks */
void sort_rules(struct D *t,struct D *SD[],struct R *SR[]){
struct R *r;
	if(t!=(struct D *)NULL){
		if(t->tunnus==0){
			r=t->def;
			while(r!=(struct R *)NULL){
				if(r->P<0||r->P>Pnr){
					fprintf(Logi,"\ar->P=%d<BR>",r->P);
					}
				SD[r->P]=t;
				SR[r->P]=r;			
				r=r->alt;
				}	
			}
		sort_rules(t->left,SD,SR);
		sort_rules(t->right,SD,SR);
		}
}

/* mitteterminali ja tema definitsiooni(de) tr�kk - conf.c */
int print_rule(struct D *t,struct R *r){
int i,j;
char *s;
	fprintf(Logi,"<FONT COLOR=\"#0000FF\">P%2d: `%s' -> ",r->P,T[t->code]);
	for(i=0;i<r->n;i++){
		j=r->d[i];
		s=T[j];
		if(r->d[i]<=tnr) fprintf(Logi,"%s ",s);
		else fprintf(Logi,"`%s' ",s);
		}
	fprintf(Logi,"</FONT><BR>");
	return(1);
}

/* produktsiooni tr�kk */
void Print_rule(struct D *t,struct R *r){
int i,j;
	if(r != (struct R *)NULL){
		fprintf(Logi,"<FONT COLOR=\"#008000\">P%2d: </FONT>",r->P);
		fprintf(Logi,"`%s'",T[t->code]);
		fprintf(Logi,"<FONT COLOR=\"#FF0000\"> -> </FONT>");		
		for(i=0;i<r->n;i++){
			j=r->d[i];
			if(r->d[i]<=tnr)fprintf(Logi,"<FONT COLOR=\"#0000FF\">%s ",T[j]);
			else fprintf(Logi,"`%s' ",T[j]);
			fprintf(Logi,"</FONT>");
			}
		fprintf(Logi,"<BR>");
		}
}

/* produktsiooni tr�kk */
void Print_rule_comm(struct D *t,struct R *r){
int i,j;
	if(r != (struct R *)NULL){
		fprintf(Logi,"P%2d: `%s' -> ",r->P,T[t->code]);
		for(i=0;i<r->n;i++){
			j=r->d[i];
			if(r->d[i]<=tnr)fprintf(Logi,"%s ",T[j]);
			else fprintf(Logi,"`%s' ",T[j]);
			}
		fprintf(Logi,"<BR>");
		}
}

/* produktsiooni tr�kk faili*/
void Print_rule_f(struct D *t,struct R *r){
int i,j;
	if(r != (struct R *)NULL){
		fprintf(Sem,"  P%2d: `%s' -> ",r->P,T[t->code]);
		for(i=0;i<r->n;i++){
			j=r->d[i];
			if(r->d[i]<=tnr)fprintf(Sem,"%s ",T[j]);
			else fprintf(Sem,"`%s' ",T[j]);
			}
		fprintf(Sem,"\n");
		}
}

/* produktsioonide hulga P tr�kk */
int print_rules(struct D *t){
	int i;
	for(i=1;i<=Pnr;i++){
		SD[i]=(struct D *)NULL;
		SR[i]=(struct R *)NULL;
		}
	sort_rules(t,SD,SR);
	for(i=1;i<=Pnr;i++){
		if(SR[i]!=NULL) Print_rule(SD[i],SR[i]);
		}
	return(1);
}		


/* produktsiooni 'vasaku poole' salvestamine */
struct D *leftside(int l){
	struct D *t;
	dl=0;
	DC=newD();
	DC->L=l;
	DL=DC;
	t=search(1);
	memset(def,'\0',20);
	if(t->code==0){
		nr++;
		if(nr>HTL){
			sprintf(rida,"too many symbols: nr=%d limes=%d<BR>",nr,HTL);
			ExiT(rida);
			}		
		t->code=nr;
		memcpy(T[nr],word,l+1);
		}
	return(t);
}

/* mitteterminal -> definitsioon */
void nonterm(int l){
	struct D *t;
	DC=newD();
	DC->L=l;
	t=search(1);
	if(t->code==0){
		nr++;
		if(nr>HTL){
			sprintf(rida,"too many symbols: nr=%d limes=%d<BR>",
				nr,HTL);
			ExiT(rida);
			}		
		t->code=nr;
		memcpy(T[nr],word,l+1);
		}
	def[dl]=t->code;
	dl++;
}

/* terminal t�hestikku V (flag=0) v�i definitsiooni (flag=1) */
void term(int l,int flag){
	struct D *t;
	DC=newD();
	DC->tunnus=1;
	DC->L=l;
	t=search(1);
	if(t->code==0){
		tnr++;
		t->code=tnr;
		word[19]=tnr;
		memcpy(T[tnr],word,20);
		}
	if(flag==1){	
		def[dl]=t->code;
		dl++;
		}
}

/* produktsiooni moodustamine ja salvestamine */
void makerul(void){
	struct R *r;
	r=newR();
	r->P=Pnr;
	Pnr++;
	r->n=dl;
	r->d=(char *)malloc(dl);
	if(r->d==NULL){ 
		sprintf(rida,"makerul: I don't have memory<BR>");
		ExiT(rida);
		}
	memcpy(r->d,def,dl);
	memset(def,'\0',20);
	r->alt=DL->def;
	DL->def=r;
	dl=0;	
}

/* terminaalse t�hestiku koostamine */
int Terms(void){
	int i,l,mid,left;  char k;
	int res=0;
	i=0;
	left=0;
	olek=0;
	mid=0;
nstate:	memset(word,'\0',20);
	l=0;
loop:	if(i>=Glen) goto out;
	if(GBuf[i]=='\t'){
		i++;
		goto loop;
		}
	switch(olek){
/* vasak */	case 0:{
			switch(GBuf[i]){
				case '-':{
					olek=1;
					mid=0;
					goto nstate;
					}
				case ' ':i++;
					 goto loop;
				case '`':{
					if(left==1){
						viga(i);
						res=1;
						}
					left=1;
					i++;
					goto loop;
					}
				case '\'':{
					mid=0;
					olek=1;   /* middle */
					i++;
					goto nstate;
					}
				default :{
					i++;
					goto loop;
					}
				}
			}   /* case0 */
/* middle */	case 1:	{
			switch(GBuf[i]){
				case ' ': i++;
					  goto loop;
				case '-': if(mid==0){
						mid=1;
						i++;
						}
					   else{
					   	viga(i);
						i++;
						res=1;
						}
					   goto loop;
				case '>':  if(mid==0){
						i++;
						viga(i);
						i++;
						res=1;
						goto loop;
						}
					   else{
					   	i++;
						olek=2;
						goto nstate;
						}
				}
			}   /* case1 */
/* right */	case 2: {
			switch(GBuf[i]){
				case ' ': i++;
					  goto loop;
				case '`': {
						  olek=3;
						  i++;
						  goto nstate;
						  }
				case '\n': left=0;
					   olek=0;
					   i++;
					   goto nstate;
				default: k=GBuf[i];  if(isgraph(k)){
						olek=4;
						goto nstate;
						}
					   else{
					   	viga(i);
						i++;
						res=1;
						}
					   i++;
					   goto loop;
				}
			}  /* case2 */
/* NT */	case 3: {
			k=GBuf[i]; if(isalnum(k)){
				i++;
				goto loop;
				}
			else{
				switch(GBuf[i]){
					case '`':
						viga(i);
						i++;
						res=1;
						goto loop;
					case '\'':
						i++;
						left=0;
						olek=2;
						goto nstate;
					case ' ': i++;
						  goto loop;
					default: viga(i);
						i++;
						res=1;
						goto loop;
					}
				}
			}   /* case3 */
/* T */		case 4:{
			if(GBuf[i]=='`'){
				term(l,0);
				olek=2;
				goto nstate;
				}
			k=GBuf[i]; if(isgraph(k)){
				word[l]=GBuf[i];
				i++;
				l++;
				goto loop;
				}
			if(GBuf[i]==' '){
				i++;
				term(l,0);
				olek=2;
				goto nstate;
				}
			if(GBuf[i]=='\n'){
				i++;
				term(l,0);
				olek=0;
				left=0;
				goto nstate;
				}
			}    /* case4 */
		}   /* switch olek */
out:	return(res);
}

/* mitteterminaalse t�hestiku ja produktsioonide hulga koostamine */
int Rules(void){
	int i,l,mid,left,res=0;
	char k;
	i=0;
	left=0;
	mid=0;

nstate:	memset(word,'\0',20);
	l=0;
loop:	if(i>=Glen) return(0);
	if(GBuf[i]=='\t'){
		i++;
		goto loop;
		}
	switch(olek){
/* vasak */	case 0:{
			switch(GBuf[i]){
				case '-':{
					olek=1;
					mid=0;
					goto nstate;
					}
				case ' ':i++;
					 goto loop;
				case '`':{
					if(left==1){
						viga(i);
						i++;
						res=1;
						}
					left=1;
					i++;
					goto loop;
					}
				case '\'':{
					mid=0;
					DL=leftside(l);
					olek=1;   /* middle */
					left=0;
					i++;
					goto nstate;
					}
				default :{
					k=GBuf[i]; if(isalnum(k)){
						word[l]=GBuf[i];
						l++;
						i++;
						}
					else{
						viga(i);
						i++;
						res=1;
						}
					goto loop;
					}
				}
			}   /* case0 */
/* middle */	case 1:	{
			switch(GBuf[i]){
				case ' ': i++;
					  goto loop;
				case '-': if(mid==0){
						mid=1;
						i++;
						}
					   else{
					   	viga(i);
						i++;
						res=1;
						}
					   goto loop;
				case '>':  if(mid==0){
						i++;
						viga(i);
						res=1;
						goto loop;
						}
					   else{
					   	i++;
						if(GBuf[i]=='\t') i++;
						olek=2;
						goto nstate;
						}
				}
			}   /* case1 */
/* right */	case 2: {
			switch(GBuf[i]){
				case ' ': i++;
					  goto loop;
				case '`': {
						  olek=3;
						  i++;
						  goto nstate;
						  }
				case '\n': makerul();
					   left=0;
					   olek=0;
					   i++;
					   goto nstate;
				default: k=GBuf[i];  if(isgraph(k)){
						olek=4;
						goto nstate;
						}
					   else{
					   	viga(i);
						i++;
						res=1;
						}
					   i++;
					   goto loop;
				}
			}  /* case2 */
/* NT */	case 3: {
			k=GBuf[i]; if(isalnum(k)){
				word[l]=GBuf[i];
				i++;
				l++;
				goto loop;
				}
			else{
				switch(GBuf[i]){
					case '`':
						viga(i);
						i++;
						res=1;
						goto loop;
					case '\'':
						nonterm(l);
						i++;
						left=0;
						olek=2;
						goto nstate;
					case ' ': i++;
						  goto loop;
					default: viga(i);
						i++;
						res=1;
						goto loop;
					}
				}
			}   /* case3 */
/* T */		case 4:{
			if(GBuf[i]=='`'){
				term(l,1);
				olek=2;
				goto nstate;
				}
			k=GBuf[i]; if(isgraph(k)){
				word[l]=GBuf[i];
				i++;
				l++;
				goto loop;
				}
			if(GBuf[i]==' '){
				i++;
				term(l,1);
				olek=2;
				goto nstate;
				}
			if(GBuf[i]=='\n'){
				i++;
				term(l,1);
				makerul();
				olek=0;
				left=0;
				goto nstate;
				}
			}    /* case4 */
		}   /* switch olek */
	return(res);
}

void print_def(struct R *r){
int i,j;
	for(i=0;i<r->n;i++){
		j=r->d[i];
		if(j<=tnr) fprintf(Logi,"%s ",T[j]);
		else fprintf(Logi,"`%s' ",T[j]);
		}
	fprintf(Logi,"<BR>");
}

/* semantikamassiivi t�itmine */
int put_semant(void){
	int piir;
	char finame[256];
	char c;
	int  i;
	int numbr;
	int kood;
	piir=tnr+Pnr;
	sort_rules(DC,SD,SR);
	semantika=DefVect(piir+1);
	if(semantika==NULL) return(0);
	memset(finame,'\0',256);
	for(i=0;i<256;i++){
		if((fname[i]!='.')&&(fname[i]!='\0')) finame[i]=fname[i];
		}
	strcat(finame,".sem");
	Sem = fopen(finame, "r");
	if (Sem==NULL){
		fclose(Sem);
		fprintf(Logi,"semantics file %s is lack<BR>",finame);
		fprintf(Logi,"I'll make it myself<BR>");
		Sem=fopen(finame, "w");
		if(Sem==NULL) abort();
		for(i=1;i<piir;i++){
			semantika[i]=i;
			if(i<=tnr) fprintf(Sem,"%d=%d \t$ %s\n",i,i,T[i]);
			else{
				fprintf(Sem,"P%d=%d \t$ ",i-tnr,i);
				Print_rule_f(SD[i-tnr],SR[i-tnr]);
				}
			}					
		fclose(Sem);
		goto showit;
		}
	olek = 0;
	while ( !feof(Sem)){
		c=fgetc(Sem);
		if(c=='$') olek=3;
		switch(olek){
		case 0:{
			if(!isalnum(c)) break;
			if(isdigit(c)){
				ungetc(c,Sem);
				fscanf(Sem,"%2d",&numbr);
				if(numbr>tnr){
					fprintf(Logi,"the terminal #.%d is lack<BR>",numbr);
					numbr=0;
					}
				olek=1;
				break;	
				}
			if((c=='P')||(c=='p')){
				fscanf(Sem,"%2d",&numbr);
				if(numbr>Pnr){
					fprintf(Logi,"the production #.%d is lack<BR>",numbr);
					numbr=0;
					}
				else numbr+=tnr;
				if(numbr>piir){
					fprintf(Logi,"too big index %d<BR>",numbr);
					numbr=piir-1;
					}
				olek=1;
				break;
				}
			break;
			}
		case 1: if(c=='=') olek=2;
			break;
		case 2: if(isdigit(c)){
				ungetc(c,Sem);
				fscanf(Sem,"%2d",&kood);
				semantika[numbr]=kood;
				olek=0;
				}
			break;
		case 3: if(c=='\n') olek=0;
			break;
		}
	}
	fclose(Sem);
showit:	
	for(i=1;i<=piir;i++){
		if(semantika[i]>0){
			if(i<=tnr) fprintf(Logi,"%s=%d<BR>",T[i],semantika[i]);
			else{
				fprintf(Logi,"P%d=%d<SPACE> <SPACE> ",i-tnr,semantika[i]);
				fprintf(Logi,"<FONT COLOR=\"#008000\"> $");  
				Print_rule_comm(SD[i-tnr],SR[i-tnr]);
				fprintf(Logi,"</FONT>");
				}
			}  
		}
	return(1);
}

int constr(void){
	int pre,i;
	char *Ti;
/* konstruktori initsialiseerinine */
	int ret=1;
	olek=0;
	Pnr=1;
	Index=1;      /* eelnevusteisenduste uute produktsioonide suffiks */
	DT=(struct D *)NULL;     /* first   */
	DC=(struct D *)NULL;     /* current */
	DL=(struct D *)NULL;     /* last    */
	DN=(struct D *)NULL;     /* new     */
	context=0;               /* independent & */
	dc=0;                    /* dependent context */
	tnr=0;  /* terminaalse t�hestiku jooksev pikkus */
	nr=0;   /* t�hestiku V jooksev pikkus */
	NR=0;   /* nr eelnevusteisenduste ajal */
	BRC=0;  /* �hesuguste paremate pooltega produktsioonide arv */
	rules=NULL;
	for(i=0;i<(2*HTL);i++){
		Ti=T[i];
		memset(Ti,'\0',20);
		}
/* terminaalse t�hestiku moodustamine */
	if(Terms()==1){
		ret=0;
		goto bye;
		}
	nr=tnr;
	fprintf(Logi,"<H4><FONT COLOR=\"#0000FF\">Terminal alphabet</H4></FONT>");
	pT(0);
	fprintf(Logi,"<HR>");
/* mitteterminaalse t�hestiku ja produktsioonide hulga moodustamine */
	if(Rules()==1){
		ret=0;
		goto bye;
		}
	fprintf(Logi,"<H4><FONT COLOR=\"#0000FF\">Nonterminal alphabet</H4></FONT>");
	pT(1);
	fprintf(Logi,"<HR>");
	fprintf(Logi,"<H4><FONT COLOR=\"#0000FF\">Productions</H4></FONT>");
	print_rules(DT);
	fprintf(Logi,"<HR>");	
/* left- ja rightmost-hulkade moodustamine, eelnevusmaatriksi koostamine */
new: 
	memset(Pm,'\0',HTL*HTL);
	memset(Lm,'\0',HTL*HTL);
	memset(Rm,'\0',HTL*HTL);
	make_LRB();
	fprintf(Logi,"<H4><FONT COLOR=\"#0000FF\">Leftmost-set</H4></FONT>");
	print_LRM(Lm);  
	fprintf(Logi,"<HR>");	
	fprintf(Logi,"<H4><FONT COLOR=\"#0000FF\">Rightmost-set</H4></FONT>");
	print_LRM(Rm); 
	fprintf(Logi,"<HR>");	
	pre=make_PM();
	fprintf(Logi,"<H4><FONT COLOR=\"#0000FF\">Precedence matrix</H4></FONT>");
	print_PM(); 
/*	fprintf(Logi,"<HR>");	
	print_rela();  */
	fprintf(Logi,"<HR>");	
	fflush(Logi);	
/*	if(Nimi[0]=='G') print_PM(); 
	else print_rela(); */
	if(pre==1) goto on;
/* eelnevustest ja eelnevusteisendused */
	fprintf(Logi,"<H4><FONT COLOR=\"#0000FF\">Precedence varies</H4></FONT>");
	if(conflicts()>0){
		fprintf(Logi,"<H4><FONT COLOR=\"#0000FF\">New grammar</H4></FONT>");
		print_rules(DT);
		fprintf(Logi,"<HR>");		
		goto new;
		}
on:	
	fprintf(Logi,"<H4><FONT COLOR=\"#008000\">");
	fprintf(Logi,"<H3>Grammar %s is a precedence grammar</H3></FONT>",fname);
/* produktsioonide 'paremate poolte' paisktabeli koostamine, p��ratavustest */
	HashRules(DT);
	if(BRC==0){
		context=0;
		fprintf(Logi,"<H4><FONT COLOR=\"#008000\">");
		fprintf(Logi,"<H4>Grammar %s is invertible</H4></FONT>",fname);
		goto semm;
		}
	fprintf(Logi,"<H4><FONT COLOR=\"#FF0000\">");
	fprintf(Logi,"<H4>Grammar %s is not invertible</H4></FONT>",fname);
	context=1;
/* s�ltumatu konteksti hulkade moodustamine, BRC(1|1)-test */
	fprintf(Logi,"<HR>");
	if(LC!=(char *)NULL) free(LC);
	LC=DefArray(nr+1);
	if(RC!=(char *)NULL) free(RC);
	RC=DefArray(nr+1);	
	make_all_indep();
	dc=0;
	if(make_BRC()==0) goto sos;
	if(BRC==0&&dep==0){
		fprintf(Logi,"<H4><FONT COLOR=\"#008000\">");	
		fprintf(Logi,"<H4>Grammar %s is BRC(1|1)-reducible</H4></FONT>",fname);
		goto semm;
		}
	if(dc==1){
		fprintf(Logi,"<H4><FONT COLOR=\"#008000\">");	
		fprintf(Logi,"<H4>Grammar %s is BRC(1,1)-reducible</H4></FONT>",fname);
		goto semm;
		}
sos:
	fprintf(Logi,"<H4><FONT COLOR=\"#FF0000\">");
	fprintf(Logi,"Grammar %s is not BRC-reducible</H4></FONT>",fname);
	p_nlist();
/*	print_all_cxt();  */
	ret=0;
	goto bye;
/* semantika omistamine */
semm:
	fprintf(Logi,"<HR>");
	fprintf(Logi,"<H4><FONT COLOR=\"#0000FF\">");
	fprintf(Logi,"<H4>Semantics</H4></FONT>");
	if(semantika!=(char *)NULL){
		free(semantika);
		semantika=(char *)NULL;
		}
	put_semant(); 
	Sn=nr;
	fprintf(Logi,"<HR>");	
	ret=w_tabs();
	fprintf(Logi,"<HR>");	
bye:
	return(ret);
}

int construc(void){
	int ret=0;
	time_t t0,t1;
	GBuf=NULL;
	Logi=fopen(L_name,"w");
	if(Logi==NULL){
		printf("Cannot open log-book<BR>");
		return(0);
		}
	fprintf(Logi,"<HTML><HEAD><TITLE>");
	time(&t0);
	fprintf(Logi,"CONSTRUCTOR %s",fname);
	fprintf(Logi,
	"</TITLE></HEAD><BODY><H4><FONT COLOR=\"#0000FF\">Start of CONSTRUCTOR for the Grammar %s %s</H4>",
		fname,asctime(localtime(&t0)));
	fprintf(Logi,"</FONT><B>");	
	if(gramm()==0) goto jokk;
	ret=constr();
jokk:
	time(&t1);
	fprintf(Logi,"<FONT COLOR=\"#0000FF\">");	
	fprintf(Logi,"<H4>Finish of CONSTRUCTOR %s</H4>",asctime(localtime(&t1)));	
	fprintf(Logi,"</FONT></BODY></HTML>");
	fflush(Logi);
	fclose(Logi);
	return(ret);
}

int main(int argc,char **argv){
	if(argc!=2){
		printf("I do need only the name of a grammar<BR>"); abort();
		}
	fname=(char *)malloc(256);
	Nimi=(char *)malloc(9);
	L_name=(char *)malloc(256);
	memset(fname,'\0',256);
	memset(Nimi,'\0',9);
	memset(L_name,'\0',256);	
	sprintf(fname,"%s",argv[1]);
	sprintf(L_name,"%s",argv[1]);	
	strcpy(Nimi,fname);
	strcat(fname,".grm");
	strcat(L_name,".htm");	
	printf("fname=%s Nimi=%s L_name=%s\n",fname,Nimi,L_name);
	construc();
	return(1);
}		