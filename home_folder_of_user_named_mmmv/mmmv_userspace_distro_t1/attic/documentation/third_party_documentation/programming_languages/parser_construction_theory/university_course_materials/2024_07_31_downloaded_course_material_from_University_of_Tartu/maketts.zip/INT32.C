/* int32.c  May 2001 */
#include <io.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include "two32.h"

/*        S E M A N T I C S                          */

#define muut 1      /* #i# - identifikaator */
#define konst 2     /* #c# - konstant */
#define pisem 3     /* < */
#define suurem 4    /* > */
#define piv 5       /* <= */
#define suv 6       /* >= */
#define pov 7       /* /= */
#define vord 8      /* = */
#define omist 10    /* omistamisoperaator */
#define jag 11      /* jagamistehe */
#define korrut 12   /* korrutamistehe */
#define lahut 13    /* lahutustehe */
#define liit 14     /* liitmistehe */
#define labl 15     /* m�rgend */
#define suunam 16   /* suunamisoperaator */
#define kuisiis 18  /* if-lause */
#define tingop 19   /* tingimusoperaator */
#define lugem 20    /* lugemisoperaator */
#define kirjut 21   /* kirjutamisoperaator */

/* interpretaatori magasinielement */
struct item{
	int liik;         /* 0 t��muutuja, 1 id, 2 c, 3 top */
	int index;       /* t��muutuja v��rtus  */
	struct itr *id;   /* liik = 1 (muutuja)  */
	struct ctr *c;    /* liik = 2 (konstant) */
	struct top *t;    /* liik = 3 (m�rgend)  */
	};

  struct item *stack[20];   /* interpretaatori magasin */

void blue(char *t){
	fprintf(Logi,"<FONT COLOR=\"0000FF\">%s</FONT>",t);
}       

void green(char *t){
	fprintf(Logi,"<FONT COLOR=\"008000\">%s</FONT>",t);
}       

void red(char *t){
	fprintf(Logi,"<FONT COLOR=\"FF0000\">%s</FONT>",t);
}       

void pset(int x,int y){
	blue("{");
	fprintf(Logi,"%s",T[x]);
	blue(",");
	fprintf(Logi,"%s",T[y]);
	blue("}");
}

void print_top(struct top *t){
fprintf(Logi,
"top %p: kood=%d leks=%d sem=%d label=%d truel=%d falsel=%d up=%p right=%p down=%p",
   t,t->kood,t->leks,t->sem,t->label,t->truel,t->falsel,t->up,t->right,
   t->down);
fprintf(Logi,"  (%s)<BR>",(t->leks==0) ? T[t->kood] : T[t->leks]);
if(t->right!=(struct top *)NULL) print_top(t->right);
if(t->down!=(struct top *)NULL) print_top(t->down);
}

void print_Itr(struct itr *t){
fprintf(Logi," itr %p: nr=%d loc=%d value=%d top=%p io=%d",
   t,t->nr,t->loc,t->value,t->t,t->io);
fprintf(Logi,"   (%s)<BR>",T[t->nr]);
}

void print_Ctr(struct ctr *t){
fprintf(Logi," ctr %p: nr=%d loc=%d value=%d",
   t,t->nr,t->loc,t->value);
fprintf(Logi,"   (%s)<BR>",T[t->nr]);
}

void print_one_top(struct top *t){
fprintf(Logi," top %p: kood=%d leks=%d sem=%d label=%d truel=%d falsel=%d up=%p right=%p down=%p",
   t,t->kood,t->leks,t->sem,t->label,t->truel,t->falsel,t->up,t->right,
   t->down);
fprintf(Logi,"  (%s)<BR>",(t->leks==0) ? T[t->kood] : T[t->leks]);
}

/* anal��sipuu tipu tr�kk */
void p_top(char *t,struct top *p){
if(logi==1){
	fprintf(Logi,"%s top:<BR>",t);
	print_one_top(p);
	}  
}

void set_show(char *title){
	fprintf(Logi,"<H4><FONT COLOR=\"#0000FF\">%s",title);
	fprintf(Logi,"</FONT></H4>");
}

void ps(void){
	fprintf(Logi,"<BR>");
}

void ExIT(void){
	if(logi==1){
		fprintf(Logi,"Abnormal end<BR><BR>");
		fflush(Logi);
		fclose(Logi);
		}               
	abort();
}

FILE *opr(void){
	of=fopen(rida,"rb");
	if (of==NULL){
		fprintf(Logi,"cannot open %s",rida);
		return(of);
		}
	return(of);
}

struct top *r_ptree(void){
	struct top *p;
	p=(struct top *)malloc(sizeof(struct top));
	if(p==(struct top *)NULL){
		fprintf(Logi,"I haven't memory enough..");
		ExIT();
		}
	fread(p,sizeof(struct top),1,of);
	if(p->right!=(struct top *)NULL) p->right=r_ptree();
	if(p->down!=(struct top *)NULL) p->down=r_ptree();
	return(p);
}

void set_up(struct top *root){
	struct top *p;
	p=root;
	if(p->down!=(struct top *)NULL){
		p=p->down;
		while(p->right!=(struct top *)NULL){
			p=p->right;
			}
		p->up=root;	
		}
	if(root->down!=(struct top *)NULL) set_up(root->down);
	if(root->right!=(struct top *)NULL) set_up(root->right);
}  

int r_tree(void){
	sprintf(rida,"%s.pt",Pr_name);
	if(opr()!=NULL){
		p_=r_ptree();
		set_up(p_);
		return(1);
		}
	return(0);
}		

int r_t(void){
	sprintf(rida,"%s.t",Pr_name);
	if(opr()!=NULL){
		fread(&T,20,nr+1,of);
		fclose(of);
		return(1);
		}
	else return(0);
}

int r_parm(void){
	PARM=(struct parm *)malloc(sizeof(struct parm));
	if(PARM==(struct parm *)NULL) ExIT();
	memset(PARM,'\0',sizeof(struct parm));
	sprintf(rida,"%s.prm",Pr_name);
	if(opr()!=NULL){
		fread(PARM,sizeof(struct parm),1,of);
		fclose(of);
		nr=PARM->nr;
		itl=PARM->itl;
		ktl=PARM->ktl;
		return(1);
		}
	return(0);
}

int r_it(void){
	sprintf(rida,"%s.it",Pr_name);
	if(opr()!=NULL){
		fread(&IT,itl*sizeof(int),1,of);
		fclose(of);
		return(1);
		}
	return(0);
}

int r_kt(void){
	sprintf(rida,"%s.kt",Pr_name);
	if(opr()!=NULL){
		fread(&KT,ktl*sizeof(int),1,of);
		fclose(of);
		return(1);
		}
	return(0);
}

int r_tabs(void){
	int flag;
	flag=1;
	flag=r_parm(); 
	if(flag==0) goto out;
	flag=r_t();    
	if(flag==0) goto out;
	flag=r_it();   
	if(flag==0) goto out;
	flag=r_kt();    
	if(flag==0) goto out;
	flag=r_tree();  
	fflush(Logi);
out:    if(flag==0){
		fprintf(Logi,"cannot read all the tables..");
		fflush(Logi);
		}
	return(flag);
}

/* analyysipuu trykk */
int pp2html(struct top *p){
	double pr;
	int n=1;
	struct top *t;
	char s[20];
	t=p;
naaber:
	if(t->right!=NULL){
		n++;
		t=t->right;
		goto naaber;
		}
	pr=100.0/n;
	sprintf(s,"\"%2.0f&#037\"",pr); 
	fprintf(Logi,"<table border=1><tr>");   
next:
	fprintf(Logi,
	"<td width=%s valign=\"top\"><STRONG>",s);      
	if((p->kood==m_k)||(p->kood==k_k)) fprintf(Logi,"%s",T[p->leks]);
	else tprop(p->sem);
	if(p->down!=NULL) pp2html(p->down);
	fprintf(Logi,"</td>");  
	if(p->right!=NULL){                     
		p=p->right;
		goto next;
		}
	fprintf(Logi,"</tr></table>");
	return 1;
}  

/* m�lueraldus konstantide tabeli kirjele */
struct ctr *make_ctr(void){
	struct ctr *c;
	c=(struct ctr *)malloc(sizeof(struct ctr));
	if(c==(struct ctr *)NULL) ExIT();
	memset(c,'\0',sizeof(struct ctr));
	return(c);
}       
	
/* konstantide tabeli moodustamine */
int make_CT(void){
	int t;
	struct ctr *c;
	int i;
	if(ktl==0) return(0);
	fprintf(Logi,"<TABLE BORDER=1><TR>"); fflush(Logi);
	for(i=0;i<ktl;i++){
		t=KT[i];
		c=make_ctr();
		c->nr=t;
		c->value=atoi(T[c->nr]);
		c->loc=i;
		CT[i]=c;
		fprintf(Logi,"<TD>c%d=%d</TD>",i+1,c->value); fflush(Logi);
		}
	fprintf(Logi,"</TR></TABLE>"); fflush(Logi);
	return(ktl);
}

/* m�lueraldus identifikaatorite tabeli kirjele */
struct itr *make_itr(void){
	struct itr *c;
	c=(struct itr *)malloc(sizeof(struct itr));
	if(c==(struct itr *)NULL) ExIT();
	memset(c,'\0',sizeof(struct itr));
	c->t=(struct top *)NULL;
	return(c);
}       

/* identifikaatorite tabeli moodustamine */
int make_IDT(void){
	int t;
	struct itr *c;
	int i;
	if(itl==0) return(0);   
	fprintf(Logi,"<TABLE BORDER=1><TR>"); fflush(Logi);
	for(i=0;i<itl;i++){
		t=IT[i];
		c=make_itr();
		c->nr=t;
		c->loc=i;
		IDT[i]=c;
		fprintf(Logi,"<TD>i%d=%s</TD>",i+1,T[c->nr]); fflush(Logi);
		}
	fprintf(Logi,"</TR></TABLE>");          
	return(itl);
}

/* identifikaatorite tabeli kirje tr�kk */
void p_itr(struct itr *id){
	fprintf(Logi,"ITR nr=%d V=%s loc=%d value=%d t=%p<BR>",
		id->nr,T[id->nr],id->loc,id->value,id->t);
}

/* muutujate v�ljatr�kk */
void print_variables(void){
	struct itr *id;
	int i;
	set_show("THE VARIABLES:");
	for(i=0;i<itl;i++){
		id=IDT[i];
		if(id->t==(struct top *)NULL)
		fprintf(Logi,"%s=%d<BR>",T[id->nr],id->value);
		}
}

/* konstantide tabeli kirje tr�kk */
void p_ctr(struct ctr *id){
	fprintf(Logi,"CTR nr=%d V=%s loc=%d value=%d<BR>",
		id->nr,T[id->nr],id->loc,id->value);
}		
		
/* m�rgendi tr�kk */
void p_label(struct top *p){
	if(p->label>0) fprintf(Logi,"%s: ",T[p->label]);
}

/* m�rgendatud operaatorite otsimine */
int det_label(struct top *P){
	struct top *t,*op,*lab;
	struct itr *id;
	int k,flag=0;
	t=P;
ring:	
	if(t==(struct top *)NULL) goto out;
	if(t->sem==labl){
		op=t->right;
		lab=t->down;
		for(k=0;k<itl;k++){
			if(IT[k]==lab->leks){
				id=IDT[k];
				goto iok;
				}
			}	
		iok:		
		if(id->t!=(struct top *)NULL){
			fprintf(Logi,"label '%s' repeats<BR>",T[lab->leks]);
			flag++;
			goto next;
			}
		id->t=op;
		fprintf(Logi,"label '%s' is address of the operator {%s} (%p)<BR>",
		        T[lab->leks],T[op->kood],op);
		t=op;
		goto ring;
		}
next: t=t->right;
	goto ring;		
out:	return(flag);
}

/* suunamiste otsimine */
int det_goto(struct top *t,int flag){
	struct top *down;
	struct itr *id;
	int k;
	if(t!=(struct top *)NULL){
		if(t->sem==suunam){
			down=t->down;
			down=down->down;
			for(k=0;k<itl;k++){
				if(IT[k]==down->leks){
					id=IDT[k];
					goto dok;
					}
				}	
dok:			if(id->t==(struct top *)NULL){
				if(logi==1)
				fprintf(Logi,"label '%s' is lack<BR>",T[id->nr]);
				flag++;
				}
			}
		flag+=det_goto(t->down,flag);
		flag+=det_goto(t->right,flag);
		}
	return(flag);	
}	

/* m�rgendatud operaatorite otsimine, m�rgendi-alampuu eemaldamine */
void set_label(struct top *P){
	struct top *t,*op,*lab,*prev;
	struct itr *id;
	int k;
	t=prev=P;
ring:	if(t!=(struct top *)NULL){
		if(t->sem==labl){
			op=t->right;
			lab=t->down;
			for(k=0;k<itl;k++){
				if(IT[k]==lab->leks){
					id=IDT[k];
					goto iok;
					}
				}	
			iok: id->t=op;
			prev->right=op;
			op->label=lab->leks;
			free(t);
			free(lab);
			t=op;
			goto ring;
			}
		prev=t;
		t=t->right;
		goto ring;
	}			
}

void ctree(void){
	int f;
	if(ktl>0){
		set_show("Table of constants"); fflush(Logi);
		make_CT();
		}
	if(itl>0){
		set_show("Table of identifiers"); fflush(Logi);
		make_IDT();
		fprintf(Logi,"<BR>");
		f=0;
		f=det_label(p_->down);
		det_goto(p_->down,f);
		if(f==0){
			set_label(p_->down);
			set_show("Modified tree");
			pp2html(p_);
			}
		else{
			flag=1;
			p_=(struct top *)NULL;
			}		
		}       
}               
		
/* magasini elemendi m�lueraldus */
struct item *make_item(void){
	struct item *c;
	c=(struct item *)malloc(sizeof(struct item));
	if(c==NULL) ExIT();
	memset(c,'\0',sizeof(struct item));
	return(c);
}	

/* magasini m�lu vabastamine */
void freestack(int i,int k){
	struct item *c;
	while(k>0){
		c=stack[i-k];
		free(c);
		stack[i-k]=(struct item *)NULL;
		k--;
		}
}

/* magasini tr�kk */
void prist(int i,int ic){
	struct item *s;
	struct ctr *c;
	struct itr *id;
	int k;
	fprintf(Logi,"<BR><TABLE BORDER=1><B><TR>");
	fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\"><STRONG>Stack<FONT></TD>");
	for(k=0;k<i;k++){
		s=stack[k];
		switch(s->liik){
			case 0: fprintf(Logi,"<TD>tm=%d</TD>",s->index); break;
			case 1: id=s->id;
				if(ic==0){
				    fprintf(Logi,"<TD>id %s=%d</TD>",T[id->nr],id->value);
				    }
				 else{
				    fprintf(Logi,"<TD>id %s</TD>",T[id->nr]);
				    }
				break;
			case 2: c=s->c;
				fprintf(Logi,"<TD>const=%d</TD>",c->value);
				break;
			case 3: id=s->id;
				fprintf(Logi,"<TD>%s:</TD>",T[id->nr]);
				break;
			}
		}
	fprintf(Logi,"</TR></TABLE>");
}				
	
/* anna muutuja, konstandi v�i t��muutuja v��rtus  */
int get_x(int i,int k){
	struct item *s;
	struct ctr *c;
	struct itr *id;
	int x=0;
	s=stack[i-k];
	switch(s->liik){
		case 0:{
			x=s->index; 
			break;
			}
		case 1:{
			id=s->id;
			x=id->value;
			break;
			}
		case 2:{
			c=s->c;
			x=c->value; 
			break;
			}
		}
	return(x);
}

/* salvesta muutuja v��rtus */
void write_x(int x,int i){
	struct item *s;
	struct itr *id;
	s=stack[i-2];
	id=s->id;
	id->value=x;
	fprintf(Logi,"<BR>%s:=%d<BR>",T[id->nr],id->value);
}

/* aritmeetiliste tehete t�itja */
void aritm(int i,int r){
struct item *s;
int x,y,res=0;
x=get_x(i,2);
y=get_x(i,1);
s=make_item();
s->liik=0;
fprintf(Logi,"<BR>");
switch(r){
	case jag:    res=x/y; fprintf(Logi,"%d = %d / %d",res,x,y); break;
	case korrut: res=x*y; fprintf(Logi,"%d = %d * %d",res,x,y); break;
	case lahut:  res=x-y; fprintf(Logi,"%d = %d - %d",res,x,y); break;
	case liit:   res=x+y; fprintf(Logi,"%d = %d + %d",res,x,y); break;
	}
fprintf(Logi,"<BR>");
s->index=res;
freestack(i,2);
stack[i-2]=s;
}

/* v�rdlustehete t�itja */
void loogik(int i,int r){
struct item *s;
int x,y;
int res=0;       /* false */
x=get_x(i,2);
y=get_x(i,1);
s=make_item();
s->liik=0;
fprintf(Logi,"<BR>");
switch(r){
	case pisem:  if(x<y)  res=1; fprintf(Logi,"%d < %d ?",x,y); break;
	case suurem: if(x>y)  res=1; fprintf(Logi,"%d > %d ?",x,y); break;
	case piv:    if(x<=y) res=1; fprintf(Logi,"%d <= %d ?",x,y); break;
	case suv:    if(x>=y) res=1; fprintf(Logi,"%d >= %d ?",x,y); break;
	case pov:    if(x!=y) res=1; fprintf(Logi,"%d /= %d ?",x,y); break;
	case vord:   if(x==y) res=1; fprintf(Logi,"%d = %d ?",x,y); break;
	}
fprintf(Logi,"<BR>");	
s->index=res;
freestack(i,2);
stack[i-2]=s;
}

void tprop(int s){
	switch(s){
		case 0:       fprintf(Logi,"root"); break;
		case pisem:   fprintf(Logi,"<"); break;
		case suurem:  fprintf(Logi,">"); break;
		case piv:     fprintf(Logi,"<="); break;
		case suv:     fprintf(Logi,">="); break;
		case pov:     fprintf(Logi,"/="); break;		
		case vord:    fprintf(Logi,"="); break;
		case omist:   fprintf(Logi,":="); break;
		case jag:     fprintf(Logi,"/"); break;
		case korrut:  fprintf(Logi,"*"); break;
		case lahut:   fprintf(Logi,"-"); break;
		case liit:    fprintf(Logi,"+"); break;
		case suunam:  fprintf(Logi,"GOTO "); break;
		case kuisiis: fprintf(Logi,"IF "); break;
		case tingop:  fprintf(Logi," "); break;
		case lugem:   fprintf(Logi,"READ "); break;
		case kirjut:  fprintf(Logi,"WRITE "); break;
		case labl:    fprintf(Logi,"label"); break;
		default:      fprintf(Logi,"%d",s); break;
		}
}

int print_Op(struct top *t){
	int fg=0;
	if(t!=(struct top *)NULL){
		if(t->sem==labl){
			t=t->down;
			fprintf(Logi,"%s: ",T[t->leks]); 
			return(0);
			}
		if(t->sem==lugem||t->sem==kirjut){
			tprop(t->sem);
			t=t->down;
			fprintf(Logi,"%s",T[t->leks]);
			return(0);
			}
		if(t->sem==suunam){
			tprop(t->sem);
			t=t->down;
			t=t->down;
			fprintf(Logi," %s",T[t->leks]);
			return(0);
			}	
		if(t->sem==kuisiis){
			fprintf(Logi,"IF ");
			print_Op(t->down);
			fprintf(Logi," THEN ");
			return(0);
			}
		if(t->down!=(struct top *)NULL&&t->sem!=omist){
			fprintf(Logi,"(");
			fg=1;
			}
		print_Op(t->down);
		if(t->leks!=0) fprintf(Logi,"%s",T[t->leks]);
		else tprop(t->sem);
		t=t->down;
		if(t!=(struct top *)NULL){
			print_Op(t->right);
			if(fg==1) fprintf(Logi,")");
			}
		}
	return(0);
}

/* TRIGOL-keelsete programmide tr�kk puu j�rgi  */
void p_prog(struct top *root){
	struct top *t;
	t=root->down;
	fprintf(Logi,"</FONT># ");
naaber:	print_Op(t);
	if(t->sem!=kuisiis&&t->sem!=labl&&t->up!=root) ps();
	t=t->right;
	if(t==(struct top *)NULL) goto ok;
	goto naaber;			
ok:	fprintf(Logi,"#<BR>");
}

/* TRIGOL-keelsete programmide interpretaator  */
void trigol_Int(struct top *root){
	struct item *s;
	struct top *t;
	struct ctr *c;
	struct itr *id;
	int op;	
	int i=0;
	int j,k,x;
	t=root->down;
	for(j=0;j<20;j++) stack[j]=(struct item *)NULL;
	fprintf(Logi,"<HR>");
down:	p_label(t);
	if(t->down!=(struct top *)NULL){
		t=t->down;
/*		p_top("down",t); fflush(Logi);  */
		goto down;
		}
/* leht => stack  */
/*	p_top("leaf",t); fflush(Logi);  */
	s=make_item();
	op=t->sem;
	switch(op){
		case muut:{
			s->liik=1;                        /* muutuja */
			for(k=0;k<itl;k++){
				if(IT[k]==t->leks){
					id=IDT[k];
					goto iok;
					}
				}	
			iok: s->id=id;
			if(id->t!=(struct top *)NULL){
				s->liik=3;                /* m�rgend */
				s->t=id->t;
				}
			break;
			}
		case konst:{
			for(k=0;k<ktl;k++){
				if(KT[k]==t->leks){
					c=CT[k];
					goto cok;
					}
				}			
			cok: s->c=c;
			s->liik=2;                        /* konstant */
			break;
			}
		default:{
			fprintf(Logi,"parsing tree is incorrect<BR>");
			goto jokk;
			}
		}	 
	stack[i]=s;
	i++;
	prist(i,0);	
naaber:	if(t->up==(struct top *)NULL){
		t=t->right;
/*		p_top("neighbour",t); */
		goto down;
		}
	t=t->up;
/*	p_top("up",t);  */
	if(t==root) goto ok;
	fprintf(Logi,"</FONT>interpreting the operator  ");
	print_Op(t);
	pp2html(t);
	op=t->sem;
	switch(op){
		case  pisem:{              /* < */
			loogik(i,op);
			i-=1;
			break;
			}
		case  suurem:{              /* > */
			loogik(i,op);
			i-=1;
			break;
			}
		case  piv:{              /* <= */
			loogik(i,op);
			i-=1;
			break;
			}
		case  suv:{              /* >= */
			loogik(i,op);
			i-=1;
			break;
			}
		case  pov:{              /* /= */
			loogik(i,op);
			i-=1;
			break;
			}
		case  vord:{              /* = */
			loogik(i,op);
			i-=1;
			break;
			}
		case omist:{             /* omistamine */
			x=get_x(i,1);
			write_x(x,i);
			freestack(i,2);
			i-=2;
			break;
			}
		case jag:{              /* jagamine */
			aritm(i,op);
			i-=1;
			break;
			}		
		case korrut:{              /* korrutamine */   
			aritm(i,op);
			i-=1;
			break;
			}			
		case lahut:{              /* lahutamine */   
			aritm(i,op);
			i-=1;
			break;
			}			
		case liit:{              /* liitmine */   
			aritm(i,op);
			i-=1;
			break;
			}
		case suunam:{               /* suunamine */
			s=stack[i-1];
			t=s->t;
			id=s->id;
			if(logi==1) fprintf(Logi,"goto %s<BR>",T[id->nr]);
			freestack(i,1);
			i-=1;
			goto down;
			}
		case kuisiis:{
			x=get_x(i,1);
			freestack(i,1);
			i-=1;
			if(x==0){
				t=t->right;
				goto naaber;
				}			
/*			p_top("if right",t); */
			break;
			}
		case tingop: break;
		case lugem:{
			s=stack[i-1];
			id=s->id;
			printf("\aInput %s= ",T[id->nr]);
			scanf("%d",&x);
			if(logi==1) fprintf(Logi,"Input %s=%d<BR>",T[id->nr],x);
			id->value=x;
			freestack(i,1);
			i-=1;
			break;
			}
		case kirjut:{
			s=stack[i-1];
			id=s->id;
			fprintf(Logi,"Output %s=%d<BR>",T[id->nr],id->value);
			freestack(i,1);
			i-=1;
			break;
			}
		}
	prist(i,0);
	goto naaber;
ok:	fprintf(Logi,"program %s is completed<BR>",pr_name);
jokk:	
	print_variables();
}

struct top *analyzer(void){
	if(r_tabs()==0) return(0);
	set_show("Program");
	p_prog(p_);
	set_show("Parsing tree");
	pp2html(p_);    
	ctree();
	return(p_);
}

int itr(void){
	int ret=0;
	time_t t0;
	GBuf=NULL;
	Logi=fopen(L_name,"w");
	if(Logi==NULL){
		printf("Cannot open log-book<BR>");
		return(0);
		}
	m_k=4; k_k=11;
	logi=1;
	time(&t0);
	fprintf(Logi,"<HTML><HEAD><TITLE>Interpreter</TITLE></HEAD><BODY><B>");
	fprintf(Logi,
	"<FONT COLOR=\"#0000FF\"><H3>Start of Interpreter for program %s",
		pr_name);
	fprintf(Logi," at %s<BR>",asctime(localtime(&t0)));		
	fflush(Logi);
	if(analyzer()!=NULL) trigol_Int(p_);
	time(&t0);
	fprintf(Logi,"<FONT COLOR=\"#0000FF\"><H4>Interpreter ended at </FONT> ");
	fprintf(Logi,"%s</H4>",asctime(localtime(&t0))); 
	fprintf(Logi,"</BODY></HTML>");
	return(1);
}

int main(int argc,char **argv){
	if(argc!=2){
		printf("I do need only the name of a tri-program\n"); abort();
		}
	pr_name=(char *)malloc(256);	
	Pr_name=(char *)malloc(256);		
	L_name=(char *)malloc(256);
	Nimi=(char *)malloc(256);	
	memset(pr_name,'\0',256);
	memset(Pr_name,'\0',256);		
	memset(L_name,'\0',256);	
	memset(Nimi,'\0',256);		
	strcpy(Nimi,".tri");
	sprintf(pr_name,"%s",argv[1]);	
	strcpy(L_name,pr_name);
	strcpy(Pr_name,pr_name);	
/*	p=strrchr(L_name,'.');
	p[1]='\0';	*/
	strcat(L_name,"i.htm"); 
	strcat(pr_name,".tri"); 	
	printf("pr_name=%s L_name=%s\n",pr_name,L_name);
/*	getchar();  */
	itr();
	return(1);
}		

