/* c_tri.c: Trigol Compiler for gcc. November 2000 */
#include <io.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include "two32.h"

/*        S E M A N T I C S                          */

#define muut 1      /* #i# - identifikaator */
#define konst 2     /* #c# - konstant */
#define pisem 3     /* < */
#define suurem 4    /* > */
#define piv 5       /* <= */
#define suv 6       /* >= */
#define pov 7       /* /= */
#define vord 8      /* = */
#define omist 10    /* omistamisoperaator */
#define jag 11      /* jagamistehe */
#define korrut 12   /* korrutamistehe */
#define lahut 13    /* lahutustehe */
#define liit 14     /* liitmistehe */
#define labl 15     /* m�rgend */
#define suunam 16   /* suunamisoperaator */
#define kuisiis 18  /* if-lause */
#define tingop 19   /* tingimusoperaator */
#define lugem 20    /* lugemisoperaator */
#define kirjut 21   /* kirjutamisoperaator */

/* interpretaatori magasinielement */
struct item{
	int liik;         /* 0 t��muutuja, 1 id, 2 c, 3 top */
	int index;       /* t��muutuja v��rtus  */
	struct itr *id;   /* liik = 1 (muutuja)  */
	struct ctr *c;    /* liik = 2 (konstant) */
	struct top *t;    /* liik = 3 (m�rgend)  */
	};

  struct item *stack[20];   /* kompilaatori magasin */
  int IX;	
  int tmarv;
  int Label;
  int opt;
  int nado=0;	

void blue(char *t){
	fprintf(Logi,"<FONT COLOR=\"0000FF\">%s</FONT>",t);
}	

void green(char *t){
	fprintf(Logi,"<FONT COLOR=\"008000\">%s</FONT>",t);
}	

void red(char *t){
	fprintf(Logi,"<FONT COLOR=\"FF0000\">%s</FONT>",t);
}	

void pset(int x,int y){
	blue("{");
	fprintf(Logi,"%s",T[x]);
	blue(",");
	fprintf(Logi,"%s",T[y]);
	blue("}");
}

void print_top(struct top *t){
fprintf(Logi," top %p: kood=%d leks=%d sem=%d label=%d truel=%d falsel=%d up=%p right=%p down=%p",
   t,t->kood,t->leks,t->sem,t->label,t->truel,t->falsel,t->up,t->right,
   t->down);
fprintf(Logi,"  (%s)<BR>",(t->leks==0) ? T[t->kood] : T[t->leks]);
if(t->right!=(struct top *)NULL) print_top(t->right);
if(t->down!=(struct top *)NULL) print_top(t->down);
}

void print_Itr(struct itr *t){
fprintf(Logi," itr %p: nr=%d loc=%d value=%d top=%p io=%d",
   t,t->nr,t->loc,t->value,t->t,t->io);
fprintf(Logi,"   (%s)<BR>",T[t->nr]);
}

void print_Ctr(struct ctr *t){
fprintf(Logi," ctr %p: nr=%d loc=%d value=%d",
   t,t->nr,t->loc,t->value);
fprintf(Logi,"   (%s)<BR>",T[t->nr]);
}

void print_one_top(struct top *t){
fprintf(Logi," top %p: kood=%d leks=%d sem=%d label=%d truel=%d falsel=%d up=%p right=%p down=%p",
   t,t->kood,t->leks,t->sem,t->label,t->truel,t->falsel,t->up,t->right,
   t->down);
fprintf(Logi,"  (%s)<BR>",(t->leks==0) ? T[t->kood] : T[t->leks]);
}

/* anal��sipuu tipu tr�kk */
void p_top(char *t,struct top *p){
	fprintf(Logi,"%s top:<BR>",t);
	print_one_top(p);
}

void print_item(int k,struct item *s){
fprintf(Logi," k=%d) item %p: liik=%d index=%d id=%p c=%p t=%p<BR>",
   k,s,s->liik,s->index,s->id,s->c,s->t);
}

void set_show(char *title){
	fprintf(Logi,"<H4><FONT COLOR=\"#0000FF\">%s",title);
	fprintf(Logi,"</FONT></H4>");
}

void ps(void){
	fprintf(Logi,"<BR>");
}

void ExIT(void){
	if(logi==1){
		fprintf(Logi,"Abnormal end<BR><BR>");
		fflush(Logi);
		fclose(Logi);
		}		
	abort();
}

FILE *opr(void){
	of=fopen(rida,"rb");
	if (of==NULL){
		fprintf(Logi,"cannot open %s. Constructor?",rida);
		return(of);
		}
	return(of);
}

struct top *r_ptree(void){
	struct top *p;
	p=(struct top *)malloc(sizeof(struct top));
	if(p==(struct top *)NULL){
		fprintf(Logi,"I haven't memory enough..");
		ExIT();
		}
	fread(p,sizeof(struct top),1,of);
	if(p->right!=(struct top *)NULL) p->right=r_ptree();
	if(p->down!=(struct top *)NULL) p->down=r_ptree();
	return(p);
}

void set_up(struct top *root){
	struct top *p;
	p=root;
	if(p->down!=(struct top *)NULL){
		p=p->down;
		while(p->right!=(struct top *)NULL){
			p=p->right;
			}
		p->up=root;	
		}
	if(root->down!=(struct top *)NULL) set_up(root->down);
	if(root->right!=(struct top *)NULL) set_up(root->right);
}  

int r_tree(void){
	sprintf(rida,"%s.pt",Pr_name);
	if(opr()!=NULL){
		p_=r_ptree();
		set_up(p_);
		return(1);
		}
	return(0);
}		

int r_t(void){
	sprintf(rida,"%s.t",Pr_name);
	if(opr()!=NULL){
		fread(&T,20,nr+1,of);
		fclose(of);
		return(1);
		}
	else return(0);
}

int r_parm(void){
	PARM=(struct parm *)malloc(sizeof(struct parm));
	if(PARM==(struct parm *)NULL) ExIT();
	memset(PARM,'\0',sizeof(struct parm));
	sprintf(rida,"%s.prm",Pr_name);
	if(opr()!=NULL){
		fread(PARM,sizeof(struct parm),1,of);
		fclose(of);
		nr=PARM->nr;
		itl=PARM->itl;
		ktl=PARM->ktl;
		return(1);
		}
	return(0);
}

int r_it(void){
	sprintf(rida,"%s.it",Pr_name);
	if(opr()!=NULL){
		fread(&IT,itl*sizeof(int),1,of);
		fclose(of);
		return(1);
		}
	return(0);
}

int r_kt(void){
	sprintf(rida,"%s.kt",Pr_name);
	if(opr()!=NULL){
		fread(&KT,ktl*sizeof(int),1,of);
		fclose(of);
		return(1);
		}
	return(0);
}

int r_tabs(void){
	int flag;
	flag=1;
	flag=r_parm(); 
	if(flag==0) goto out;
	flag=r_t();    
	if(flag==0) goto out;
	flag=r_it();   
	if(flag==0) goto out;
	flag=r_kt();    
	if(flag==0) goto out;
	flag=r_tree();  
	fflush(Logi);
out:    if(flag==0){
		fprintf(Logi,"cannot read all the tables..");
		fflush(Logi);
		}
	return(flag);
}

int print_Op(struct top *t){
	int fg=0;
	if(t!=(struct top *)NULL){
		if(t->sem==labl){
			t=t->down;
			fprintf(Logi,"%s: ",T[t->leks]); 
			return(0);
			}
		if(t->sem==lugem||t->sem==kirjut){
			tprop(t->sem);
			t=t->down;
			fprintf(Logi,"%s",T[t->leks]);
			return(0);
			}
		if(t->sem==suunam){
			tprop(t->sem);
			t=t->down;
			t=t->down;
			fprintf(Logi," %s",T[t->leks]);
			return(0);
			}	
		if(t->sem==kuisiis){
			fprintf(Logi,"IF ");
			print_Op(t->down);
			fprintf(Logi," THEN ");
			return(0);
			}
		if(t->down!=(struct top *)NULL&&t->sem!=omist){
			fprintf(Logi,"(");
			fg=1;
			}
		print_Op(t->down);
		if(t->leks!=0) fprintf(Logi,"%s",T[t->leks]);
		else tprop(t->sem);
		t=t->down;
		if(t!=(struct top *)NULL){
			print_Op(t->right);
			if(fg==1) fprintf(Logi,")");
			}
		}
	return(0);
}


/* TRIGOL-keelsete programmide tr�kk puu j�rgi  */
void p_prog(struct top *root){
	struct top *t;
	t=root->down;
	fprintf(Logi,"</FONT># ");
naaber:	print_Op(t);
	if(t->sem!=kuisiis&&t->sem!=labl&&t->up!=root) ps();
	t=t->right;
	if(t==(struct top *)NULL) goto ok;
	goto naaber;			
ok:	fprintf(Logi,"#<BR>");
}

/* m�rgendatud operaatorite otsimine */
int det_label(struct top *P){
	struct top *t,*op,*lab;
	struct itr *id;
	int k,flag=0;
	t=P;
ring:	
	if(t==(struct top *)NULL) goto out;
	if(t->sem==labl){
		op=t->right;
		lab=t->down;
		for(k=0;k<itl;k++){
			if(IT[k]==lab->leks){
				id=IDT[k];
				goto iok;
				}
			}	
		iok:		
		if(id->t!=(struct top *)NULL){
			fprintf(Logi,"label '%s' repeats<BR>",T[lab->leks]);
			flag++;
			goto next;
			}
		id->t=op;
		fprintf(Logi,"label '%s' is address of the operator {%s} (%p)<BR>",
		        T[lab->leks],T[op->kood],op);
		t=op;
		goto ring;
		}
next: t=t->right;
	goto ring;		
out:	return(flag);
}

/* m�rgendatud operaatorite otsimine, m�rgendi to"o"tlus */
void set_label(struct top *P){
	struct top *t,*op,*lab,*prev;
	struct itr *id;
	int k;
	t=prev=P;
ring: if(t!=(struct top *)NULL){
		if(t->sem==labl){
			op=t->right;
			lab=t->down;
			for(k=0;k<itl;k++){
				if(IT[k]==lab->leks){
					id=IDT[k];
					goto iok;
					}
				}
			iok: id->t=op;
			prev->right=op;
			op->label=lab->leks;
			free(t);
			free(lab);
			t=op;
			goto ring;
			}
		prev=t;
		t=t->right;
		goto ring;
	}			
}

void ctree(void){
	int f;
	if(ktl>0){
		blue("<BR>Table of constants<BR>");
		make_CT();
		}
	if(itl>0){
		blue("<BR>Table of identifiers<BR>");
		make_IDT();
		f=0;
		f=det_label(p_->down);
		if(f==0) set_label(p_->down);
		}	
}		

void tprop(int s){
	switch(s){
		case 0:       fprintf(Logi,"root"); break;
		case pisem:   fprintf(Logi,"<"); break;
		case suurem:  fprintf(Logi,">"); break;
		case piv:     fprintf(Logi,"<="); break;
		case suv:     fprintf(Logi,">="); break;
		case pov:     fprintf(Logi,"/="); break;		
		case vord:    fprintf(Logi,"="); break;
		case omist:   fprintf(Logi,":="); break;
		case jag:     fprintf(Logi,"/"); break;
		case korrut:  fprintf(Logi,"*"); break;
		case lahut:   fprintf(Logi,"-"); break;
		case liit:    fprintf(Logi,"+"); break;
		case suunam:  fprintf(Logi,"GOTO "); break;
		case kuisiis: fprintf(Logi,"IF "); break;
		case tingop:  fprintf(Logi," "); break;
		case lugem:   fprintf(Logi,"READ "); break;
		case kirjut:  fprintf(Logi,"WRITE "); break;
		case labl:    fprintf(Logi,"label"); break;
		default:      fprintf(Logi,"%d",s); break;
		}
}

int pp2html(struct top *p) {
	double pr;
	int n=1;
	struct top *t;
	char s[20];
	t=p;
naaber:
	if(t->right!=NULL){
		n++;
		t=t->right;
		goto naaber;
		}
	pr=100.0/n;
	sprintf(s,"\"%2.0f&#037\"",pr);	
	fprintf(Logi,"<table border=1><tr>");	
next:
	fprintf(Logi,
	"<td width=%s valign=\"top\"><STRONG>",s); 	
	if((p->kood==m_k)||(p->kood==k_k)) fprintf(Logi,"%s",T[p->leks]);
	else tprop(p->sem);
	if(p->down!=NULL) pp2html(p->down);
	fprintf(Logi,"</td>");	
	if(p->right!=NULL){			
		p=p->right;
		goto next;
		}
	fprintf(Logi,"</tr></table>");
	return 1;
}  

/* m�lueraldus konstantide tabeli kirjele */
struct ctr *make_ctr(void){
	struct ctr *c;
	c=(struct ctr *)malloc(sizeof(struct ctr));
	if(c==(struct ctr *)NULL) ExIT();
	memset(c,'\0',sizeof(struct ctr));
	return(c);
}	
	
/* konstantide tabeli moodustamine */
int make_CT(void){
	int t;
	struct ctr *c;
	int i;
	if(ktl==0) return(0);
	fprintf(Logi,"<TABLE BORDER=1><TR>");
	for(i=0;i<ktl;i++){
		t=KT[i];
		c=make_ctr();
		c->nr=t;
		c->loc=i;
		c->value=atoi(T[c->nr]);
		CT[i]=c;
		fprintf(Logi,"<TD>c%d=%d</TD>",i+1,c->value);
		}
	fprintf(Logi,"</TR></TABLE>");
	return(ktl);
}

/* m�lueraldus identifikaatorite tabeli kirjele */
struct itr *make_itr(void){
	struct itr *c;
	c=(struct itr *)malloc(sizeof(struct itr));
	if(c==(struct itr *)NULL) ExIT();
	memset(c,'\0',sizeof(struct itr));
	c->t=(struct top *)NULL;
	return(c);
}	

/* identifikaatorite tabeli moodustamine */
int make_IDT(void){
	int t;
	struct itr *c;
	int i;
	if(itl==0) return(0);	
	fprintf(Logi,"<TABLE BORDER=1><TR>");
	for(i=0;i<itl;i++){
		t=IT[i];
		c=make_itr();
		c->nr=t;
		c->loc=i;
		IDT[i]=c;
		fprintf(Logi,"<TD>i%d=%s</TD>",i+1,T[c->nr]);
		}
	fprintf(Logi,"</TR></TABLE>");		
	return(itl);
}

/* identifikaatorite tabeli kirje tr�kk */
void p_itr(struct itr *id){
	fprintf(Logi,"ITR nr=%d V=%s loc=%d value=%d t=%p<BR>",
		id->nr,T[id->nr],id->loc,id->value,id->t);
}

/* muutujate v�ljatr�kk */
void print_variables(void){
	struct itr *id;
	int i;
	set_show("THE VARIABLES:");
	for(i=0;i<itl;i++){
		id=IDT[i];
		if(id->t==(struct top *)NULL) 
			fprintf(Logi,"%s=%d<BR>",T[id->nr],id->value);
		}
}

/* konstantide tabeli kirje tr�kk */
void p_ctr(struct ctr *id){
	fprintf(Logi,"CTR nr=%d V=%s loc=%d value=%d<BR>",
		id->nr,T[id->nr],id->loc,id->value);
}		

/* magasini elemendi m�lueraldus */
struct item *make_item(void){
	struct item *c;
	c=(struct item *)malloc(sizeof(struct item));
	if(c==NULL) ExIT();
	memset(c,'\0',sizeof(struct item));
	return(c);
}	

/* magasini m�lu vabastamine */
void freestack(int i,int k){
	struct item *c;
	while(k>0){
		c=stack[i-k];
		free(c);
		stack[i-k]=(struct item *)NULL;
		k--;
		}
}

/* luurab t��muutujate arvu (tmarv), t��tleb if-lause puud */
int det_nrlv(struct top *root){
	struct top *t,*t1,*t2,*t3,*t4;
	struct itr *id;
	int k;
	char st[20];
	int op;
	int tm=0;
	int N=0;  /* maks. t��muutuja number */
	int i=0;  /* magasiniindeks */
	IX=1;     /* t��m�rgendi nr */
	t=root->down;
	memset(st,'\0',20);
down:
	if(t->down!=(struct top *)NULL){
		t=t->down;
		goto down;
		}
/* leht => stack  */
leht:
	op=t->sem;
	switch(op){
		case muut:{                              /* muutuja */
			st[i]=1;
			for(k=0;k<itl;k++){
				if(IT[k]==t->leks){
					id=IDT[k];
					goto iok;
					}
				}	
			iok:
			if(id->t!=(struct top *)NULL){
				st[i]=3;              /* m�rgend */
				}
			break;
			}
		case konst:{
			st[i]=2;                        /* konstant */
			break;
			}
		default: red("error in the parsing tree");
			 return(-1);
		}
	i++;
naaber:	
	if(t->up==(struct top *)NULL){
		t=t->right;
		if(t->down!=(struct top *)NULL)	goto down;
		else goto leht;
		}
	t=t->up;
	if(t==root) goto ok;
	op=t->sem;
	if((op>=pisem)&&(op<=vord)){              /* v�rdlustehe */
		if(st[i-2]==4) tm--;
		if(st[i-1]==4) tm--;
		i-=2;
		goto naaber;
		}
	if((op>=jag)&&(op<=liit)){            /* aritmeetika */
			if(st[i-2]==4) tm--;
			if(st[i-1]==4) tm--;
			st[i-2]=4;     /* t��muutuja */
			tm++;
			if(tm>N) N=tm;
			i-=1;
			goto naaber;
			}
	switch(op){
		case omist:{              /* omistamine */
			if(st[i-2]==4) tm--;
			if(st[i-1]==4) tm--;
			i-=2;
			break;
			}
		case suunam:{               /* suunamine */
			i-=1;
			break;
			}
		case kuisiis:{          /* if-lause */
			t1=t->down;     /* v�rdlemine */
			t2=t->right;    /* IFi naaber */
			if(t2->sem==suunam){
				t3=t2->down;
				t4=t3->down;
				t1->truel=t4->leks;
				free(t3);
				free(t4);   
				t->up=t2->up;
				t->right=t2->right;
				free(t2);   /* eemaldan 'goto' */
				}
			else{
				t3=t2->right;
				t1->truel=IX;
				t2->label=IX;
				IX++;
				t1->falsel=IX;
				t3->label=IX;
				IX++;
				}
			break;
			}
		case tingop: break;
		case lugem:{
			t1=t->down;
			for(k=0;k<itl;k++){
				if(IT[k]==t1->leks){
					id=IDT[k];
					goto lok;
					}
				}	
			lok:	
			id->io=id->io||1; 
			Rd=1;
			i-=1; 
			break;
			}
		case kirjut:{
			t1=t->down;
			for(k=0;k<itl;k++){
				if(IT[k]==t1->leks){
					id=IDT[k];
					goto kok;
					}
				}	
			kok:	
			id->io=id->io||2;  
			Wr=1;
			i-=1; 
			break;
			}
		}
	goto naaber;
ok:	
	return(N);
}

/* tekstimassiivi sisestamine kettalt */
char *jarray(char *pealkiri){
	FILE *tekst=NULL;
	char *B;
	char c;
	int  i;
	int  k;
	struct stat *buf;
	buf=(struct stat *)malloc(sizeof(struct stat));
	if(buf==NULL){
		fprintf(Logi,"r_text: I haven't %d bytes of memory..<BR>",
			sizeof(struct stat));
		ExIT();
		}		
 	tekst = fopen(pealkiri, "r");
	if (tekst==NULL){
		fprintf(Logi,"cannot find the file  %s <BR>",pealkiri);
		ExIT();
		}
	if(stat(pealkiri,buf)==-1){
		fprintf(Logi,"r_text: stat failed<BR>");
		ExIT();
		}
	k=buf->st_size;	
	B = (char *)malloc(k+10);
	if(B == NULL){
		fprintf(Logi,"I don't have memory enaugh..");
		ExIT();
		}
	memset(B,'\0',k+10);
/* fill buffer */
	rewind(tekst);
	i=0;
	while (!feof(tekst)){
		c=fgetc(tekst);
		B[i]=c;
		i++;
		}
	P_length=i;
	for(i=P_length;i>0;i--){
		if(isgraph(B[i])){
			i++;
			B[i]='\n';
			i++;
			B[i]='\0';
			P_length=i;
			goto out;
			}
		}
out:	fclose(tekst);
	return(B);
}

int prog(void){
	PBuf=jarray(pr_name);
	if(PBuf!=NULL){
		Plen=P_length;
		return(1);
		}
	return(0);
}

void Put(char *c){
	fprintf(rules,"%s",c);
	if(c[0]==';') fprintf(Logi,"<FONT COLOR=\"008000\">%s</FONT>",c);
	else fprintf(Logi,"%s",c);
}

void PreOn(void){
	fprintf(Logi,"<CODE><PRE><BIG>");
}

void PreOff(void){
	fprintf(Logi,"</PRE>");
}	

int gen_header(void){
	struct itr *id;
	int i,j;
	int id_nr=0;
	memset(rida,'\0',80);
	sprintf(rida,"%s.asm",Pr_name);
	rules=fopen(rida, "w");
	if (rules==NULL){
		fprintf(Logi,"cannot create the file %s<BR>",rida);
		fclose(rules);
		return(0);
		};
	blue("<BR><BR>Compiler to Assembler started<BR><BR>");
	if(prog()==0) goto yle;
	green("; gen_header: source text<BR>");
	memset(rida,'\0',80);
	j=0;
	for(i=0;i<Plen;i++){
		rida[j]=PBuf[i];
		j++;
		if(PBuf[i]=='\n'){
			fprintf(Logi,
				"<FONT COLOR=\"008000\">; %s<BR></FONT>",rida);
			fprintf(rules,"; %s",rida);
			memset(rida,'\0',80);
			j=0;
			}
		}
	fprintf(rules,";\n");
	green(";<BR>");
yle:
	id_nr=0;
	for(i=0;i<itl;i++){
		id=IDT[i];
		if(id->t==(struct top *)NULL) id_nr++;
		}		
	PreOn();	
	sprintf(rida,"; Program %s.asm\n",Pr_name);
	Put(rida);
	Put("\t.MODEL\tsmall\n");
	Put("\t.STACK\t100h\n");	
	sprintf(rida,"; gen_header: Rd=%d Wr=%d<BR>",Rd,Wr);
	green(rida);
	if(Rd==1) Put("\tEXTRN\treadint:PROC\n");
	if(Wr==1) Put("\tEXTRN\tbin2dec:PROC\n");
	if(id_nr>0){
		sprintf(rida,"; gen_header: # of identifiers=%d<BR>",id_nr);
		green(rida);
		Put("\t.DATA\n");
		for(i=0;i<itl;i++){
			id=IDT[i];
			if(id->t==(struct top *)NULL){
				sprintf(rida,"%s\tDW\t0\n",T[id->nr]);
				Put(rida);
				}
			}
		}
	if(tmarv>0){
		sprintf(rida,"; gen_header: # of workvariables=%d<BR>",tmarv);
		for(i=0;i<tmarv;i++){
			sprintf(rida,"dTv%d\tDW\t0\n",i);		
			Put(rida);
			}
		}		
	if(Rd==0 && Wr==0) goto code;
	green("; gen_header: generate I/O-text<BR>");	
	if(Rd==1) Put("Sisse\tDB\t'Input the variable ','$'\n");
	if(Wr==1) Put("Trykk\tDB\t'Variable ','$'\n");	
	if(itl>0){
		for(i=0;i<itl;i++){
			id=IDT[i];
			if(id->t==(struct top *)NULL&&id->io!=0){ 
				sprintf(rida,"%s_S\tDB\t'%s=','$'\n",
					T[id->nr],T[id->nr]); 
				Put(rida);	
				}  
			}
		}
	fflush(Logi);
code: green("; gen_header: code segment'll start<BR>");	
	Put("\t.CODE\nProgramStart:\n");
	Put("\tmov\tax,@data\n");
	Put("\tmov\tds,ax\n");
	fflush(Logi);
	return(1);
}
	
void w_label(int label){
	if(label>0){
		if(label>tnr) sprintf(rida,"%s:",T[label]);
		else sprintf(rida,"MExi%d:",label);
		Put(rida);
		Label=0;
		}
}

/* genereeri aadress */
void w_addr(int i,int k){
	struct item *s;
	struct ctr *c;
	struct itr *id;
	s=stack[i-k];
	switch(s->liik){
		case 0:{
			sprintf(rida,"dTv%d",s->index);
			Put(rida);
			IX--;
			break;
			}
		case 1:{
			id=s->id;
			sprintf(rida,"%s",T[id->nr]);
			Put(rida);
			break;
			}
		case 2:{
			c=s->c;
			sprintf(rida,"%s",T[c->nr]);
			Put(rida);
			break;
			}
		case 3:{
			id=s->id;
			sprintf(rida,"%s",T[id->nr]);
			Put(rida);
			break;
			}
		case 4:{
			sprintf(rida,"%d",s->index);
			Put(rida);
			IX--;
			break;
			}						
		}
}

/* magasini tr�kk */
void prist(int i,int ic){
	struct item *s;
	struct ctr *c;
	struct itr *id;
	int k;
	fprintf(Logi,"<BR><TABLE BORDER=1><B><TR>");
	fprintf(Logi,"<TD><FONT COLOR=\"#0000FF\"><STRONG>Stack<FONT></TD>");
	for(k=0;k<i;k++){
		s=stack[k];
		switch(s->liik){
			case 0: fprintf(Logi,"<TD>tm</TD>"); break;
			case 1: id=s->id;
				if(ic==0){
				    fprintf(Logi,"<TD>%s</TD>",T[id->nr]);
				    }
				 else{
				    fprintf(Logi,"<TD>%s</TD>",T[id->nr]);
				    }
				break;
			case 2: c=s->c;
				fprintf(Logi,"<TD>%d</TD>",c->value);
				break;
			case 3: id=s->id;
				fprintf(Logi,"<TD>%s:</TD>",T[id->nr]);
				break;
			}
		}
	fprintf(Logi,"</TR></TABLE>");
}				

struct item *leaf(struct top *t){
	int k,op;
	struct item *s;
	struct itr *id;
	struct ctr *c;
	s=make_item();
	op=t->sem;
	switch(op){
		case muut:{
			s->liik=1;                        /* muutuja */
			for(k=0;k<itl;k++){
				if(IT[k]==t->leks){
					id=IDT[k];
					goto iok;
					}
				}	
			iok:	
			s->id=id;
			if(id->t!=(struct top *)NULL){
				s->liik=3;                /* m�rgend */
				s->t=id->t;
				}
			break;
			}
		case konst:{
			for(k=0;k<ktl;k++){
				if(KT[k]==t->leks){
					c=CT[k];
					goto cok;
					}
				}	
			cok:	
			s->c=c;
			s->liik=2;                        /* konstant */
			break;
			}
		default: {
		 	memset(rida,'\0',80);
			sprintf(rida,"del %s.asm",pr_name);
			system(rida);
			fclose(rules);
			fprintf(Logi,"cannot compile the program %s.asm<BR>",
				pr_name);
			ExIT();	
			}
		}
	return(s);
}	

int logic(int i, struct top *t){
	int op;
	op=t->sem;
	Put("\tmov\tax,");
	w_addr(i,2);
	Put("\n\tcmp\tax,");
	w_addr(i,1);
	Put("\n");
	switch(op){
		case  pisem:{              /* < */
			Put("\tjb\t");
			break;
			}
		case  suurem:{              /* > */
			Put("\tjg\t");
			break;
			}
		case  piv:{              /* <= */
			Put("\tjbe\t");
			break;
			}
		case  suv:{              /* >= */
			Put("\tjge\t");
			break;
			}
		case  pov:{              /* /= */
			Put("\tjne\t");
			break;
			}
		case  vord:{              /* = */
			Put("\tje\t");
			break;
			}
		}
	freestack(i,2);
	i-=2;
	if(t->truel>0){
		if(t->truel>tnr) sprintf(rida,"%s\n",T[t->truel]);
		else sprintf(rida,"MExi%d\n",t->truel);
		Put(rida);
		}
	if(t->falsel>0){
		sprintf(rida,"\tjmp\tMExi%d\n",t->falsel);
		Put(rida);
		}
	return(i);
}	

int Assign(int i){
	if((opt==1)&&(nado==1)){
		Put("\tmov\t");
		w_addr(i,1);
		Put(",ax\n");
		freestack(i,1);
		i-=1;
		nado=0;
		return(i);
		}
	Put("\tmov\tax,");
	w_addr(i,1);
	Put("\n\tmov\t");
	w_addr(i,2);
	Put(",ax\n");
	freestack(i,2);
	i-=2;
	return(i);
}	

int Aritm(int i,struct top *t){
	int op;
	struct item *s;
	struct top *t1;
	op=t->sem;
	Put("\tmov\tax,");
	w_addr(i,2);
	switch(op){
		case jag:
			Put("\n\tmov\tdl,");
			w_addr(i,1);
			Put("\n");
			Put("\tdiv\tdl\n");
			break;
		case korrut:
			Put("\n\tmov\tdx,");
			w_addr(i,1);
			Put("\n");
			Put("\tmul\tdx\n");
			break;
		case lahut:              /* lahutamine */
			Put("\n\tsub\tax,");
			w_addr(i,1);
			Put("\n");
			break;
		case liit:              /* liitmine */
			Put("\n\tadd\tax,");
			w_addr(i,1);
			Put("\n");
			break;
		}	
	freestack(i,2);
	if(opt==1){
		t1=t->up;
		if(t1->sem==omist){
			i-=2;
			nado=1;
			return(i);
			}
		}	
	s=make_item();
	s->liik=0;
	s->index=IX;
	stack[i-2]=s;
	sprintf(rida,"\tmov\tdTv%d,ax\n",IX);
	Put(rida);
	IX++;
	i-=1;
	return(i);
}	

int InOut(int i,struct top *t){
	struct item *s;
	struct itr *id;
	int op,x;
	s=stack[i-1];
	id=s->id;
	x=strlen(T[id->nr]);
	Put("\tmov\tah,9h\n");
	Put("\tmov\tbx,1\n");	
	op=t->sem;
	switch(op){
		case lugem:
			Put("\tmov\tcx,17\n");
			Put("\tmov\tdx,OFFSET Sisse\n");
			Put("\tint\t21h\n");
			Put("\tmov\tah,9h\n");
			Put("\tmov\tbx,1\n");
			sprintf(rida,"\tmov\tcx,%d\n",x+1);
			Put(rida);
			sprintf(rida,"\tmov\tdx,OFFSET %s_S\n",T[id->nr]);
			Put(rida);
			Put("\tint\t21h\n");
			Put("\tcall\treadint\n");
			Put("\tmov\t");				
			w_addr(i,1);
			Put(",ax\n"); 
			break;
		case kirjut:
			Put("\tmov\tcx,8\n");
			Put("\tmov\tdx,OFFSET Trykk\n");
			Put("\tint\t21h\n");
			Put("\tmov\tah,9h\n");
			Put("\tmov\tbx,1\n");
			sprintf(rida,"\tmov\tcx,%d\n",x+1);
			Put(rida);
			sprintf(rida,"\tmov\tdx,OFFSET %s_S\n",T[id->nr]);
			Put(rida);
			Put("\tint\t21h\n");
			sprintf(rida,"\tmov\tax,%s\n",T[id->nr]);
			Put(rida);
			Put("\tmov\tdx,0\n");
			Put("\tcmp\tax,0\n");
			Put("\tjg\ts1h2o3w\n");
			Put("\tmov\tdx,1\n");
			Put("s1h2o3w:\n");
			Put("\tmov\tch,1\n");
			Put("\tcall\tbin2dec\n");
			break;
		}
	freestack(i,1);
	i-=1;		
	return(i);
}				

void trigol_Asm(struct top *root){
	struct top *t;
	int op;
	int i=0;
	int j;
	IX=0;       /* t��muutuja index */
	Label=0;
	t=root->down;
	for(j=0;j<20;j++) stack[j]=(struct item *)NULL;
down:	
	if(t->label>0) Label=t->label;
	if(t->down!=(struct top *)NULL){
		t=t->down;
		goto down;
		}
	stack[i]=leaf(t);
	i++;
	prist(i,0); 
naaber:	if(t->up==(struct top *)NULL){
		t=t->right;
		goto down;
		}
	t=t->up;
	if(t==root) goto ok;
	green(";compiling the operator  ");
	print_Op(t);
	ps();	
	pp2html(t);
	if(Label!=0) w_label(Label);
	op=t->sem;
	if(op>=pisem&&op<=vord){
		i=logic(i,t);	
		goto naaber;
		}
	if(op>=jag&&op<=liit){
		i=Aritm(i,t);
		goto naaber;
		}
	switch(op){
		case omist:             /* omistamine */
			i=Assign(i);				
			break;
		case suunam:               /* suunamine */
			Put("\tjmp\t");
			w_addr(i,1);
			Put("\n");
			freestack(i,1);
			i-=1;
			break;
		case kuisiis:	break;
		case tingop: break;
		case lugem: i=InOut(i,t); break;
		case kirjut: i=InOut(i,t); break;	
		}
	prist(i,0);  
	goto naaber;
ok:	Put("\tmov\tah,4ch\n");   /* DOS terminate program f. */
	Put("\tint\t21h\n");      /* terminate the program */
	Put("\tEND\tProgramStart\n");
	fflush(rules);
	fclose(rules);
	fprintf(Logi,
	  "<FONT COLOR=\"008000\">programm %s.asm is compiled<BR></FONT>",
	  Pr_name);
}

FILE *op(void){
	FILE *inf=NULL;
	inf=fopen(rida,"rb");
	if (inf==NULL){
		fprintf(Logi,"cannot open the file %s ",rida);
		fclose(inf);
		return(NULL);
		}
	rewind(inf);
	return(inf);
}

int LogicO(int i,struct top *t){
	struct item *s1,*s2;
	struct ctr *c;
	int op,r,x,y;
	s1=stack[i-2];
	s2=stack[i-1];
	if((s1->liik==2||s1->liik==4)&&(s2->liik==2||s2->liik==4)){
		green("constant expression, I'll optimize..<BR>");
		r=0;
		if(s1->liik==2){
			c=s1->c;
			x=c->value;
			}
		else x=s1->index;
		if(s2->liik==2){
			c=s2->c;
			y=c->value;
			}
		else y=s2->index;
		op=t->sem;
		switch(op){
			case pisem:  if(x<y)  r=1; 
					sprintf(rida,"%d < %d ?<BR>",x,y); 
					green(rida);
					break;
				case suurem: if(x>y)  r=1; 
					fprintf(Logi,
					"<FONT COLOR=\"008000\">%d > %d ?<BR></FONT>",x,y); break;
				case piv:    if(x<=y) r=1; 
					fprintf(Logi,
					"<FONT COLOR=\"008000\">%d <= %d ?<BR></FONT>",x,y); break;
				case suv:    if(x>=y) r=1; 
					fprintf(Logi,
					"<FONT COLOR=\"008000\">%d >= %d ?<BR></FONT>",x,y); break;
				case pov:    if(x!=y) r=1; 
					fprintf(Logi,
					"<FONT COLOR=\"008000\">%d /= %d ?<BR></FONT>",x,y); break;
				case vord:   if(x==y) r=1; 
					fprintf(Logi,
					"<FONT COLOR=\"008000\">%d = %d ?<BR></FONT>",x,y); break;
				}
			freestack(i,2);
			i-=2;
			if(r==1){
				if(t->truel>tnr){
					sprintf(rida,"\tjmp\t%s\n",T[t->truel]);
					Put(rida);
					}
				else{
					t=t->up;
					t=t->right;
					}
				}	
		}
	return(i);
}
			
int AritmO(int i,struct top *t){
	struct item *s1,*s2;
	struct ctr *c;
	int op,r,x,y;
	s1=stack[i-2];
	s2=stack[i-1];
	if((s1->liik==2||s1->liik==4)&&(s2->liik==2||s2->liik==4)){
		green("constant expression, I'll optimize..<BR>");
		fflush(Logi);
		r=0;
		if(s1->liik==2){
			c=s1->c;
			x=c->value;
			}
		else x=s1->index;
		if(s2->liik==2){
			c=s2->c;
			y=c->value;
			}
		else y=s2->index;
		op=t->sem;
		switch(op){
			case jag: r=x/y; 
				fprintf(Logi,
				"<FONT COLOR=\"008000\">%d = %d / %d<BR></FONT>",r,x,y);
					break;
			case korrut: r=x*y; 
				fprintf(Logi,
				"<FONT COLOR=\"008000\">%d = %d * %d<BR></FONT>",r,x,y);
					break;
			case lahut: r=x-y; 
				fprintf(Logi,
				"<FONT COLOR=\"008000\">%d = %d - %d<BR></FONT>",r,x,y);
					break;
			case liit: r=x+y; 
				fprintf(Logi,
				"<FONT COLOR=\"008000\">%d = %d + %d<BR></FONT>",r,x,y);
					break;
				}
			s1->liik=4;
			s1->index=r;
			freestack(i,1);
			i-=1;
		}
	fflush(Logi);
	return(i);
}			

void trigol_Asm_O(struct top *root){
	int op;
	int i=0;
	int j;
	IX=0;       /* t��muutuja index */
	Label=0;
	t=root->down;
	for(j=0;j<20;j++) stack[j]=(struct item *)NULL;
down:	
	if(t->label>0) Label=t->label;
	if(t->down!=(struct top *)NULL){
		t=t->down;
		goto down;
		}
	stack[i]=leaf(t);
	i++;
	prist(i,0);  
naaber:	if(t->up==(struct top *)NULL){
		t=t->right;
		goto down;
		}
	t=t->up;
	if(t==root) goto ok;
	green("; compiling the operator  ");
	print_Op(t);
	ps();
	pp2html(t);	
	if(Label!=0) w_label(Label);
	fflush(Logi);
	op=t->sem;
	if(op>=pisem&&op<=vord){
		j=i;
		i=LogicO(i,t);
		if(i==j) i=logic(i,t);	
		goto naaber;
		}
	if(op>=jag&&op<=liit){
		j=i;
		i=AritmO(i,t);
		fflush(Logi);
		if(i==j) i=Aritm(i,t);	
		fflush(Logi);
		goto naaber;
		}
	switch(op){
		case omist: i=Assign(i);
			break;
		case suunam:
			Put("\tjmp\t");
			w_addr(i,1);
			Put("\n");
			freestack(i,1);
			i-=1;
			break;
		case kuisiis:
			break;
		case tingop: break;
		case lugem: i=InOut(i,t); break;
		fflush(Logi);
		case kirjut: i=InOut(i,t); break;	
		fflush(Logi);	
		}
	prist(i,0);  
	goto naaber;
ok:	Put("\tmov\tah,4ch\n");   /* DOS terminate program f. */
	Put("\tint\t21h\n");      /* terminate the program */
	Put("\tEND\tProgramStart\n");
	fflush(rules);
	fclose(rules);
	fprintf(Logi,
	  "<FONT COLOR=\"008000\">programm %s.asm is compiled<BR></FONT>",
	  Pr_name);
}

void to_asm(struct top *p){
	Rd=0;
	Wr=0;
	tmarv=det_nrlv(p);
	if(tmarv<0) goto ots;
	set_show("Modified tree:");
	pp2html(p_);
	if(gen_header()==0) goto ots;
	(opt==0) ? trigol_Asm(p_) : trigol_Asm_O(p);
	blue("<BR> I'll start compiler from assembler, and linker<BR>");
	sprintf(rida,"tasm %s >>%s\n",Pr_name,L_name);   
	fprintf(Logi,"<BR>%s<BR>",rida);
	fflush(Logi);
	fclose(Logi); 
	system(rida);
	Logi=fopen(L_name,"a+");  
	sprintf(rida,"tlink %s+teek >>%s\n",Pr_name,L_name);
	fprintf(Logi,"<BR>%s<BR>",rida);
	fflush(Logi);
	fclose(Logi); 
	system(rida);
	Logi=fopen(L_name,"a+");  
ots:
	fflush(Logi);
	fflush(rules);
	fclose(rules);
}


struct top *analyzer(void){
	if(r_tabs()==0) return(0);
	set_show("Program");
   	p_prog(p_);
	set_show("Parsing tree");			
	pp2html(p_);	
	ctree();
	fflush(Logi);
	return(p_);
}

int itr(void){
	int ret=0;
	time_t t0;
	GBuf=NULL;
	Logi=fopen(L_name,"w");
	if(Logi==NULL){
		printf("Cannot open log-book\n");
		return(0);
		}
	m_k=4; k_k=11;
	logi=1;
	time(&t0);
	fprintf(Logi,"<HTML><HEAD><TITLE>Compiler</TITLE></HEAD><BODY><B>");
	fprintf(Logi,"<FONT COLOR=\"#0000FF\"><H3>Start of TRIGOL ");
	if(opt==1) fprintf(Logi,"Optimizing ");
	fprintf(Logi,"Compiler for a Program ");
	fprintf(Logi,"</FONT>%s ",pr_name);
	fprintf(Logi,"<FONT COLOR=\"#0000FF\"> at </FONT>");
	fprintf(Logi,"%s</H3><BR>",asctime(localtime(&t0)));
	if(analyzer()!=0) to_asm(p_);
	time(&t0);
	fprintf(Logi,"<FONT COLOR=\"#0000FF\"><H4>Compiler ended at </FONT> ");
	fprintf(Logi,"%s</H4>",asctime(localtime(&t0)));	
	fprintf(Logi,"</BODY></HTML>");
	return(ret);
}

int main(int argc,char **argv){
	opt=0;
	if(argc<2){
		printf("arguments: p-name [o]\n"); abort();
		}
	if(argc==3) opt=1;

	pr_name=(char *)malloc(256);	
	L_name=(char *)malloc(256);
	Nimi=(char *)malloc(8);	
	Pr_name=(char *)malloc(256);	
	memset(pr_name,'\0',256);	
	memset(L_name,'\0',256);	
	memset(Nimi,'\0',8);
	strcpy(Nimi,"tri");			
	memset(Pr_name,'\0',256);			
	sprintf(pr_name,"%s",argv[1]);	
	strcpy(Pr_name,pr_name);	
	strcpy(L_name,pr_name);
	strcat(pr_name,".tri"); 
	if(opt==0) strcat(L_name,"c.htm");
	else strcat(L_name,"oc.htm");
	printf("pr_name=%s L_name=%s\n",pr_name,L_name);
	itr();
	return(1);
}		
